import React from 'react';
import { Clock, Thermometer, Sparkles, BookOpen, ChevronRight, ShieldCheck } from 'lucide-react';
import { HerbierRecipe } from '../../data/herbierRecipesRegistry';

interface HerbierRecipeCardProps {
  recipe: HerbierRecipe;
  onSelect?: (url: string) => void;
  showHeritageTeaser?: boolean;
}

export const HerbierRecipeCard: React.FC<HerbierRecipeCardProps> = ({
  recipe,
  onSelect,
  showHeritageTeaser = true
}) => {
  const dotsString = '●'.repeat(recipe.difficultyLevel) + '○'.repeat(5 - recipe.difficultyLevel);

  const getCategoryTheme = () => {
    switch (recipe.category) {
      case 'phytotherapie':
        return {
          bg: 'bg-emerald-50 text-emerald-900 border-emerald-200',
          badge: 'bg-emerald-100 text-emerald-800'
        };
      case 'cosmetique':
        return {
          bg: 'bg-rose-50 text-rose-900 border-rose-200',
          badge: 'bg-rose-100 text-rose-800'
        };
      case 'gastronomie':
        return {
          bg: 'bg-amber-50 text-amber-900 border-amber-200',
          badge: 'bg-amber-100 text-amber-800'
        };
      default:
        return {
          bg: 'bg-stone-50 text-stone-900 border-stone-200',
          badge: 'bg-stone-100 text-stone-800'
        };
    }
  };

  const theme = getCategoryTheme();

  const handleClick = (e: React.MouseEvent) => {
    if (onSelect) {
      e.preventDefault();
      onSelect(recipe.canonicalUrl);
    }
  };

  return (
    <article className="group bg-white rounded-3xl border border-[#EAE5D9] overflow-hidden hover:shadow-xl hover:border-[#0F261E]/30 transition-all duration-300 flex flex-col justify-between">
      <div>
        <!-- Image & Badges -->
        <div className="relative aspect-16/10 overflow-hidden bg-[#FAF7F2]">
          <img
            src={recipe.image}
            alt={recipe.imageAlt}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${theme.badge}`}>
              {recipe.categoryLabel}
            </span>
            <span className="px-2 py-1 rounded-full text-[10px] font-mono font-bold bg-[#0F261E]/80 text-white backdrop-blur-xs">
              Terrain {recipe.terrains[0]}
            </span>
          </div>
          <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-full text-[10px] font-bold text-[#0F261E] flex items-center gap-1 shadow-xs">
            <Clock className="w-3 h-3 text-[#0F261E]/60" />
            <span>{recipe.totalTimeMinutes} min</span>
          </div>
        </div>

        <!-- Content -->
        <div className="p-5 sm:p-6">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-mono text-emerald-800 font-semibold" title={`Niveau : ${recipe.difficultyLabel}`}>
              {dotsString} <span className="font-sans text-[11px] text-[#0F261E]/60">{recipe.difficultyLabel}</span>
            </span>
            <span className="text-[11px] font-mono text-[#0F261E]/50">
              {recipe.tempSachetA} / {recipe.tempSachetB}
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-bold font-serif text-[#0F261E] group-hover:text-emerald-900 transition-colors line-clamp-2 mb-2 leading-snug">
            <a href={recipe.canonicalUrl} onClick={handleClick}>
              {recipe.title}
            </a>
          </h3>

          <p className="text-xs sm:text-sm text-[#0F261E]/70 line-clamp-2 mb-4 leading-relaxed font-light">
            {recipe.subtitle}
          </p>

          {/* Mémoire du vivant Teaser */}
          {showHeritageTeaser && recipe.heritage && (
            <div className="p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE5D9]/70 mb-4 text-xs text-[#0F261E]/80">
              <div className="flex items-center gap-1.5 font-bold text-[10px] uppercase text-[#0F261E]/60 mb-1">
                <BookOpen className="w-3 h-3" />
                <span>{recipe.heritage.register.split('(')[0].trim()}</span>
              </div>
              <p className="italic font-serif line-clamp-2 text-[#0F261E]/90 text-[11px]">
                {recipe.heritage.quote}
              </p>
            </div>
          )}

          {/* Terrains & Axes Tags */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {recipe.terrains.map(t => (
              <span key={t} className="px-2 py-0.5 rounded-md bg-[#FAF7F2] text-[10px] font-mono font-medium text-[#0F261E]/70 border border-[#EAE5D9]">
                T{t.replace(/\D/g, '') || t}
              </span>
            ))}
            {recipe.axes.slice(0, 2).map(a => (
              <span key={a} className="px-2 py-0.5 rounded-md bg-amber-50 text-[10px] font-mono font-medium text-amber-900 border border-amber-200">
                {a}
              </span>
            ))}
          </div>
        </div>
      </div>

      <!-- Action Footer -->
      <div className="px-5 sm:px-6 pb-5 pt-3 border-t border-[#EAE5D9]/50 flex items-center justify-between">
        <span className="text-[11px] text-[#0F261E]/50">
          Lot {recipe.batchNumber}
        </span>
        <a
          href={recipe.canonicalUrl}
          onClick={handleClick}
          className="inline-flex items-center gap-1 text-xs font-bold text-[#0F261E] group-hover:text-emerald-900 group-hover:translate-x-1 transition-all"
        >
          <span>Consulter le protocole</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </a>
      </div>
    </article>
  );
};

export default HerbierRecipeCard;
