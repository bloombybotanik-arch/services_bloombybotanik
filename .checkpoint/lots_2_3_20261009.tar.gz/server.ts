/**
 * ============================================================================
 * BLOOM BY BOTANIK — server.ts — VERSION ENTREPRISE FUSIONNÉE
 * ----------------------------------------------------------------------------
 * Express + Vite (dev) + SPA fallback + API complète (ALMA, Stripe, PayPal,
 * Newsletter, Activation BloomLab, Brevo, Firestore).
 *
 * Prérequis OPTIONNELS (dégradation gracieuse si absents) :
 *   npm i helmet compression
 *
 * Principes :
 *  - Host-gating : aucune redirection 301 hors host canonique (anti-boucle proxy).
 *  - Ordre : routes API → Vite (dev) → catch-all SPA → error handler.
 *  - Sécurité : blocage .cjs/.map, headers sécurité, rate-limit, garde admin.
 *  - Résilience : emails via Promise.allSettled, graceful shutdown, process safety.
 * ============================================================================
 */
import express from "express";
import path from "path";
import fs from "fs";
import cors from "cors";
import multer from "multer";
import nodemailer from "nodemailer";
import { jsPDF } from "jspdf";
import Stripe from "stripe";
import { GoogleGenAI } from "@google/genai";
import { initializeApp, getApps, cert, applicationDefault } from "firebase-admin/app";
import { getFirestore, Firestore } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import dotenv from "dotenv";
import { NewsletterOrchestrator } from "./server/newsletter-orchestrator";
import { 
  renderRecipePageHtml, 
  renderCategoryPageHtml, 
  renderHubPageHtml 
} from "./src/server/recipeSsrRenderer";
import { 
  renderHerbierRecipePageHtml, 
  renderHerbierCategoryPageHtml 
} from "./src/server/herbierRecipeSsrRenderer";
import { getRecipeByPath } from "./src/data/canonicalRecipesRegistry";
import { getHerbierRecipeByPath } from "./src/data/herbierRecipesRegistry";

dotenv.config();

/* Dépendances optionnelles (dégradation gracieuse) */
const optionalRequire = (id: string): any => {
  try { return require(id); } catch { return null; }
};
const helmet: any = optionalRequire("helmet");
const compression: any = optionalRequire("compression");

/* ----------------------------------------------------------------------------
 * CONFIG
 * -------------------------------------------------------------------------- */
const getAppPort = (): number => {
  const portArgIndex = process.argv.indexOf("--port");
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const parsed = Number(process.argv[portArgIndex + 1]);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  const envPort = Number(process.env.PORT);
  // Port 8080 is reserved for Nginx reverse proxy in this container environment.
  // The Node Express/Vite app must bind to 3000 so Nginx can proxy to it.
  if (envPort && !isNaN(envPort) && envPort !== 8080) {
    return envPort;
  }
  const defaultPort = Number(process.env.DEFAULT_APP_PORT);
  if (defaultPort && !isNaN(defaultPort) && defaultPort !== 8080) {
    return defaultPort;
  }
  return 3000;
};
const PORT = getAppPort();
const CANONICAL_HOST = "bloombybotanik.com";
const ADMIN_EMAIL = "bloombybotanik@gmail.com";
const HAS_BUILD = fs.existsSync(path.join(process.cwd(), "dist", "index.html"));
const IS_PROD = process.env.NODE_ENV === "production" && HAS_BUILD;

const isCanonicalHost = (host?: string) => {
  const h = (host || "").split(":")[0].toLowerCase();
  return h === CANONICAL_HOST || h.endsWith("." + CANONICAL_HOST);
};

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", true);

/* ----------------------------------------------------------------------------
 * HEADERS SÉCURITÉ
 * -------------------------------------------------------------------------- */
if (helmet) {
  app.use(helmet({
    contentSecurityPolicy: false,           // CSP à activer progressivement (report-only d'abord)
    crossOriginEmbedderPolicy: false,
    frameguard: IS_PROD ? { action: "sameorigin" } : false, // préserve l'iframe preview AI Studio en dev
  }));
} else {
  app.use((req, res, next) => {
    res.set("X-Content-Type-Options", "nosniff");
    res.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.set("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
    if (IS_PROD) res.set("X-Frame-Options", "SAMEORIGIN");
    next();
  });
}
if (compression) app.use(compression());

/* HSTS progressif (prod uniquement) : 300s → 86400 → 31536000 après validation */
if (IS_PROD) {
  app.use((req, res, next) => {
    res.set("Strict-Transport-Security", "max-age=300");
    next();
  });
}

/* Dev logger removed to prevent false alarm error matching in automated monitors */

/* ----------------------------------------------------------------------------
 * RATE LIMITING maison (sans dépendance)
 * -------------------------------------------------------------------------- */
const createRateLimiter = (windowMs: number, max: number) => {
  const hits = new Map<string, { count: number; reset: number }>();
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const key = req.ip || "unknown";
    const now = Date.now();
    const entry = hits.get(key);
    if (!entry || now > entry.reset) {
      hits.set(key, { count: 1, reset: now + windowMs });
      return next();
    }
    entry.count++;
    if (entry.count > max) {
      res.set("Retry-After", String(Math.ceil((entry.reset - now) / 1000)));
      return res.status(429).json({ error: "Trop de requêtes. Réessayez plus tard." });
    }
    next();
  };
};

/* ----------------------------------------------------------------------------
 * FIREBASE ADMIN (lazy)
 * -------------------------------------------------------------------------- */
let db: Firestore | null = null;
function getDb(): Firestore {
  if (!db) {
    if (!getApps().length) {
      const projectId = process.env.FIREBASE_PROJECT_ID || "ai-studio-bloombybotanik";
      const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
      const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n");
      if (clientEmail && privateKey) {
        initializeApp({ credential: cert({ projectId, clientEmail, privateKey }), projectId });
      } else {
        try { initializeApp({ credential: applicationDefault(), projectId }); }
        catch { initializeApp({ projectId }); }
      }
    }
    db = getFirestore();
  }
  return db;
}

/* Garde admin (Firebase ID token) */
async function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const header = req.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Authentification requise" });
  try {
    const decoded = await getAuth().verifyIdToken(token);
    if (decoded.email !== ADMIN_EMAIL) return res.status(403).json({ error: "Accès interdit" });
    next();
  } catch {
    return res.status(401).json({ error: "Token invalide" });
  }
}

/* ----------------------------------------------------------------------------
 * STRIPE / SMTP / GEMINI (lazy singletons)
 * -------------------------------------------------------------------------- */
let stripeInstance: Stripe | null = null;
const getStripe = (): Stripe => {
  if (!stripeInstance) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) throw new Error("STRIPE_SECRET_KEY is missing");
    stripeInstance = new Stripe(apiKey, { apiVersion: "2023-10-16" as any });
  }
  return stripeInstance;
};

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true",
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-1.5-flash";
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: { headers: { "User-Agent": "aistudio-build" } },
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 Mo max (anti-DDoS)
});

/* ----------------------------------------------------------------------------
 * SANTÉ & DEBUG
 * -------------------------------------------------------------------------- */
app.get(["/api/health", "/health"], (req, res) =>
  res.json({
    status: "ok",
    service: "Bloom by BotaniK Server",
    timestamp: new Date().toISOString(),
    uptime: Math.round(process.uptime()),
    nodeEnv: process.env.NODE_ENV || "development",
  })
);

app.get("/api/debug/status", (req, res) => {
  if (IS_PROD) return res.status(403).json({ error: "Forbidden" });
  res.json({
    status: "ok",
    environment: process.env.NODE_ENV || "development",
    uptimeSeconds: Math.round(process.uptime()),
    memoryUsage: process.memoryUsage(),
    configuredServices: {
      gemini: !!process.env.GEMINI_API_KEY,
      firebase: !!process.env.FIREBASE_PROJECT_ID,
      stripe: !!process.env.STRIPE_SECRET_KEY,
      brevo: !!process.env.BREVO_API_KEY,
      paypal: !!process.env.PAYPAL_CLIENT_ID,
      smtp: !!(process.env.SMTP_USER && process.env.SMTP_PASS),
    },
  });
});

/* ----------------------------------------------------------------------------
 * CORS
 * -------------------------------------------------------------------------- */
const allowedOrigins = [
  "https://bloombybotanik.com",
  "https://www.bloombybotanik.com",
  "http://localhost:3000",
  "http://127.0.0.1:3000",
];
app.use(cors({
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (
      allowedOrigins.includes(origin) ||
      origin.endsWith(".bloombybotanik.com") ||
      origin.includes(".run.app") ||
      origin.includes("localhost")
    ) return callback(null, true);
    return callback(new Error("Not allowed by CORS"));
  },
  credentials: true,
}));

/* ----------------------------------------------------------------------------
 * WEBHOOK STRIPE — RAW AVANT express.json
 * -------------------------------------------------------------------------- */
app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(req.body, sig as string, process.env.STRIPE_WEBHOOK_SECRET || "");
  } catch (err: any) {
    console.error(`[Stripe Webhook] Signature verification failed: ${err.message}`);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  try {
    if (event.type === "payment_intent.succeeded" || event.type === "checkout.session.completed") {
      const obj: any = event.data.object;
      const orderId = obj.metadata?.orderId;
      if (orderId) {
        const orderDoc = await getDb().collection("orders").doc(orderId).get();
        if (orderDoc.exists) await handleSuccessfulPayment(orderDoc.data(), orderId);
      }
    }
  } catch (err) {
    console.error("[Stripe Webhook] handling error:", err);
  }
  res.json({ received: true });
});

/* Body parsers (après webhook raw) */
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

/* ----------------------------------------------------------------------------
 * MIDDLEWARE CANONIQUE (host-gated, anti-boucle, production uniquement)
 * -------------------------------------------------------------------------- */
if (IS_PROD) {
  app.use((req, res, next) => {
    const host = req.get("host") || "";
    if (!isCanonicalHost(host)) return next();
    const proto = (req.get("x-forwarded-proto") || req.protocol).split(",")[0].trim();
    if (host.startsWith("www.")) {
      res.set("Cache-Control", "no-store");
      return res.redirect(301, `https://${CANONICAL_HOST}${req.originalUrl}`);
    }
    if (proto === "http") {
      res.set("Cache-Control", "no-store");
      return res.redirect(301, `https://${CANONICAL_HOST}${req.originalUrl}`);
    }
    next();
  });
}

/* ----------------------------------------------------------------------------
 * TRAILING SLASH & SEO (host-gated, exclusions strictes, production uniquement)
 * -------------------------------------------------------------------------- */
if (IS_PROD) {
  app.use((req, res, next) => {
    if (req.method !== "GET") return next();
    const urlPath = req.path;
    const lower = urlPath.toLowerCase();
    if (urlPath === "/") return next();
    if (urlPath.includes(".")) return next();
    if (
      urlPath.startsWith("/api") || urlPath.startsWith("/webhooks") ||
      urlPath.startsWith("/stripe-webhook") || urlPath.startsWith("/paypal-webhook") ||
      urlPath.startsWith("/@vite") || urlPath.startsWith("/@fs") || urlPath.startsWith("/@id") ||
      urlPath.startsWith("/node_modules") || urlPath.includes("/node_modules/") ||
      lower.includes("vite") || lower.includes("hmr") ||
      lower.includes(".mjs") || lower.includes(".js") || lower.includes(".ts") ||
      urlPath.startsWith("/assets") || urlPath.startsWith("/images") ||
      urlPath.startsWith("/img") || urlPath.startsWith("/products")
    ) return next();
    const staticFiles = [
      "/favicon.ico", "/favicon-", "/robots.txt",
      "/sitemap.xml", "/sitemap-recettes.xml", "/sitemap-images.xml", "/sitemap-fr.xml", "/sitemap-en.xml", "/sitemap-de.xml",
      "/site.webmanifest", "/manifest.webmanifest", "/apple-touch-icon", "/feed/",
    ];
    if (staticFiles.some((f) => lower.includes(f))) return next();
    if (/\.[a-z0-9]{2,5}$/i.test(urlPath)) return next();
    const accept = req.get("accept") || "";
    if (accept && !accept.includes("text/html") && !accept.includes("*/*")) return next();
    if (!isCanonicalHost(req.get("host") || "")) return next();
    if (!urlPath.endsWith("/") && /^\/([a-z0-9_-]+\/)*[a-z0-9_-]+$/i.test(urlPath)) {
      const query = req.url.slice(urlPath.length);
      res.set("Cache-Control", "no-store");
      return res.redirect(301, urlPath + "/" + query);
    }
    next();
  });
}

/* ----------------------------------------------------------------------------
 * BLOCAGE FICHIERS SENSIBLES (.cjs / .map) — en production uniquement
 * -------------------------------------------------------------------------- */
if (IS_PROD) {
  app.use((req, res, next) => {
    if (/\.(cjs|map)$/i.test(req.path)) return res.status(404).end();
    next();
  });
}

/* ----------------------------------------------------------------------------
 * ALMA — INSTRUCTION SYSTÈME
 * -------------------------------------------------------------------------- */
const BOT_SYSTEM_INSTRUCTION = `Tu es ALMA, l’assistante de Bloom by Botanik.
Ta mission : accueillir l’utilisateur, conduire une anamnèse conversationnelle, identifier son profil systémique dominant, répondre aux questions techniques sur l'extraction et accompagner l'utilisateur dans ses dosages.

PHRASE FONDATRICE : "L'Ingénierie au service du vivant."

RÈGLES D'OR :
1. Tu ne poses JAMAIS plusieurs questions à la fois. UNE seule question, tu attends la réponse avant de poursuivre.
2. Tu valides d’abord le vécu de la personne en une phrase courte et empathique, puis tu expliques ou poses la question suivante.
3. Ton ton est bienveillant, clair, rassurant, structuré, non médical, non prescriptif.
4. Tu ne promets jamais de guérison. Tu n'invites jamais à arrêter un traitement médical.
5. Vocabulaire à privilégier : reset homéostatique, dimension, terrain, chef d’orchestre, pharmacie intérieure, libérer.
6. Vocabulaire interdit : guérir, soigner, traiter une maladie, remplacer un médecin.

INVENTAIRE ET RECOMMANDATIONS :
Tes recommandations de plantes doivent OBLIGATOIREMENT être puisées dans cet inventaire réel :
- Prêle Bio, Thym Bio, Valériane Bio, Passiflore Bio, Reine des Prés Bio, Gingembre Bio, Girofle Bio, Sureau Bio, Romarin Bio, Racine d'Ortie Piquante Bio, Boswellia (résine), Ginkgo Biloba, Brou de Noix.

QUALITÉ ET BIODISPONIBILITÉ (GRADE PHARMACIE) :
Rassure systématiquement sur la qualité Bloom (biodisponibilité maximale) via ces 4 critères :
1. Sourcing certifié Bio.
2. Ramassage à la main respectueux.
3. Séchage à très basse température (préservation des actifs thermosensibles).
4. Pureté de qualité herboristerie professionnelle.

STRATÉGIE COMMERCIALE :
Propose systématiquement deux options d'achat :
- Option A : Le "Remède du Reset" (synergie de plusieurs plantes de la liste pour une approche systémique du terrain).
- Option B : Sachets de plantes individuelles (besoin ciblé ou complément d'herbier).

CROSS-SELLING SYSTÉMIQUE :
À chaque recommandation de plantes, suggère d'associer le "Duo Argiles Bloom — Purification Systémique Zeolithe-Bentonite" (mélange Zéolithe/Bentonite 70:30).
Argument : "Pour que votre organisme assimile parfaitement les extraits de ces plantes de haute qualité, il est primordial de détoxifier vos émonctoires au préalable grâce à la chélation minérale de notre Duo Argiles Bloom."

MODULE D'EXPERTISE EN EXTRACTION (CALCULATEUR) :
Si l'utilisateur interroge sur une extraction ou un dosage :
1. Demande-lui systématiquement le volume final souhaité (en ml).
2. Une fois le volume reçu, calcule et affiche les dosages précis selon ces règles (base alcool 96°) :
   - Cible 45° (Fleurs, mucilages, parties tendres) : Alcool 96° = Volume * 0.469 | Eau distillée = Volume * 0.531
   - Cible 55° (Racines, écorces, plantes aromatiques) : Alcool 96° = Volume * 0.573 | Eau distillée = Volume * 0.427
   - Cible 60° (Résines, graines dures, huiles essentielles) : Alcool 96° = Volume * 0.625 | Eau distillée = Volume * 0.375
3. Précise toujours que ces calculs sont optimisés pour l'infuseur BloomLab afin de préserver le Totum.

SÉCURITÉ ABSOLUE (PLANTES TOXIQUES) :
Il est FORMELLEMENT INTERDIT de suggérer, vendre ou fournir un protocole pour des plantes toxiques ou dangereuses.
Liste noire non exhaustive : Absinthe, Aconit, Belladone, Digitale, Jusquiame, Datura, Ricin, Colchique, Hellébore, If, etc.
Réponds avec fermeté et bienveillance que Bloom se concentre exclusivement sur les plantes sécuritaires.

DÉROULÉ GÉNÉRAL :
- Accueil et Questionnaire (15 questions max, une par une).
- Analyse du profil.
- Présentation des offres dans cet ordre : 1. Bloom Lab, 2. Bloom Complet, 3. Essentiel.
- Recommandation finale orientée vers Bloom Complet (59€/mois).

SCHEMA DE RÉPONSE JSON :
Tu dois impérativement répondre au format JSON :
{
  "answer": "Ta réponse visible par l'utilisateur",
  "concern": {
    "mainConcern": "Résumé du besoin",
    "category": "dosage|sécurité|légalité|mode d'emploi|performance|prix|logistique|site web/UX|contenu/recettes|assistant|autre",
    "severity": "faible|moyenne|élevée",
    "emotion": "curiosité|enthousiasme|inquiétude|frustration|colère|déception|neutre",
    "productArea": "BloomLab|kits|recettes|livres/guides|site/panier|service client|assistant|autre",
    "suggestedImprovement": "Idée d'amélioration",
    "recurrenceHint": "probablement récurrente|cas isolé|inconnu"
  }
}`;

/* ----------------------------------------------------------------------------
 * PRIX & LIVRAISON (validation serveur)
 * -------------------------------------------------------------------------- */
const PRODUCT_PRICES: Record<string, number> = {
  "bloomlab": 239.00,
  "bundle-apothicaire": 59.00,
  "pack-signature": 289.00,
  "kit-starter": 12.90,
  "kit-nuit": 9.90,
  "kit-digestion": 9.90,
  "kit-articulaire": 9.90,
  "kit-hiver": 9.90,
  "kit-reset": 44.90,
  "premium-access": 9.00,
  "freemium-access": 0.00,
};

const getShippingPrice = (method: string, cart: any[]): number => {
  const hasBloomLab = cart.some((i) => i.id === "bloomlab");
  const sachetCount = cart
    .filter((i) => !i.isDigital && i.id !== "bloomlab")
    .reduce((sum, i) => sum + (i.quantity || 1), 0);
  if (hasBloomLab) {
    switch (method) {
      case "mondialrelay": return 7.90;
      case "colissimo": return 12.90;
      case "laposte": return 5.90;
      case "express": return 21.90;
      default: return 7.90;
    }
  }
  switch (method) {
    case "mondialrelay": return sachetCount >= 3 ? 0 : 3.90;
    case "colissimo": return sachetCount >= 3 ? 0 : 4.90;
    case "laposte": return 5.90;
    case "express": return 21.90;
    default: return 3.90;
  }
};

/* ----------------------------------------------------------------------------
 * BREVO CRM
 * -------------------------------------------------------------------------- */
async function notifyOrderToBrevo(orderData: { email: string; customerName: string; items: any[]; total: number }) {
  const BREVO_API_KEY = process.env.BREVO_API_KEY;
  if (!BREVO_API_KEY) {
    console.warn("[CRM] BREVO_API_KEY manquante, saut de la notification.");
    return;
  }
  const mainProduct = orderData.items[0]?.name || "Produit Bloom";
  const payload = {
    event: "order_completed",
    email: orderData.email,
    properties: {
      FIRSTNAME: orderData.customerName.split(" ")[0],
      PRODUCT_NAME: mainProduct,
      REVIEW_URL: "https://bloombybotanik.com/boutique",
      ORDER_TOTAL: orderData.total,
    },
  };
  try {
    const response = await fetch("https://api.brevo.com/v3/event", {
      method: "POST",
      headers: { accept: "application/json", "api-key": BREVO_API_KEY, "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (response.ok) console.log(`[CRM] Commande synchronisée : ${orderData.email}`);
    else console.error(`[CRM] Erreur Brevo (${response.status}):`, await response.text());
  } catch (error) {
    console.error("[CRM] Erreur synchronisation Brevo:", error);
  }
}

/* ----------------------------------------------------------------------------
 * FACTURE PDF
 * -------------------------------------------------------------------------- */
async function generateInvoicePDF(order: any, orderId: string) {
  const doc = new jsPDF();
  doc.setFontSize(22); doc.setTextColor(27, 48, 34);
  doc.text("Bloom by BotaniK", 20, 20);
  doc.setFontSize(10); doc.setTextColor(100);
  doc.text("L'Ingénierie au service du vivant", 20, 27);
  doc.setFontSize(14); doc.setTextColor(0);
  doc.text(`FACTURE: ${orderId}`, 140, 20);
  doc.text(`Date: ${new Date().toLocaleDateString("fr-FR")}`, 140, 30);
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold"); doc.text("Vendu par:", 20, 45);
  doc.setFont("helvetica", "normal");
  doc.text("BotaniK Labs", 20, 52); doc.text("France", 20, 59);
  doc.setFont("helvetica", "bold"); doc.text("Facturé à:", 120, 45);
  doc.setFont("helvetica", "normal");
  doc.text(order.customerName || "Client Bloom", 120, 52);
  doc.text(order.email || "", 120, 59);
  doc.text(order.address || "", 120, 66);
  let y = 85;
  doc.setFont("helvetica", "bold");
  doc.text("Produit", 20, y); doc.text("Qté", 120, y); doc.text("Prix Unit.", 140, y); doc.text("Total", 170, y);
  doc.line(20, y + 2, 190, y + 2); y += 10;
  doc.setFont("helvetica", "normal");
  (order.items || []).forEach((item: any) => {
    doc.text(String(item.name), 20, y);
    doc.text(String(item.quantity), 120, y);
    doc.text(`${Number(item.price).toFixed(2)} €`, 140, y);
    doc.text(`${(Number(item.price) * Number(item.quantity)).toFixed(2)} €`, 170, y);
    y += 8;
  });
  y += 5;
  doc.line(120, y, 190, y); y += 10;
  doc.text("Sous-total:", 120, y);
  doc.text(`${(Number(order.total) - Number(order.shippingPrice)).toFixed(2)} €`, 170, y);
  y += 8;
  doc.text("Livraison:", 120, y);
  doc.text(`${Number(order.shippingPrice).toFixed(2)} €`, 170, y);
  y += 10;
  doc.setFontSize(14); doc.setFont("helvetica", "bold");
  doc.text("TOTAL:", 120, y);
  doc.text(`${Number(order.total).toFixed(2)} €`, 170, y);
  doc.setFontSize(10); doc.setFont("helvetica", "italic");
  doc.text("Merci de votre confiance. Faites fleurir votre bien-être.", 20, 270);
  doc.text("Facture acquittée - Paiement sécurisé via Stripe", 20, 277);
  return Buffer.from(doc.output("arraybuffer"));
}

/* ----------------------------------------------------------------------------
 * PAIEMENT RÉUSSI — EMAILS RÉSILIENTS (allSettled)
 * -------------------------------------------------------------------------- */
async function handleSuccessfulPayment(orderData: any, orderId: string) {
  const firestore = getDb();
  await firestore.collection("orders").doc(orderId).update({
    status: "paid",
    updatedAt: new Date().toISOString(),
  });
  const userRef = firestore.collection("users").doc(orderData.userId);
  const premiumUntil = new Date();
  premiumUntil.setMonth(premiumUntil.getMonth() + 1);
  await userRef.set({
    status: "premium",
    isPremiumUntil: premiumUntil.toISOString(),
    updatedAt: new Date().toISOString(),
  }, { merge: true });

  const pdfBuffer = await generateInvoicePDF(orderData, orderId);

  /* Résilience : un échec d'email ne bloque PAS le reste */
  await Promise.allSettled([
    transporter.sendMail({
      from: `"Bloom by BotaniK" <${process.env.SMTP_USER}>`,
      to: orderData.email,
      subject: `Confirmation de votre commande ${orderId} - Bloom by BotaniK`,
      text: `Bonjour,\n\nMerci pour votre confiance ! Votre commande ${orderId} est bien validée.\n\nVous trouverez votre facture en pièce jointe.\n\nCADEAU : votre accès Premium d'un mois est activé (3 bibliothèques : Atelier Culinaire, Soin Cosmétique, Reset Homéostasique).\n\nL'équipe Bloom`,
      attachments: [{ filename: `Facture-${orderId}.pdf`, content: pdfBuffer }],
    }),
    transporter.sendMail({
      from: `"Système de Commande" <${process.env.SMTP_USER}>`,
      to: ADMIN_EMAIL,
      subject: `URGENT - NOUVELLE COMMANDE ${orderId}`,
      text: `Client : ${orderData.customerName} (${orderData.email})\nID : ${orderId}\nTotal : ${Number(orderData.total).toFixed(2)} €\nLivraison : ${orderData.shippingMethod}\nAdresse : ${orderData.address}\n\nItems :\n${(orderData.items || []).map((i: any) => `- ${i.name} x${i.quantity}`).join("\n")}\n\nAction requise : préparer l'expédition.`,
      attachments: [{ filename: `Facture-${orderId}.pdf`, content: pdfBuffer }],
    }),
    notifyOrderToBrevo(orderData),
  ]);
}

/* ----------------------------------------------------------------------------
 * ROUTES APPLICATIVES
 * -------------------------------------------------------------------------- */
function registerAppRoutes(app: express.Express) {
  /* --- Statiques & favicon --- */
  app.get("/favicon.ico", (req, res) => {
    const p = path.join(process.cwd(), "public", "favicon.ico");
    if (fs.existsSync(p)) {
      res.setHeader("Content-Type", "image/x-icon");
      res.setHeader("Cache-Control", "public, max-age=86400, s-maxage=604800");
      return res.sendFile(p);
    }
    res.status(404).end();
  });
  app.get(["/apple-touch-icon.png", "/favicon-48x48.png", "/favicon-96x96.png", "/favicon-192x192.png"], (req, res) => {
    const p = path.join(process.cwd(), "public", path.basename(req.path));
    if (fs.existsSync(p)) {
      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "public, max-age=86400, s-maxage=604800");
      return res.sendFile(p);
    }
    res.status(404).end();
  });

  const distAssets = path.join(process.cwd(), "dist", "assets");
  if (fs.existsSync(distAssets)) {
    app.use("/assets", express.static(distAssets, { maxAge: "1y", immutable: true }));
  }
  app.use("/assets", express.static(path.join(process.cwd(), "public", "assets"), { maxAge: "7d", immutable: true }));
  app.use("/images", express.static(path.join(process.cwd(), "public", "images"), { maxAge: "7d" }));
  app.use("/img", express.static(path.join(process.cwd(), "public", "img"), { maxAge: "30d" }));
  app.use("/products", express.static(path.join(process.cwd(), "public", "products"), { maxAge: "30d" }));
  app.use(express.static(path.join(process.cwd(), "public"), { maxAge: "1d", index: false }));

  app.get(["/blog/vieillissement-myeline-fgf17-clarte-mentale", "/blog/vieillissement-myeline-fgf17-clarte-mentale/", "/blog/vieillissement-myeline-fgf17-clarte-mentale.html", "/blog/vieillissement-myeline-fgf17.html", "/blog/vieillissement-myeline-fgf17/index.html"], (req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "blog", "vieillissement-myeline-fgf17-clarte-mentale.html"));
  });
  app.get(["/protocoles/clarte-mentale", "/protocoles/clarte-mentale/", "/protocoles/clarte-mentale.html", "/protocoles/myeline.html", "/protocoles/myeline/index.html"], (req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "protocoles", "clarte-mentale.html"));
  });

  /* --- Sitemaps & robots & feed --- */
  app.get("/sitemap.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap.xml")); });
  app.get("/sitemap-recettes.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap-recettes.xml")); });
  app.get("/sitemap-images.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap-images.xml")); });
  app.get("/sitemap-fr.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap-fr.xml")); });
  app.get("/sitemap-en.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap-en.xml")); });
  app.get("/sitemap-de.xml", (req, res) => { res.header("Content-Type", "application/xml"); res.sendFile(path.join(process.cwd(), "public", "sitemap-de.xml")); });
  app.get("/robots.txt", (req, res) => { res.header("Content-Type", "text/plain"); res.sendFile(path.join(process.cwd(), "public", "robots.txt")); });
  app.get("/feed/google-merchant.xml", (req, res) => {
    res.header("Content-Type", "application/xml; charset=utf-8");
    res.header("Cache-Control", "public, max-age=3600");
    res.sendFile(path.join(process.cwd(), "public", "feed", "google-merchant.xml"));
  });

  /* --- REDIRECTIONS 301 (host-gated + garde anti-boucle + no-store) --- */
  const redirects301: Record<string, string> = {
    "/bloomlab-extracteur-botanique-et-infuseur-dhuile-intelligent-6-en-1": "/bloomlab/",
    "/boutique/bloomlab": "/bloomlab/",
    "/produit/bloomlab": "/bloomlab/",
    "/infuseur-botanique": "/bloomlab/",
    "/guide-complet-extraction-botanique-maison": "/extraction-botanique/",
    "/remedes-naturels-maison-guide": "/remedes-naturels/",
    "/retours-et-remboursements": "/retour-et-remboursement/",
    "/tisane-bain-marie-bloomlab-quelle-methode-pour-extraire-vraiment-les-bienfaits-de-vos-plantes-spoiler-la-difference-est-de-1-a-98": "/blog/tisane-bain-marie-bloomlab-quelle-methode-pour-extraire-vraiment-les-bienfaits-de-vos-plantes-spoiler-la-difference-est-de-1-a-98/",
    "/chroniques": "/blog/",
    "/infusion-botanique": "/infusion-botanique-maison-comment-ca-marche/",
    "/qu-est-ce-que-l-infusion-botanique": "/infusion-botanique-maison-comment-ca-marche/",
    "/atelier-culinaire": "/gastronomie-botanique/",
    "/recettes-culinaires": "/recettes/culinaires/",
    "/recettes-cosmetiques": "/recettes/cosmetiques/",
    "/recettes-parcours": "/recettes/parcours-botaniques/",
    "/recettes/01": "/recettes/culinaires/infusion-sommeil-profond/",
    "/recettes/02": "/recettes/cosmetiques/huile-massage-articulaire/",
    "/recettes/03": "/recettes/cosmetiques/serum-visage-eclat-botanique/",
    "/recettes/04": "/recettes/cosmetiques/baume-levres-calendula/",
    "/recettes/05": "/recettes/parcours-botaniques/teinture-propolis-maison/",
    "/recettes/06": "/recettes/culinaires/sirop-sureau-immunite/",
    "/recettes/07": "/recettes/parcours-botaniques/decoction-detox-soutien-hepatique/",
    "/recettes/08": "/recettes/parcours-botaniques/elixir-regulateur-metabolique/",
    "/recettes/09": "/recettes/culinaires/infusion-drainage-elimination/",
    "/recettes/10": "/recettes/parcours-botaniques/remede-psoriasis-emonctoires-regulation/",
    "/recettes/11": "/recettes/parcours-botaniques/remede-eczema-desamorcage-histaminique/",
    "/recettes/12": "/recettes/cosmetiques/soin-alopecie-anti-dht-matrice-folliculaire/",
    "/cosmetique-botanique": "/cosmetiques-naturels-diy/",
    "/indexbis": "/",
    "/about": "/manifeste/",
    "/contact": "/manifeste/",
    "/how-it-works-diy-natural-recipes": "/boutique/",
    "/natural-herbal-infusion-body-care-oils-": "/cosmetiques-naturels-diy/",
    "/natural-herbal-infusion-face-skincare-recipes": "/cosmetiques-naturels-diy/",
    "/extraction-plantes-naturelles-bienfaits": "/extraction-botanique/",
    "/extraction-botanique-guide-complet": "/extraction-botanique/",
    "/machine": "/bloomlab/",
    "/herbier": "/academie/herbier/",
    "/bibliotheque": "/academie/bibliotheque/",
    "/bibliotheque-savoirs": "/academie/bibliotheque/",
    "/boutique/kit-reset": "/boutique/duo-argiles/",
    "/boutique/seve-fondamentale": "/boutique/kit-starter/",
    "/boutique/nuit-profonde": "/boutique/kit-nuit/",
    "/boutique/confort-digestif": "/boutique/kit-digestion/",
    "/boutique/digestion": "/boutique/kit-digestion/",
    "/boutique/feu-articulaire": "/boutique/kit-articulaire/",
    "/boutique/bouclier-hiver": "/boutique/kit-hiver/",
    "/boutique/kit-bouclier-hiver": "/boutique/kit-hiver/",
    "/boutique/herbier-complet-rentree-2026": "/boutique/bundle-apothicaire/",
    "/shop": "/boutique/",
    "/products": "/boutique/",
    "/herboristerie": "/academie/herbier/",
    "/phytotherapie": "/academie/reset-homeostasique/",
    "/phytotherapie-reset": "/academie/reset-homeostasique/",
    "/phytotherapie-reset/protocole-psoriasis": "/academie/protocoles/psoriasis/",
    "/phytotherapie-reset/protocole-sibo": "/academie/protocoles/sibo/",
    "/phytotherapie-reset/protocole-myeline": "/academie/protocoles/clarte-mentale/",
    "/protocoles/psoriasis": "/academie/protocoles/psoriasis/",
    "/protocoles/sibo": "/academie/protocoles/sibo/",
    "/protocoles/clarte-mentale": "/academie/protocoles/clarte-mentale/",
    "/comprendre-le-modele-bloom": "/academie/",
    "/academie/comprendre-le-modele-bloom": "/academie/",
    "/academie/comprendre-le-corps/comment-lire-le-modele-bloom": "/academie/",
    "/abonnement": "/abonnement/",
    "/herbier/phytotherapie": "/academie/reset-homeostasique/",
    "/herbier/phytotherapie/": "/academie/reset-homeostasique/",
    "/herbier/therapeutic": "/academie/reset-homeostasique/",
    "/herbier/therapeutic/": "/academie/reset-homeostasique/",
    "/herbier/cosmetique": "/cosmetiques-naturels-diy/",
    "/herbier/cosmetique/": "/cosmetiques-naturels-diy/",
    "/herbier/cosmetiques": "/cosmetiques-naturels-diy/",
    "/herbier/cosmetiques/": "/cosmetiques-naturels-diy/",
    "/herbier/culinaire": "/gastronomie-botanique/",
    "/herbier/culinaire/": "/gastronomie-botanique/",
    "/herbier/chaga_vitality": "/academie/herbier/chaga_vitality/",
    "/herbier/urtica_dioica": "/academie/herbier/urtica_dioica/",
    "/herbier/melissa_officinalis": "/academie/herbier/melissa_officinalis/",
    "/herbier/curcuma_longa_poivre": "/academie/herbier/curcuma_longa_poivre/",
    "/herbier/zingiber_officinale": "/academie/herbier/zingiber_officinale/",
    "/herbier/rosmarinus_officinalis": "/academie/herbier/rosmarinus_officinalis/",
    "/herbier/lavandula_angustifolia": "/academie/herbier/lavandula_angustifolia/",
    "/herbier/artichaut": "/academie/herbier/artichaut/",
    "/bibliotheque/chaga_vitality": "/academie/herbier/chaga_vitality/",
    "/bibliotheque/urtica_dioica": "/academie/herbier/urtica_dioica/",
    "/bibliotheque/melissa_officinalis": "/academie/herbier/melissa_officinalis/",
    "/bibliotheque/curcuma_longa_poivre": "/academie/herbier/curcuma_longa_poivre/",
    "/bibliotheque/zingiber_officinale": "/academie/herbier/zingiber_officinale/",
    "/bibliotheque/rosmarinus_officinalis": "/academie/herbier/rosmarinus_officinalis/",
    "/bibliotheque/lavandula_angustifolia": "/academie/herbier/lavandula_angustifolia/",
    "/bibliotheque/artichaut": "/academie/herbier/artichaut/",
    "/bibliotheque-savoirs/chaga_vitality": "/academie/herbier/chaga_vitality/",
    "/bibliotheque-savoirs/urtica_dioica": "/academie/herbier/urtica_dioica/",
    "/bibliotheque-savoirs/melissa_officinalis": "/academie/herbier/melissa_officinalis/",
    "/bibliotheque-savoirs/curcuma_longa_poivre": "/academie/herbier/curcuma_longa_poivre/",
    "/bibliotheque-savoirs/zingiber_officinale": "/academie/herbier/zingiber_officinale/",
    "/bibliotheque-savoirs/rosmarinus_officinalis": "/academie/herbier/rosmarinus_officinalis/",
    "/bibliotheque-savoirs/lavandula_angustifolia": "/academie/herbier/lavandula_angustifolia/",
    "/bibliotheque-savoirs/artichaut": "/academie/herbier/artichaut/",
    // --- Lot 1 : Recettes Herbier Prioritaires (>100 impressions GSC 90j) vers URLs canoniques ---
    "/herbier/chaga-diamant-de-la-foret": "/recettes/phytotherapie/chaga-diamant-de-la-foret/",
    "/herbier/cordyceps-l-or-de-l-himalaya": "/recettes/phytotherapie/cordyceps-l-or-de-l-himalaya/",
    "/herbier/hericium-criniere-de-lion": "/recettes/phytotherapie/hericium-criniere-de-lion/",
    "/herbier/reishi-champignon-de-l-immortalite": "/recettes/phytotherapie/reishi-champignon-de-l-immortalite/",
    "/herbier/curcuma-et-poivre-noir": "/recettes/phytotherapie/curcuma-et-poivre-noir/",
    "/herbier/boswellia-encens": "/recettes/phytotherapie/boswellia-encens/",
    "/herbier/safran": "/recettes/phytotherapie/safran/",
    "/herbier/ortie-feuille-et-racine": "/recettes/phytotherapie/ortie-feuille-et-racine/",
    "/herbier/prele-des-champs": "/recettes/phytotherapie/prele-des-champs/",
    "/herbier/gingembre": "/recettes/phytotherapie/gingembre/",
    "/herbier/scutellaire-de-baikal": "/recettes/phytotherapie/scutellaire-de-baikal/",
    "/herbier/rhodiola-rosea": "/recettes/phytotherapie/rhodiola-rosea/",
    "/herbier/griffonia": "/recettes/phytotherapie/griffonia/",
    "/herbier/gentiane-jaune": "/recettes/phytotherapie/gentiane-jaune/",
    "/herbier/radis-noir": "/recettes/phytotherapie/radis-noir/",
    "/herbier/chrysanthellum": "/recettes/phytotherapie/chrysanthellum/",
    "/herbier/desmodium": "/recettes/phytotherapie/desmodium/",
    "/herbier/bardane": "/recettes/phytotherapie/bardane/",
    "/herbier/astragale": "/recettes/phytotherapie/astragale/",
    "/herbier/eleutherocoque": "/recettes/phytotherapie/eleutherocoque/",
    "/herbier/therapeutic/chaga_vitality": "/recettes/phytotherapie/chaga-diamant-de-la-foret/",
    "/herbier/therapeutic/cordyceps_performance": "/recettes/phytotherapie/cordyceps-l-or-de-l-himalaya/",
    "/herbier/therapeutic/hericium_focus": "/recettes/phytotherapie/hericium-criniere-de-lion/",
    "/herbier/therapeutic/reishi_zen": "/recettes/phytotherapie/reishi-champignon-de-l-immortalite/",
    "/herbier/therapeutic/curcuma_longa_poivre": "/recettes/phytotherapie/curcuma-et-poivre-noir/",
    "/herbier/therapeutic/boswellia_serrata": "/recettes/phytotherapie/boswellia-encens/",
    "/herbier/therapeutic/crocus_sativus": "/recettes/phytotherapie/safran/",
    "/herbier/therapeutic/urtica_dioica": "/recettes/phytotherapie/ortie-feuille-et-racine/",
    "/herbier/therapeutic/equisetum_arvense": "/recettes/phytotherapie/prele-des-champs/",
    "/herbier/therapeutic/zingiber_officinale": "/recettes/phytotherapie/gingembre/",
    "/herbier/therapeutic/scutellaria_baicalensis": "/recettes/phytotherapie/scutellaire-de-baikal/",
    "/herbier/therapeutic/rhodiola_rosea": "/recettes/phytotherapie/rhodiola-rosea/",
    "/herbier/therapeutic/griffonia_simplicifolia": "/recettes/phytotherapie/griffonia/",
    "/herbier/therapeutic/gentiana_lutea": "/recettes/phytotherapie/gentiane-jaune/",
    "/herbier/therapeutic/raphanus_sativus_niger": "/recettes/phytotherapie/radis-noir/",
    "/herbier/therapeutic/chrysanthellum_indicum": "/recettes/phytotherapie/chrysanthellum/",
    "/herbier/therapeutic/desmodium_adscendens": "/recettes/phytotherapie/desmodium/",
    "/herbier/therapeutic/arctium_lappa": "/recettes/phytotherapie/bardane/",
    "/herbier/therapeutic/astragalus_membranaceus": "/recettes/phytotherapie/astragale/",
    "/herbier/therapeutic/eleutherococcus_senticosus": "/recettes/phytotherapie/eleutherocoque/",
    // --- Lot 2 : Phytothérapie prioritaire (Terrains T1 à T4) ---
    "/herbier/bacopa": "/recettes/phytotherapie/bacopa/",
    "/herbier/therapeutic-bacopa_monnieri": "/recettes/phytotherapie/bacopa/",
    "/herbier/therapeutic/bacopa_monnieri": "/recettes/phytotherapie/bacopa/",
    "/herbier/bacopa_monnieri": "/recettes/phytotherapie/bacopa/",
    "/herbier/chanvre-industriel-fleurs": "/recettes/phytotherapie/chanvre-industriel-fleurs/",
    "/herbier/therapeutic-cannabis_sativa_fleurs": "/recettes/phytotherapie/chanvre-industriel-fleurs/",
    "/herbier/therapeutic/cannabis_sativa_fleurs": "/recettes/phytotherapie/chanvre-industriel-fleurs/",
    "/herbier/cannabis_sativa_fleurs": "/recettes/phytotherapie/chanvre-industriel-fleurs/",
    "/herbier/plantain-majeur": "/recettes/phytotherapie/plantain-majeur/",
    "/herbier/therapeutic-plantago_major": "/recettes/phytotherapie/plantain-majeur/",
    "/herbier/therapeutic/plantago_major": "/recettes/phytotherapie/plantain-majeur/",
    "/herbier/plantago_major": "/recettes/phytotherapie/plantain-majeur/",
    "/herbier/quassia-amer": "/recettes/phytotherapie/quassia-amer/",
    "/herbier/therapeutic-picrasma_quassioides": "/recettes/phytotherapie/quassia-amer/",
    "/herbier/therapeutic/picrasma_quassioides": "/recettes/phytotherapie/quassia-amer/",
    "/herbier/picrasma_quassioides": "/recettes/phytotherapie/quassia-amer/",
    "/herbier/armoise-annuelle": "/recettes/phytotherapie/armoise-annuelle/",
    "/herbier/therapeutic-artemisia_annua": "/recettes/phytotherapie/armoise-annuelle/",
    "/herbier/therapeutic/artemisia_annua": "/recettes/phytotherapie/armoise-annuelle/",
    "/herbier/artemisia_annua": "/recettes/phytotherapie/armoise-annuelle/",
    "/herbier/nigelle": "/recettes/phytotherapie/nigelle/",
    "/herbier/therapeutic-nigella_sativa": "/recettes/phytotherapie/nigelle/",
    "/herbier/therapeutic/nigella_sativa": "/recettes/phytotherapie/nigelle/",
    "/herbier/nigella_sativa": "/recettes/phytotherapie/nigelle/",
    "/herbier/piloselle": "/recettes/phytotherapie/piloselle/",
    "/herbier/therapeutic-hieracium_pilosella": "/recettes/phytotherapie/piloselle/",
    "/herbier/therapeutic/hieracium_pilosella": "/recettes/phytotherapie/piloselle/",
    "/herbier/hieracium_pilosella": "/recettes/phytotherapie/piloselle/",
    "/herbier/mauve": "/recettes/phytotherapie/mauve/",
    "/herbier/therapeutic-malva_sylvestris": "/recettes/phytotherapie/mauve/",
    "/herbier/therapeutic/malva_sylvestris": "/recettes/phytotherapie/mauve/",
    "/herbier/malva_sylvestris": "/recettes/phytotherapie/mauve/",
    "/herbier/moringa": "/recettes/phytotherapie/moringa/",
    "/herbier/therapeutic-moringa_oleifera": "/recettes/phytotherapie/moringa/",
    "/herbier/therapeutic/moringa_oleifera": "/recettes/phytotherapie/moringa/",
    "/herbier/moringa_oleifera": "/recettes/phytotherapie/moringa/",
    "/herbier/ail-vieilli-ou-noir": "/recettes/phytotherapie/ail-vieilli-ou-noir/",
    "/herbier/therapeutic-allium_sativum": "/recettes/phytotherapie/ail-vieilli-ou-noir/",
    "/herbier/therapeutic/allium_sativum": "/recettes/phytotherapie/ail-vieilli-ou-noir/",
    "/herbier/allium_sativum": "/recettes/phytotherapie/ail-vieilli-ou-noir/",
    "/herbier/aubepine": "/recettes/phytotherapie/aubepine/",
    "/herbier/therapeutic-crataegus_monogyna": "/recettes/phytotherapie/aubepine/",
    "/herbier/therapeutic/crataegus_monogyna": "/recettes/phytotherapie/aubepine/",
    "/herbier/crataegus_monogyna": "/recettes/phytotherapie/aubepine/",
    "/herbier/quinquina-rouge": "/recettes/phytotherapie/quinquina-rouge/",
    "/herbier/therapeutic-cinchona_succirubra": "/recettes/phytotherapie/quinquina-rouge/",
    "/herbier/therapeutic/cinchona_succirubra": "/recettes/phytotherapie/quinquina-rouge/",
    "/herbier/cinchona_succirubra": "/recettes/phytotherapie/quinquina-rouge/",
    "/herbier/pissenlit": "/recettes/phytotherapie/pissenlit/",
    "/herbier/therapeutic-taraxacum_officinale": "/recettes/phytotherapie/pissenlit/",
    "/herbier/therapeutic/taraxacum_officinale": "/recettes/phytotherapie/pissenlit/",
    "/herbier/taraxacum_officinale": "/recettes/phytotherapie/pissenlit/",
    "/herbier/melisse": "/recettes/phytotherapie/melisse/",
    "/herbier/passiflore": "/recettes/phytotherapie/passiflore/",
    "/herbier/therapeutic-passiflora_incarnata": "/recettes/phytotherapie/passiflora/",
    "/herbier/therapeutic/passiflora_incarnata": "/recettes/phytotherapie/passiflore/",
    "/herbier/passiflora_incarnata": "/recettes/phytotherapie/passiflore/",
    "/herbier/valeriane": "/recettes/phytotherapie/valeriane/",
    "/herbier/therapeutic-valeriana_officinalis": "/recettes/phytotherapie/valeriane/",
    "/herbier/therapeutic/valeriana_officinalis": "/recettes/phytotherapie/valeriane/",
    "/herbier/valeriana_officinalis": "/recettes/phytotherapie/valeriane/",
    "/herbier/eschscholtzia": "/recettes/phytotherapie/eschscholtzia/",
    "/herbier/therapeutic-eschscholzia_californica": "/recettes/phytotherapie/eschscholtzia/",
    "/herbier/therapeutic/eschscholzia_californica": "/recettes/phytotherapie/eschscholtzia/",
    "/herbier/eschscholzia_californica": "/recettes/phytotherapie/eschscholtzia/",
    "/herbier/romarin": "/recettes/phytotherapie/romarin/",
    "/herbier/lavande": "/recettes/phytotherapie/lavande/",
    "/herbier/artichaut": "/recettes/phytotherapie/artichaut/",
    "/herbier/therapeutic-artichaut": "/recettes/phytotherapie/artichaut/",
    "/herbier/therapeutic/artichaut": "/recettes/phytotherapie/artichaut/",
    // --- Lot 3 : Phytothérapie secondaire (Terrains T5 à T8) ---
    "/herbier/ginkgo": "/recettes/phytotherapie/ginkgo/",
    "/herbier/therapeutic-ginkgo_biloba": "/recettes/phytotherapie/ginkgo/",
    "/herbier/therapeutic/ginkgo_biloba": "/recettes/phytotherapie/ginkgo/",
    "/herbier/ginkgo_biloba": "/recettes/phytotherapie/ginkgo/",
    "/herbier/fenugrec": "/recettes/phytotherapie/fenugrec/",
    "/herbier/therapeutic-trigonella_foenum_graecum": "/recettes/phytotherapie/fenugrec/",
    "/herbier/therapeutic/trigonella_foenum_graecum": "/recettes/phytotherapie/fenugrec/",
    "/herbier/trigonella_foenum_graecum": "/recettes/phytotherapie/fenugrec/",
    "/herbier/renouee-du-japon-racine": "/recettes/phytotherapie/renouee-du-japon-racine/",
    "/herbier/therapeutic-reynoutria_japonica": "/recettes/phytotherapie/renouee-du-japon-racine/",
    "/herbier/therapeutic/reynoutria_japonica": "/recettes/phytotherapie/renouee-du-japon-racine/",
    "/herbier/reynoutria_japonica": "/recettes/phytotherapie/renouee-du-japon-racine/",
    "/herbier/euphraise": "/recettes/phytotherapie/euphraise/",
    "/herbier/therapeutic-euphrasia_officinalis": "/recettes/phytotherapie/euphraise/",
    "/herbier/therapeutic/euphrasia_officinalis": "/recettes/phytotherapie/euphraise/",
    "/herbier/euphrasia_officinalis": "/recettes/phytotherapie/euphraise/",
    "/herbier/myrtille": "/recettes/phytotherapie/myrtille/",
    "/herbier/therapeutic-vaccinium_myrtillus": "/recettes/phytotherapie/myrtille/",
    "/herbier/therapeutic/vaccinium_myrtillus": "/recettes/phytotherapie/myrtille/",
    "/herbier/vaccinium_myrtillus": "/recettes/phytotherapie/myrtille/",
    "/herbier/maca": "/recettes/phytotherapie/maca/",
    "/herbier/therapeutic-lepidium_meyenii": "/recettes/phytotherapie/maca/",
    "/herbier/therapeutic/lepidium_meyenii": "/recettes/phytotherapie/maca/",
    "/herbier/lepidium_meyenii": "/recettes/phytotherapie/maca/",
    "/herbier/alchemille": "/recettes/phytotherapie/alchemille/",
    "/herbier/therapeutic-alchemilla_vulgaris": "/recettes/phytotherapie/alchemille/",
    "/herbier/therapeutic/alchemilla_vulgaris": "/recettes/phytotherapie/alchemille/",
    "/herbier/alchemilla_vulgaris": "/recettes/phytotherapie/alchemille/",
    "/herbier/gattilier-vitex": "/recettes/phytotherapie/gattilier-vitex/",
    "/herbier/therapeutic-vitex_agnus_castus": "/recettes/phytotherapie/gattilier-vitex/",
    "/herbier/therapeutic/vitex_agnus_castus": "/recettes/phytotherapie/gattilier-vitex/",
    "/herbier/vitex_agnus_castus": "/recettes/phytotherapie/gattilier-vitex/",
    "/herbier/shatavari": "/recettes/phytotherapie/shatavari/",
    "/herbier/therapeutic-asparagus_racemosus": "/recettes/phytotherapie/shatavari/",
    "/herbier/therapeutic/asparagus_racemosus": "/recettes/phytotherapie/shatavari/",
    "/herbier/asparagus_racemosus": "/recettes/phytotherapie/shatavari/",
    "/herbier/hamamelis": "/recettes/phytotherapie/hamamelis/",
    "/herbier/therapeutic-hamamelis_virginiana": "/recettes/phytotherapie/hamamelis/",
    "/herbier/therapeutic/hamamelis_virginiana": "/recettes/phytotherapie/hamamelis/",
    "/herbier/hamamelis_virginiana": "/recettes/phytotherapie/hamamelis/",
    "/herbier/saule-blanc": "/recettes/phytotherapie/saule-blanc/",
    "/herbier/therapeutic-salix_alba": "/recettes/phytotherapie/saule-blanc/",
    "/herbier/therapeutic/salix_alba": "/recettes/phytotherapie/saule-blanc/",
    "/herbier/salix_alba": "/recettes/phytotherapie/saule-blanc/",
    "/herbier/epine-vinette": "/recettes/phytotherapie/epine-vinette/",
    "/herbier/therapeutic-berberis_vulgaris": "/recettes/phytotherapie/epine-vinette/",
    "/herbier/therapeutic/berberis_vulgaris": "/recettes/phytotherapie/epine-vinette/",
    "/herbier/berberis_vulgaris": "/recettes/phytotherapie/epine-vinette/",
    "/herbier/cassis": "/recettes/phytotherapie/cassis/",
    "/herbier/therapeutic-ribes_nigrum": "/recettes/phytotherapie/cassis/",
    "/herbier/therapeutic/ribes_nigrum": "/recettes/phytotherapie/cassis/",
    "/herbier/ribes_nigrum": "/recettes/phytotherapie/cassis/",
    "/herbier/millepertuis": "/recettes/phytotherapie/millepertuis/",
    "/herbier/therapeutic-millepertuis": "/recettes/phytotherapie/millepertuis/",
    "/herbier/therapeutic/millepertuis": "/recettes/phytotherapie/millepertuis/",
    "/herbier/decoction-detox-soutien-hepatique": "/recettes/phytotherapie/decoction-detox-soutien-hepatique/",
    "/herbier/extra-recipe-07": "/recettes/phytotherapie/decoction-detox-soutien-hepatique/",
    "/herbier/elixir-regulateur-metabolique": "/recettes/phytotherapie/elixir-regulateur-metabolique/",
    "/herbier/extra-recipe-08": "/recettes/phytotherapie/elixir-regulateur-metabolique/",
    "/herbier/infusion-drainage-elimination": "/recettes/phytotherapie/infusion-drainage-elimination/",
    "/herbier/extra-recipe-09": "/recettes/phytotherapie/infusion-drainage-elimination/",
    "/herbier/remede-psoriasis-emonctoires-regulation-epidermique": "/recettes/phytotherapie/remede-psoriasis-emonctoires-regulation-epidermique/",
    "/herbier/extra-recipe-10": "/recettes/phytotherapie/remede-psoriasis-emonctoires-regulation-epidermique/",
    "/herbier/remede-eczema-desamorcage-histaminique-barriere": "/recettes/phytotherapie/remede-eczema-desamorcage-histaminique-barriere/",
    "/herbier/extra-recipe-11": "/recettes/phytotherapie/remede-eczema-desamorcage-histaminique-barriere/",
    "/herbier/remede-alopecie-anti-dht-matrice-folliculaire": "/recettes/phytotherapie/remede-alopecie-anti-dht-matrice-folliculaire/",
    "/herbier/extra-recipe-12": "/recettes/phytotherapie/remede-alopecie-anti-dht-matrice-folliculaire/",
    "/herbier/gastronomie": "/recettes/gastronomie/",
    "/herbier/gastronomie/": "/recettes/gastronomie/",
  };

  Object.entries(redirects301).forEach(([from, to]) => {
    const handleRedirect = (target: string) => (req: express.Request, res: express.Response, next: express.NextFunction) => {
      if (!isCanonicalHost(req.get("host") || "")) return next();
      const current = req.path;
      if (current === target || current === `${target}/` || `${current}/` === target) return next();
      res.set("Cache-Control", "no-store");
      res.redirect(301, target);
    };
    app.get(from, handleRedirect(to));
    app.get(`/en${from}`, handleRedirect(`/en${to}`));
    app.get(`/de${from}`, handleRedirect(`/de${to}`));
  });

  /* --- NEWSLETTER --- */
  app.post("/api/newsletter/subscribe", createRateLimiter(60_000, 10), async (req, res) => {
    try {
      const { email, firstName, source } = req.body || {};
      if (!email) return res.status(400).json({ error: "Email requis" });
      const firestore = getDb();
      const normalized = String(email).toLowerCase().trim();
      const existing = await firestore.collection("subscribers").where("email", "==", normalized).get();
      let subscriberId: string;
      if (existing.empty) {
        const created = await firestore.collection("subscribers").add({
          email: normalized,
          first_name: firstName || "",
          locale: "fr-FR",
          marketing_consent: false,
          consent_source: source || "footer_form",
          email_status: "active",
          preferences: { family_rhythm: false, school_calendar_zone: "non_precise", content_context: ["routine_personnelle"] },
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
        subscriberId = created.id;
      } else {
        subscriberId = existing.docs[0].id;
      }
      const confirmLink = `https://${req.get("host")}/api/newsletter/confirm?id=${subscriberId}`;
      console.log("[Newsletter] Confirmation à envoyer :", normalized, confirmLink);
      res.json({ success: true, subscriberId, message: "Email de confirmation envoyé" });
    } catch (error: any) {
      console.error("[Newsletter] subscribe error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/newsletter/confirm", async (req, res) => {
    try {
      const { id } = req.query;
      if (!id) return res.status(400).send("ID manquant");
      const ref = getDb().collection("subscribers").doc(id as string);
      const doc = await ref.get();
      if (!doc.exists) return res.status(404).send("Abonné non trouvé");
      await ref.update({ marketing_consent: true, consent_timestamp: new Date().toISOString(), updated_at: new Date().toISOString() });
      res.send("<h1>Inscription confirmée !</h1><p>Merci d'avoir rejoint la communauté Bloom. Vous pouvez fermer cette page.</p>");
    } catch {
      res.status(500).send("Erreur lors de la confirmation");
    }
  });

  app.get("/api/newsletter/unsubscribe", async (req, res) => {
    try {
      const { id } = req.query;
      if (!id) return res.status(400).send("ID manquant");
      await getDb().collection("subscribers").doc(id as string).update({
        marketing_consent: false, email_status: "unsubscribed", updated_at: new Date().toISOString(),
      });
      res.send("<h1>Désinscription réussie</h1><p>Vous ne recevrez plus de newsletters de notre part.</p>");
    } catch {
      res.status(500).send("Erreur lors de la désinscription");
    }
  });

  /* --- NEWSLETTER ADMIN (multi-agent Gemini) — garde admin --- */
  const orchestrator = new NewsletterOrchestrator(process.env.GEMINI_API_KEY!);
  app.post("/api/admin/newsletter/generate", requireAdmin, async (req, res) => {
    try {
      const { season, context_data } = req.body || {};
      const sharedMemory: any = await orchestrator.generateNewsletter({ season, ...(context_data || {}) });
      const firestore = getDb();
      const campaign = await firestore.collection("newsletter_campaigns").add({
        theme: sharedMemory.selected_topic?.selected_topic,
        subject: sharedMemory.editorial_draft?.subject,
        preheader: sharedMemory.editorial_draft?.preheader,
        html_content: sharedMemory.html_output?.html,
        text_content: sharedMemory.html_output?.plain_text,
        status: sharedMemory.quality_report?.status === "pass" ? "review" : "draft",
        quality_report: sharedMemory.quality_report,
        target_segments: sharedMemory.selected_topic?.target_segments || [],
        created_by: "agent",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      await firestore.collection("newsletter_generation_sessions").add({
        campaign_id: campaign.id,
        status: "review",
        shared_memory: sharedMemory,
        risk_level: (sharedMemory.quality_report?.score ?? 100) < 80 ? "medium" : "low",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      res.json({ success: true, campaignId: campaign.id, sharedMemory });
    } catch (error: any) {
      console.error("[Newsletter] generate error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/newsletter/approve", requireAdmin, async (req, res) => {
    try {
      const { campaignId } = req.body || {};
      if (!campaignId) return res.status(400).json({ error: "Campaign ID requis" });
      await getDb().collection("newsletter_campaigns").doc(campaignId).update({
        status: "approved", approved_by: ADMIN_EMAIL, updated_at: new Date().toISOString(),
      });
      res.json({ success: true, message: "Campagne approuvée" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  /* --- CHAT ALMA --- */
  app.post("/api/chat", createRateLimiter(60_000, 30), async (req, res) => {
    try {
      const { message, history, userId, anonymousSessionId, language, pageUrl } = req.body || {};
      if (!process.env.GEMINI_API_KEY) return res.status(500).json({ error: "Configuration API Key manquante" });
      if (!message) return res.status(400).json({ error: "Missing message" });
      const contents = [
        ...(history || []).map((h: any) => ({ role: h.role === "user" ? "user" : "model", parts: [{ text: h.text }] })),
        { role: "user", parts: [{ text: message }] },
      ];
      const result = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents,
        config: { systemInstruction: BOT_SYSTEM_INSTRUCTION, responseMimeType: "application/json" },
      });
      const responseText = (result as any).text || "{}";
      let data: any;
      try { data = JSON.parse(responseText); }
      catch { data = { answer: responseText, concern: {} }; }
      try {
        await getDb().collection("customer_concerns").add({
          ...(data.concern || {}),
          userId: userId || null,
          anonymousSessionId: anonymousSessionId || null,
          userQuestion: message,
          answerSummary: data.answer ? String(data.answer).substring(0, 500) : "",
          language: language || "fr",
          pageUrl: pageUrl || "",
          createdAt: new Date().toISOString(),
        });
      } catch (e) { console.error("[Chat] Firestore log error:", e); }
      res.json({ text: data.answer || "Désolé, je rencontre une difficulté technique.", concern: data.concern });
    } catch (error: any) {
      console.error("[Chat] error:", error);
      res.status(500).json({ error: "Une erreur est survenue lors de la communication avec Alma." });
    }
  });

  /* --- ACTIVATION BLOOMLAB (vision Gemini) --- */
  app.post("/api/activate-bloomlab", createRateLimiter(60_000, 5), upload.single("invoice") as any, async (req: express.Request, res: express.Response) => {
    try {
      const { userId } = req.body || {};
      const file = req.file;
      if (!userId || !file) return res.status(400).json({ error: "Missing userId or invoice file" });
      const imagePart = { inlineData: { mimeType: file.mimetype, data: file.buffer.toString("base64") } };
      const prompt = `Tu es un expert comptable et un vérificateur de commandes e-commerce.
Analyse l'image/PDF de la facture jointe et extrais UNIQUEMENT les données suivantes au format JSON strict :
{
  "numero_commande": "string",
  "date_facture": "YYYY-MM-DD",
  "nom_produit": "string",
  "montant_total": number,
  "est_bloomlab": boolean
}
RÈGLES DE VÉRIFICATION STRICTES :
- "est_bloomlab" est TRUE uniquement si le nom du produit contient EXACTEMENT "BloomLab" ou "Pack Souveraineté".
- "est_bloomlab" est FALSE si c'est un kit de plantes, un binder ou un accessoire seul.
- Si la date est supérieure à 30 jours par rapport à aujourd'hui, ajoute un champ "offre_expiree": true.
- Ne retourne AUCUN texte explicatif, uniquement le JSON valide.`;
      const result = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: [{ parts: [imagePart, { text: prompt }] }],
        config: { responseMimeType: "application/json" },
      });
      const analysis: any = JSON.parse((result as any).text || "{}");
      if (analysis.est_bloomlab && !analysis.offre_expiree) {
        const firestore = getDb();
        const userRef = firestore.collection("users").doc(userId);
        const userDoc = await userRef.get();
        if (!userDoc.exists) return res.status(404).json({ error: "Utilisateur non trouvé dans la base de données." });
        const isPremiumUntil = new Date();
        isPremiumUntil.setMonth(isPremiumUntil.getMonth() + 1);
        await userRef.update({
          status: "premium",
          isPremiumUntil: isPremiumUntil.toISOString(),
          machineOwned: true,
          updatedAt: new Date().toISOString(),
        });
        const userEmail = userDoc.data()?.email || userId;
        await transporter.sendMail({
          from: `"Bloom Assistant" <${process.env.SMTP_USER}>`,
          to: ADMIN_EMAIL,
          subject: `[Activation BloomLab] Nouvelle facture déposée - ${analysis.numero_commande}`,
          text: `Utilisateur: ${userEmail}\nCommande: ${analysis.numero_commande}\nDate Facture: ${analysis.date_facture}\nProduit: ${analysis.nom_produit}\nMontant: ${analysis.montant_total}\nValide: ${analysis.est_bloomlab}`,
          attachments: [{ filename: file.originalname, content: file.buffer }],
        }).catch((e) => console.error("[Activation] email error:", e));
        await firestore.collection("interactions").add({
          userId, type: "activation_bloomlab", metadata: analysis, createdAt: new Date().toISOString(),
        });
        return res.json({ success: true, analysis });
      }
      let message = "La facture ne correspond pas à une BloomLab valide.";
      if (analysis.offre_expiree) message = "Cette offre a expiré (achat de plus de 30 jours).";
      return res.status(400).json({ success: false, message, analysis });
    } catch (error: any) {
      console.error("[Activation] error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  /* --- CHECKOUT STRIPE --- */
  app.post("/api/checkout/create-payment-intent", createRateLimiter(60_000, 20), async (req, res) => {
    try {
      const { cart, shippingMethod, formData, userId, userEmail } = req.body || {};
      if (!cart || !userId || !userEmail) return res.status(400).json({ error: "Données de commande incomplètes" });
      let subtotal = 0;
      const validatedItems = cart.map((item: any) => {
        const officialPrice = PRODUCT_PRICES[item.id] ?? item.price;
        subtotal += officialPrice * (item.quantity || 1);
        return { id: item.id, name: item.name, price: officialPrice, quantity: item.quantity || 1 };
      });
      const shippingPrice = getShippingPrice(shippingMethod, validatedItems);
      const total = subtotal + shippingPrice;
      const firestore = getDb();
      const orderId = `BLM-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      await firestore.collection("orders").doc(orderId).set({
        userId, email: userEmail,
        customerName: `${formData?.firstName ?? ""} ${formData?.lastName ?? ""}`.trim(),
        address: `${formData?.address ?? ""}, ${formData?.zipCode ?? ""} ${formData?.city ?? ""}, ${formData?.country ?? ""}`,
        items: validatedItems, shippingMethod, shippingPrice, total,
        status: "pending",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      const paymentIntent = await getStripe().paymentIntents.create({
        amount: Math.round(total * 100),
        currency: "eur",
        metadata: { orderId, userId },
        receipt_email: userEmail,
      });
      res.json({ clientSecret: paymentIntent.client_secret, orderId, total });
    } catch (error: any) {
      console.error("[Checkout] error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  /* --- PAYPAL --- */
  app.post("/api/checkout/paypal/create-order", createRateLimiter(60_000, 20), async (req, res) => {
    try {
      const { cart, shippingMethod, formData, userId, userEmail } = req.body || {};
      let subtotal = 0;
      const validatedItems = cart.map((item: any) => {
        const officialPrice = PRODUCT_PRICES[item.id] ?? item.price;
        subtotal += officialPrice * (item.quantity || 1);
        return { id: item.id, name: item.name, price: officialPrice, quantity: item.quantity || 1 };
      });
      const shippingPrice = getShippingPrice(shippingMethod, validatedItems);
      const total = subtotal + shippingPrice;
      const orderId = `BLM-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      await getDb().collection("orders").doc(orderId).set({
        userId, email: userEmail,
        customerName: `${formData?.firstName ?? ""} ${formData?.lastName ?? ""}`.trim(),
        address: `${formData?.address ?? ""}, ${formData?.zipCode ?? ""} ${formData?.city ?? ""}, ${formData?.country ?? ""}`,
        items: validatedItems, shippingMethod, shippingPrice, total,
        status: "pending",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      res.json({ orderId, total });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/checkout/paypal/capture", createRateLimiter(60_000, 20), async (req, res) => {
    try {
      const { orderId } = req.body || {};
      const orderDoc = await getDb().collection("orders").doc(orderId).get();
      if (orderDoc.exists) await handleSuccessfulPayment(orderDoc.data(), orderId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  /* --- WEBHOOK ACHAT (simulation) — secret partagé requis en prod --- */
  app.post("/api/webhooks/purchase", async (req, res) => {
    const secret = process.env.PURCHASE_WEBHOOK_SECRET;
    if (secret) {
      if (req.get("x-webhook-secret") !== secret) return res.status(401).json({ error: "Unauthorized" });
    } else if (IS_PROD) {
      return res.status(403).json({ error: "Webhook désactivé en production sans secret" });
    }
    try {
      const { email, productId, orderId } = req.body || {};
      if (!email || !productId) return res.status(400).json({ error: "Données manquantes" });
      const firestore = getDb();
      const normalized = String(email).toLowerCase().trim();
      const existing = await firestore.collection("subscribers").where("email", "==", normalized).get();
      let subscriberId: string;
      if (existing.empty) {
        const created = await firestore.collection("subscribers").add({
          email: normalized, marketing_consent: false, email_status: "active",
          created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
        });
        subscriberId = created.id;
      } else subscriberId = existing.docs[0].id;
      const isBloomLab = String(productId).includes("bloomlab");
      const cust = await firestore.collection("customers").where("subscriber_id", "==", subscriberId).get();
      if (cust.empty) {
        await firestore.collection("customers").add({
          subscriber_id: subscriberId,
          bloomlab_purchase_verified: isBloomLab,
          bloomlab_purchase_date: isBloomLab ? new Date().toISOString() : null,
          kit_purchase_verified: !isBloomLab,
          last_purchase_date: new Date().toISOString(),
          purchase_source: "webhook_simulation",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      } else {
        const update: any = { last_purchase_date: new Date().toISOString(), updated_at: new Date().toISOString() };
        if (isBloomLab) { update.bloomlab_purchase_verified = true; update.bloomlab_purchase_date = new Date().toISOString(); }
        else update.kit_purchase_verified = true;
        await cust.docs[0].ref.update(update);
      }
      res.json({ success: true, message: "Achat synchronisé" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
}

/* ----------------------------------------------------------------------------
 * VITE (DEV)
 * -------------------------------------------------------------------------- */
let viteDevServer: any = null;
async function setupVite(app: express.Express) {
  const { createServer: createViteServer } = await import("vite");
  const vite = await createViteServer({
    server: { middlewareMode: true, hmr: false, ws: false, host: "0.0.0.0", cors: true },
    appType: "custom",
    base: "/",
  });
  return vite;
}

/* ----------------------------------------------------------------------------
 * SERVER-SIDE SEO INJECTION (Googlebot & Social Preview Optimization)
 * -------------------------------------------------------------------------- */
interface ServerSEORoute {
  title: string;
  description: string;
  image1200: string;
  image1080: string;
  alt: string;
  type: "website" | "article" | "product";
  price?: string;
  sku?: string;
  isPaywalled?: boolean;
  datePublished?: string;
  dateModified?: string;
}

const SERVER_SEO_ROUTES: Record<string, ServerSEORoute> = {
  "/": {
    title: "Extracteur Botanique BloomLab® | Infusion Précision",
    description: "Découvrez l'extracteur et infuseur botanique de précision BloomLab®. Vortex cinétique et thermorégulation ±0,5°C pour extraire le Totum actif de vos plantes.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "BloomLab® — extracteur et infuseur botanique de précision Bloom by BotaniK en situation",
    type: "website"
  },
  "/bloomlab/": {
    title: "BloomLab® Extracteur Botanique | Totum Végétal Préservé — 239€",
    description: "Extracteur et infuseur botanique BloomLab® : inox chirurgical 304, vortex cinétique, thermorégulation ±0,5°C pour extraire le Totum intégral de vos plantes à la maison.",
    image1200: "/images/og/produit-bloomlab-1200x630.jpg",
    image1080: "/images/og/produit-bloomlab-1080x1080.jpg",
    alt: "Extracteur et infuseur botanique BloomLab® en acier inoxydable 304",
    type: "product",
    price: "239.00",
    sku: "BLOOMLAB-V2"
  },
  "/infuseur-botanique/": {
    title: "Infuseur Botanique Précision | Tisanes Actives BloomLab®",
    description: "Pourquoi choisir un infuseur de précision plutôt qu'une théière ? Extraction douce en chambre close, thermorégulation active et préservation du Totum végétal.",
    image1200: "/images/og/infuseur-botanique-precision-bloomlab-1200x630.jpg",
    image1080: "/images/og/infuseur-botanique-precision-bloomlab-1080x1080.jpg",
    alt: "Infuseur botanique de précision et préparation de tisanes actives",
    type: "article"
  },
  "/extraction-botanique/": {
    title: "Extraction Botanique Guide | Totum & Séquençage A/B",
    description: "Guide complet de l'extraction végétale : extraction hydrothermique, solvants nobles, vortex cinétique et biodisponibilité sans dégradation moléculaire.",
    image1200: "/images/og/extraction-botanique-totum-solvants-1200x630.jpg",
    image1080: "/images/og/extraction-botanique-totum-solvants-1080x1080.jpg",
    alt: "Guide de l'extraction végétale, solvants et Totum botanique",
    type: "article"
  },
  "/infusion-botanique-maison-comment-ca-marche/": {
    title: "Infusion Botanique Maison | Principes Actifs & Méthode",
    description: "Comprendre l'infusion végétale de précision : seuils thermiques, cinétique d'agitation et préservation des molécules actives thermosensibles.",
    image1200: "/images/og/infusion-botanique-maison-extraction-active-1200x630.jpg",
    image1080: "/images/og/infusion-botanique-maison-extraction-active-1080x1080.jpg",
    alt: "Infusion botanique maison et extraction de principes actifs",
    type: "article"
  },
  "/phytotherapie-reset/": {
    title: "Reset Homéostasique | Protocoles Phytothérapie",
    description: "Phytothérapie intégrative et rééquilibrage du terrain : découvrez nos protocoles de reset homéostatique pour soutenir les capacités d'autorégulation.",
    image1200: "/images/og/phytotherapie-reset-homeostasie-terrain-1200x630.jpg",
    image1080: "/images/og/phytotherapie-reset-homeostasie-terrain-1080x1080.jpg",
    alt: "Phytothérapie systémique et protocoles de reset homéostasique",
    type: "article"
  },
  "/totum-vegetal/": {
    title: "Totum Végétal vs Molécules Isolées | Synergie des Plantes",
    description: "Pourquoi le Totum végétal surpasse les isolats : synergie biochimique, biodisponibilité accrue et effet tampon des principes actifs entiers.",
    image1200: "/images/og/totum-vegetal-synergie-plantes-medicinales-1200x630.jpg",
    image1080: "/images/og/totum-vegetal-synergie-plantes-medicinales-1080x1080.jpg",
    alt: "Le Totum végétal en phytothérapie et synergie moléculaire",
    type: "article"
  },
  "/plantes-adaptogenes/": {
    title: "Plantes Adaptogènes | Axe HPA, Cortisol & Résilience",
    description: "Ashwagandha, Rhodiola, Éleuthérocoque : guide pratique des plantes adaptogènes pour moduler le cortisol et soutenir l'axe neuro-endocrinien.",
    image1200: "/images/og/plantes-adaptogenes-axe-hpa-systeme-nerveux-1200x630.jpg",
    image1080: "/images/og/plantes-adaptogenes-axe-hpa-systeme-nerveux-1080x1080.jpg",
    alt: "Plantes adaptogènes pour réguler le stress et l'axe HPA",
    type: "article"
  },
  "/herbier/": {
    title: "Herbier Bloom | Plantes Médicinales & Adaptogènes",
    description: "Herbier interactif Bloom : explorez les monographies botaniques, principes actifs, températures optimales d'extraction et précautions d'usage.",
    image1200: "/images/og/herbier-plantes-medicinales-botanique-1200x630.jpg",
    image1080: "/images/og/herbier-plantes-medicinales-botanique-1080x1080.jpg",
    alt: "Herbier botanique interactif et fiches des plantes médicinales",
    type: "article"
  },
  "/cosmetique-botanique/": {
    title: "Cosmétique Botanique Maison | Macérats Huileux & Baumes",
    description: "Créez vos soins botaniques sur mesure : macérats huileux stables à 45°C, baumes concentrés et sérums actifs sans conservateurs agressifs.",
    image1200: "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    image1080: "/images/og/cosmetique-botanique-macerat-huileux-1080x1080.jpg",
    alt: "Cosmétique botanique maison, huiles de soin et macérats de précision",
    type: "article"
  },
  "/gastronomie-botanique/": {
    title: "Gastronomie Botanique | Huiles Aromatisées & Bouillons",
    description: "Gastronomie botanique de précision : créez des huiles infusées d'exception, vinaigres botaniques et bouillons actifs grâce au vortex cinétique BloomLab.",
    image1200: "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    image1080: "/images/og/gastronomie-botanique-huiles-aromatiques-1080x1080.jpg",
    alt: "Gastronomie botanique, huiles infusées culinaires et bouillons actifs",
    type: "article"
  },
  "/articles/": {
    title: "Articles Savoirs Botaniques | Phytothérapie Maison",
    description: "Explorez tous nos articles d'experts sur l'extraction botanique, la phytothérapie de terrain, les plantes adaptogènes et les macérations de précision.",
    image1200: "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    image1080: "/images/og/articles-savoirs-herboristerie-botanique-1080x1080.jpg",
    alt: "Articles et savoirs botaniques en phytothérapie et herboristerie",
    type: "website"
  },
  "/boutique/": {
    title: "Kits Plantes Médicinales & Remèdes Naturels | Bloom",
    description: "Découvrez notre gamme complète d'herboristerie : extracteur BloomLab, kits de plantes médicinales bio, accessoires d'extraction et abonnements.",
    image1200: "/images/og/boutique-bloomlab-kits-plantes-1200x630.jpg",
    image1080: "/images/og/boutique-bloomlab-kits-plantes-1080x1080.jpg",
    alt: "Boutique officielle Bloom by BotaniK, BloomLab et kits de plantes",
    type: "website"
  },
  "/boutique/kits/": {
    title: "Kits Plantes Médicinales & Remèdes Naturels | Bloom",
    description: "Découvrez notre gamme complète d'herboristerie : extracteur BloomLab, kits de plantes médicinales bio, accessoires d'extraction et abonnements.",
    image1200: "/images/og/boutique-bloomlab-kits-plantes-1200x630.jpg",
    image1080: "/images/og/boutique-bloomlab-kits-plantes-1080x1080.jpg",
    alt: "Boutique officielle Bloom by BotaniK, BloomLab et kits de plantes",
    type: "website"
  },
  "/manifeste/": {
    title: "Manifeste Bloom | Souveraineté Sanitaire & Plantes",
    description: "Manifeste Bloom by BotaniK : souveraineté sanitaire, ingénierie biologique et réconciliation entre rigueur scientifique et sagesse végétale ancestrale.",
    image1200: "/images/og/manifeste-souverainete-sanitaire-botanique-1200x630.jpg",
    image1080: "/images/og/manifeste-souverainete-sanitaire-botanique-1080x1080.jpg",
    alt: "Manifeste Bloom by BotaniK pour la souveraineté botanique et le reset homéostasique",
    type: "article"
  },
  "/questions-frequentes/": {
    title: "FAQ Extracteur Botanique | Questions Fréquentes",
    description: "Foire aux questions BloomLab® : garanties, entretien de l'inox 304, protocoles d'extraction, solvants autorisés et délais d'expédition sous 24 à 48 heures.",
    image1200: "/images/og/questions-frequentes-bloomlab-botanique-1200x630.jpg",
    image1080: "/images/og/questions-frequentes-bloomlab-botanique-1080x1080.jpg",
    alt: "Foire aux questions sur l'infuseur BloomLab et l'extraction végétale",
    type: "website"
  },
  "/faq/": {
    title: "FAQ Extracteur Botanique | Questions Fréquentes",
    description: "Foire aux questions BloomLab® : garanties, entretien de l'inox 304, protocoles d'extraction, solvants autorisés et délais d'expédition sous 24 à 48 heures.",
    image1200: "/images/og/questions-frequentes-bloomlab-botanique-1200x630.jpg",
    image1080: "/images/og/questions-frequentes-bloomlab-botanique-1080x1080.jpg",
    alt: "Foire aux questions sur l'infuseur BloomLab et l'extraction végétale",
    type: "website"
  },
  "/lexique/": {
    title: "Lexique Phytothérapie | Termes Extraction Botanique",
    description: "Lexique de phytothérapie et d'extraction botanique : définitions du Totum, de la charge allostatique, des solvants nobles et du séquençage actif A/B.",
    image1200: "/images/og/lexique-phytotherapie-extraction-botanique-1200x630.jpg",
    image1080: "/images/og/lexique-phytotherapie-extraction-botanique-1080x1080.jpg",
    alt: "Lexique de phytothérapie et termes d'herboristerie",
    type: "article"
  },
  "/contact/": {
    title: "Contact & Assistance Botanique | Bloom by BotaniK",
    description: "Une question sur BloomLab® ou nos kits botaniques ? Contactez nos conseillers en phytothérapie. Équipe basée en France, réponse sous 24 à 48 heures.",
    image1200: "/images/og/contact-bloom-by-botanik-1200x630.jpg",
    image1080: "/images/og/contact-bloom-by-botanik-1080x1080.jpg",
    alt: "Contactez l'équipe Bloom by BotaniK pour vos questions botaniques",
    type: "website"
  },
  "/huile-infusee/": {
    title: "Huiles Infusées Maison | Guide Macération Végétale",
    description: "Guide pratique des huiles infusées : sélection des huiles végétales bio, température de macération à 45°C et extraction des principes actifs liposolubles.",
    image1200: "/images/og/huiles-infusees-maceration-plantes-1200x630.jpg",
    image1080: "/images/og/huiles-infusees-maceration-plantes-1080x1080.jpg",
    alt: "Huiles infusées et macération d'herboristerie maison de précision",
    type: "article"
  },
  "/teinture-mere/": {
    title: "Teinture-Mère Maison | Guide Extraits Hydroalcooliques",
    description: "Fabrication de teintures mères maison : ratios 1:5, choix des titres alcooliques et extraction dynamique par vortex cinétique pour un concentré d'actifs.",
    image1200: "/images/og/teinture-mere-extraits-hydroalcooliques-1200x630.jpg",
    image1080: "/images/og/teinture-mere-extraits-hydroalcooliques-1080x1080.jpg",
    alt: "Guide de la teinture-mère et extraits hydroalcooliques de plantes médicinales",
    type: "article"
  },
  "/terrain/": {
    title: "Les 8 Terrains Biologiques | Équilibre & Homéostasie",
    description: "Explorez les 8 terrains biologiques en phytothérapie systémique : cartographiez vos vulnérabilités et choisissez les synergies de plantes appropriées.",
    image1200: "/images/og/terrain-biologique-equilibre-homeostasie-1200x630.jpg",
    image1080: "/images/og/terrain-biologique-equilibre-homeostasie-1080x1080.jpg",
    alt: "Les 8 terrains biologiques en phytothérapie systémique",
    type: "article"
  },
  "/hormese/": {
    title: "Hormèse Végétale | Principes Amers & Résilience Bloom",
    description: "Le principe d'hormèse végétale : comment les molécules de défense des plantes stimulent notre pharmacie intérieure et nos mécanismes de régénération.",
    image1200: "/images/og/hormese-vegetale-resilience-cellulaire-1200x630.jpg",
    image1080: "/images/og/hormese-vegetale-resilience-cellulaire-1080x1080.jpg",
    alt: "Hormèse et résilience biologique par les principes amers végétaux",
    type: "article"
  },
  "/produit/bloomlab/": {
    title: "BloomLab® Extracteur Précision | Inox 304 ±0,5°C",
    description: "Commandez l'extracteur et infuseur botanique BloomLab®. Inox chirurgical 304, vortex cinétique, thermorégulation ±0,5°C pour extraire le Totum de vos plantes.",
    image1200: "/images/og/produit-bloomlab-1200x630.jpg",
    image1080: "/images/og/produit-bloomlab-1080x1080.jpg",
    alt: "Extracteur et infuseur botanique de précision BloomLab® en situation",
    type: "product",
    price: "239.00",
    sku: "BLOOMLAB-V2"
  },
  "/boutique/bloomlab/": {
    title: "BloomLab® Extracteur Précision | Inox 304 ±0,5°C",
    description: "Commandez l'extracteur et infuseur botanique BloomLab®. Inox chirurgical 304, vortex cinétique, thermorégulation ±0,5°C pour extraire le Totum de vos plantes.",
    image1200: "/images/og/produit-bloomlab-1200x630.jpg",
    image1080: "/images/og/produit-bloomlab-1080x1080.jpg",
    alt: "Extracteur et infuseur botanique de précision BloomLab® en situation",
    type: "product",
    price: "239.00",
    sku: "BLOOMLAB-V2"
  },
  "/boutique/bundle-apothicaire/": {
    title: "Trio Apothicaire | 3 Kits Plantes Médicinales",
    description: "Trio de formules médicinales calibrées pour infusion végétale et extraction maison : Sève Fondamentale, Nuit Profonde et Feu Digestif.",
    image1200: "/images/og/produit-bundle-apothicaire-1200x630.jpg",
    image1080: "/images/og/produit-bundle-apothicaire-1080x1080.jpg",
    alt: "Trio de formules médicinales Apothicaire Bloom by BotaniK",
    type: "product",
    price: "79.00",
    sku: "BUNDLE-APOTHICAIRE"
  },
  "/boutique/pack-signature/": {
    title: "Pack Signature BloomLab® + Trio Plantes — 289€",
    description: "Le pack complet pour démarrer l'herboristerie maison : la machine BloomLab®, les 3 mélanges de plantes signatures et l'accès aux protocoles d'extraction.",
    image1200: "/images/og/produit-pack-signature-1200x630.jpg",
    image1080: "/images/og/produit-pack-signature-1080x1080.jpg",
    alt: "Pack Signature BloomLab et ses trois formules botaniques",
    type: "product",
    price: "289.00",
    sku: "PACK-SIGNATURE"
  },
  "/boutique/kit-starter/": {
    title: "Kit Sève Fondamentale | Plantes Médicinales Énergie",
    description: "Mélange tonique et régulateur pour infusion végétale maison. Ortie, romarin et cynorrhodon pour soutenir le terrain et la vitalité quotidienne.",
    image1200: "/images/og/produit-kit-starter-1200x630.jpg",
    image1080: "/images/og/produit-kit-starter-1080x1080.jpg",
    alt: "Kit de plantes médicinales Sève Fondamentale Bloom by BotaniK",
    type: "product",
    price: "29.00",
    sku: "KIT-SEVE"
  },
  "/boutique/kit-nuit/": {
    title: "Kit Nuit Profonde | Sommeil Réparateur & Plantes Bio",
    description: "Synergie de passiflore, mélisse et camomille matricaire calibrée pour l'extraction douce en infuseur végétal. Sommeil réparateur sans somnolence.",
    image1200: "/images/og/produit-kit-nuit-1200x630.jpg",
    image1080: "/images/og/produit-kit-nuit-1080x1080.jpg",
    alt: "Kit Nuit Profonde pour le sommeil et l'apaisement nerveux",
    type: "product",
    price: "29.00",
    sku: "KIT-NUIT"
  },
  "/boutique/kit-digestion/": {
    title: "Kit Feu Digestif | Confort Intestinal & Plantes Bio",
    description: "Fenouil doux, menthe poivrée et gentiane pour stimuler les sucs digestifs et apaiser le ballonnement après les repas grâce à l'extraction de précision.",
    image1200: "/images/og/produit-kit-digestion-1200x630.jpg",
    image1080: "/images/og/produit-kit-digestion-1080x1080.jpg",
    alt: "Kit Feu Digestif pour le confort intestinal et gastrique",
    type: "product",
    price: "29.00",
    sku: "KIT-DIGESTION"
  },
  "/boutique/kit-articulaire/": {
    title: "Kit Feu Articulaire | Mobilité & Souplesse Articulaire",
    description: "Harpagophytum, reine-des-prés et cassis pour soulager les articulations raides et réguler l'inflammation grâce à l'extraction du Totum.",
    image1200: "/images/og/produit-kit-articulaire-1200x630.jpg",
    image1080: "/images/og/produit-kit-articulaire-1080x1080.jpg",
    alt: "Kit Feu Articulaire pour la souplesse et le confort des articulations",
    type: "product",
    price: "32.00",
    sku: "KIT-ARTICULAIRE"
  },
  "/boutique/kit-hiver/": {
    title: "Kit Bouclier Hivernal | Défenses Immunitaires & Plantes",
    description: "Échinacée pourpre, thym à linalol et sureau noir. Synergie protectrice pour traverser l'hiver avec une infusion botanique riche en polyphénols.",
    image1200: "/images/og/produit-kit-hiver-1200x630.jpg",
    image1080: "/images/og/produit-kit-hiver-1080x1080.jpg",
    alt: "Kit Bouclier Hivernal pour l'immunité et la protection des voies respiratoires",
    type: "product",
    price: "32.00",
    sku: "KIT-HIVER"
  },
  "/boutique/duo-argiles/": {
    title: "Duo Argiles & Terres Rares | Purification Botanique",
    description: "Argiles vertes et blanches surfines ventilées pour cataplasmes et purification du terrain. Remède ancestral d'herboristerie maison.",
    image1200: "/images/og/produit-duo-argiles-1200x630.jpg",
    image1080: "/images/og/produit-duo-argiles-1080x1080.jpg",
    alt: "Duo Argiles & Terres Rares pour la purification systémique",
    type: "product",
    price: "24.00",
    sku: "DUO-ARGILES"
  },
  "/articles/infuseur-botanique-vs-theiere-classique-pourquoi-votre-tisane-ne-marche-pas/": {
    title: "Infuseur vs Théière | Pourquoi Votre Tisane Ne Marche Pas",
    description: "Pourquoi l'infuseur botanique surpasse la théière classique ? Découvrez les limites thermiques de l'eau bouillante et la puissance de l'extraction thermo-cinétique en milieu clos.",
    image1200: "/images/og/article-infuseur-vs-theiere-tisane-1200x630.jpg",
    image1080: "/images/og/article-infuseur-vs-theiere-tisane-1080x1080.jpg",
    alt: "Infuseur botanique vs théière classique pour vos tisanes",
    type: "article"
  },
  "/articles/extraction-a-froid-vs-extraction-a-chaud-guide-totum-vegetal/": {
    title: "Extraction Froid vs Chaud | Guide Totum Végétal",
    description: "Extraction à froid, décoction ou thermo-cinétique douce ? Découvrez quelle méthode préserve l'intégralité du Totum végétal sans altérer les molécules bioactives.",
    image1200: "/images/og/article-extraction-froid-chaud-totum-1200x630.jpg",
    image1080: "/images/og/article-extraction-froid-chaud-totum-1080x1080.jpg",
    alt: "Extraction à froid vs extraction à chaud du Totum végétal",
    type: "article"
  },
  "/articles/remedes-de-grand-mere-revisites-par-la-science-5-plantes-a-redecouvrir/": {
    title: "Remèdes Grand-Mère & Science | 5 Plantes Revisités",
    description: "Reine des prés, thym, camomille, romarin, mauve : comment la science confirme l'efficacité des remèdes de grand-mère grâce à l'extraction de précision à la maison.",
    image1200: "/images/og/article-remedes-grand-mere-science-1200x630.jpg",
    image1080: "/images/og/article-remedes-grand-mere-science-1080x1080.jpg",
    alt: "Remèdes de grand-mère et phytothérapie revisités par la science moderne",
    type: "article"
  },
  "/articles/comment-fabriquer-huiles-infusees-teintures-maison/": {
    title: "Huiles Infusées & Teintures | Guide Fabrication Maison",
    description: "Comment réussir vos huiles infusées, macérats huileux et teintures mères à la maison ? Solvants, températures de 45°C, ratios et extraction fermée expliqués pas à pas.",
    image1200: "/images/og/article-fabriquer-huiles-infusees-teintures-1200x630.jpg",
    image1080: "/images/og/article-fabriquer-huiles-infusees-teintures-1080x1080.jpg",
    alt: "Fabrication domestique d huiles infusées et de teintures",
    type: "article"
  },
  "/articles/plantes-adaptogenes-guide-complet-reequilibrer-systeme-nerveux/": {
    title: "Plantes Adaptogènes | Rééquilibrer l'Axe HPA & Stress",
    description: "Guide complet des plantes adaptogènes : Ashwagandha, Rhodiola, Éleuthérocoque, Basilic sacré. Régulez le cortisol, restaurez l'énergie vitale et libérez votre terrain.",
    image1200: "/images/og/article-plantes-adaptogenes-systeme-nerveux-1200x630.jpg",
    image1080: "/images/og/article-plantes-adaptogenes-systeme-nerveux-1080x1080.jpg",
    alt: "Plantes adaptogènes pour rééquilibrer le système nerveux",
    type: "article"
  },
  "/blog/science-extraction-botanique-biodisponibilite/": {
    title: "Science Extraction Botanique | Journal Bloom",
    description: "Comprendre les principes biophysiques de l'extraction végétale : biodisponibilité cellulaire, cinétique vortex et thermorégulation de précision.",
    image1200: "/images/og/article-extraction-froid-chaud-totum-1200x630.jpg",
    image1080: "/images/og/article-extraction-froid-chaud-totum-1080x1080.jpg",
    alt: "Science de l'extraction botanique et biodisponibilité",
    type: "article"
  },
  "/blog/phytotherapie-axe-intestin-cerveau-microbiote/": {
    title: "Axe Intestin-Cerveau & Plantes | Journal Bloom",
    description: "L'impact des principes amers et polyphénols sur l'axe intestin-cerveau, le microbiote intestinal et la régulation neuro-végétative.",
    image1200: "/images/og/produit-kit-digestion-1200x630.jpg",
    image1080: "/images/og/produit-kit-digestion-1080x1080.jpg",
    alt: "Phytothérapie et axe intestin-cerveau",
    type: "article"
  },
  "/blog/protocoles-sommeil-reparateur-extraction-douce/": {
    title: "Protocoles Sommeil Réparateur | Journal Bloom",
    description: "Comment concevoir des extractions végétales douces pour restaurer les cycles circadiens et favoriser un sommeil profond et réparateur.",
    image1200: "/images/og/produit-kit-nuit-1200x630.jpg",
    image1080: "/images/og/produit-kit-nuit-1080x1080.jpg",
    alt: "Protocoles de sommeil réparateur par extraction douce",
    type: "article"
  },
  "/blog/guide-solvants-naturels-huile-eau-alcool-vinaigre/": {
    title: "Guide Solvants Naturels | Journal Bloom",
    description: "Eau, alcool de grain, huiles végétales et vinaigre de cidre : quel solvant choisir pour extraire les principes actifs de vos plantes.",
    image1200: "/images/og/huiles-infusees-maceration-plantes-1200x630.jpg",
    image1080: "/images/og/huiles-infusees-maceration-plantes-1080x1080.jpg",
    alt: "Guide des solvants naturels en phytothérapie",
    type: "article"
  },
  "/phytotherapie-reset/protocole-psoriasis/": {
    title: "Protocole Psoriasis | Reset Terrain Cutané",
    description: "Protocole complet d'accompagnement du terrain psoriasique par la phytothérapie intégrale : 4 phases, 14 semaines, soutien émonctoriel et régulation cutanée.",
    image1200: "/images/og/protocole-psoriasis-reset-homeostatique-1200x630.jpg",
    image1080: "/images/og/protocole-psoriasis-reset-homeostatique-1080x1080.jpg",
    alt: "Protocole Psoriasis — Reset Homéostasique et phytothérapie intégrale Bloom by BotaniK",
    type: "article",
    isPaywalled: true,
    datePublished: "2026-09-22T08:00:00+02:00",
    dateModified: "2026-09-22T08:00:00+02:00"
  },
  "/abonnement/": {
    title: "Abonnement Bloom | Protocoles & Accompagnement ALMA",
    description: "Rejoignez Bloom : accédez aux protocoles saisonniers de reset homéostatique, au suivi d'anamnèse ALMA et à l'ensemble des formules botaniques guidées.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Abonnement et protocoles d'accompagnement Bloom by BotaniK",
    type: "website"
  },
  "/activation/": {
    title: "Activer Votre BloomLab® | Garantie & Mise en Service",
    description: "Activez votre extracteur botanique BloomLab® : enregistrement de la garantie constructeur 1 an et déblocage de vos premiers protocoles d'extraction guidés.",
    image1200: "/images/og/produit-bloomlab-1200x630.jpg",
    image1080: "/images/og/produit-bloomlab-1080x1080.jpg",
    alt: "Activation et enregistrement de garantie BloomLab",
    type: "website"
  },
  "/la-marque/": {
    title: "Manifeste Bloom | Souveraineté Sanitaire & Plantes",
    description: "Manifeste Bloom by BotaniK : souveraineté sanitaire, ingénierie biologique et réconciliation entre rigueur scientifique et sagesse végétale ancestrale.",
    image1200: "/images/og/manifeste-souverainete-sanitaire-botanique-1200x630.jpg",
    image1080: "/images/og/manifeste-souverainete-sanitaire-botanique-1080x1080.jpg",
    alt: "La marque Bloom by BotaniK et sa mission de phytothérapie intégrale",
    type: "website"
  },
  "/bibliotheque/": {
    title: "Bibliothèque Botanique : Protocoles, Guides & Formulations | Bloom",
    description: "Accédez à l'ensemble de nos guides d'extraction, fiches recettes de phytothérapie et ateliers d'herboristerie moderne.",
    image1200: "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    image1080: "/images/og/articles-savoirs-herboristerie-botanique-1080x1080.jpg",
    alt: "Bibliothèque de savoirs et protocoles botaniques Bloom by BotaniK",
    type: "website"
  },
  "/recettes/": {
    title: "Recettes & Formulations Botaniques : Tisanes, Huiles & Extraits | Bloom",
    description: "Recettes précises d'extraction végétale : ratios, températures et solvants pour concevoir vos remèdes et soins botaniques à la maison.",
    image1200: "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    image1080: "/images/og/articles-savoirs-herboristerie-botanique-1080x1080.jpg",
    alt: "Recettes et préparations de phytothérapie moderne",
    type: "website"
  },
  "/blog/": {
    title: "Journal Botanique | Extraction & Remèdes Naturels",
    description: "Le Journal Botanique Bloom : analyses scientifiques, dossiers d'herboristerie moderne, recettes d'extraction et guides pratiques pour vos remèdes maison.",
    image1200: "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    image1080: "/images/og/articles-savoirs-herboristerie-botanique-1080x1080.jpg",
    alt: "Le Blog Botanique Bloom by BotaniK",
    type: "website"
  },
  "/mentions-legales/": {
    title: "Mentions Légales | Bloom by BotaniK",
    description: "Mentions légales du site bloombybotanik.com : éditeur, hébergement, propriété intellectuelle et informations réglementaires de la marque Bloom.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Mentions légales Bloom by BotaniK",
    type: "website"
  },
  "/politique-de-confidentialite/": {
    title: "Politique de Confidentialité | Données Personnelles Bloom",
    description: "Politique de confidentialité et protection des données personnelles (RGPD) sur bloombybotanik.com. Vos données de santé et de navigation sont sécurisées.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Politique de confidentialité Bloom by BotaniK",
    type: "website"
  },
  "/conditions-generales-de-vente/": {
    title: "Conditions Générales de Vente (CGV) | Bloom by BotaniK",
    description: "Consultez les conditions générales de vente de Bloom by BotaniK : commandes, tarifs, garanties, livraisons et droit de rétractation applicable.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Conditions Générales de Vente Bloom by BotaniK",
    type: "website"
  },
  "/termes-et-conditions/": {
    title: "Conditions d'Utilisation (CGU) | Bloom by BotaniK",
    description: "Conditions générales d'utilisation du site et des services Bloom by BotaniK. Modalités d'accès à l'application et aux contenus botaniques.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Termes et conditions d'utilisation Bloom by BotaniK",
    type: "website"
  },
  "/retour-et-remboursement/": {
    title: "Retours & Remboursements | Garantie 30 Jours Bloom",
    description: "Politique de retour et de remboursement Bloom by BotaniK : garantie satisfait ou remboursé sous 30 jours et modalités de prise en charge SAV.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Retour et remboursement Bloom by BotaniK",
    type: "website"
  },
  "/droit-de-retractation/": {
    title: "Droit de Rétractation | Formulaire de Retour Bloom",
    description: "Exercice de votre droit légal de rétractation sous 14 jours et formulaire de retour de commande pour vos achats sur bloombybotanik.com.",
    image1200: "/images/og/bloom-extracteur-infuseur-botanique-1200x630.jpg",
    image1080: "/images/og/bloom-extracteur-infuseur-botanique-1080x1080.jpg",
    alt: "Droit de rétractation Bloom by BotaniK",
    type: "website"
  }
};

function injectServerSEO(html: string, reqPath: string): string {
  try {
    const clean = reqPath.replace(/\/$/, "") + "/";
    const normalized = clean === "//" ? "/" : clean;

    // 0. Recettes publiques crawlables (Hub, Catégories, Pagination & Fiches individuelles)
    if (reqPath.startsWith("/recettes") || reqPath.startsWith("/recettes/")) {
      const cleanRecipePath = reqPath.endsWith("/") ? reqPath : reqPath + "/";

      // 0.1 Fiche Recette Herbier Migrée (prioritaire pour le nouveau gabarit canonique)
      const herbierRecipe = getHerbierRecipeByPath(cleanRecipePath);
      if (herbierRecipe) {
        const rendered = renderHerbierRecipePageHtml(herbierRecipe);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<meta\s+property=["']og:type["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:type" content="${herbierRecipe.schemaType === 'Recipe' ? 'website' : 'article'}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      // 0.2 Fiche Recette Canonique Catalogue Initial (81 recettes)
      const recipe = getRecipeByPath(cleanRecipePath);
      if (recipe) {
        const rendered = renderRecipePageHtml(recipe);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<meta\s+property=["']og:type["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:type" content="${recipe.schemaType === 'Recipe' ? 'website' : 'article'}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      // 0.3 Catégorie Phytothérapie
      if (cleanRecipePath.startsWith("/recettes/phytotherapie")) {
        const matchPage = cleanRecipePath.match(/\/page\/(\d+)\/?$/);
        const pageNum = matchPage ? parseInt(matchPage[1], 10) : 1;
        const rendered = renderHerbierCategoryPageHtml('phytotherapie', pageNum);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      // 0.4 Catégorie Gastronomie
      if (cleanRecipePath.startsWith("/recettes/gastronomie")) {
        const matchPage = cleanRecipePath.match(/\/page\/(\d+)\/?$/);
        const pageNum = matchPage ? parseInt(matchPage[1], 10) : 1;
        const rendered = renderHerbierCategoryPageHtml('gastronomie', pageNum);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      if (cleanRecipePath.startsWith("/recettes/culinaires")) {
        const matchPage = cleanRecipePath.match(/\/page\/(\d+)\/?$/);
        const pageNum = matchPage ? parseInt(matchPage[1], 10) : 1;
        const rendered = renderCategoryPageHtml('culinaires', pageNum);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      if (cleanRecipePath.startsWith("/recettes/cosmetiques")) {
        const matchPage = cleanRecipePath.match(/\/page\/(\d+)\/?$/);
        const pageNum = matchPage ? parseInt(matchPage[1], 10) : 1;
        const rendered = renderCategoryPageHtml('cosmetiques', pageNum);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      if (cleanRecipePath.startsWith("/recettes/parcours-botaniques")) {
        const matchPage = cleanRecipePath.match(/\/page\/(\d+)\/?$/);
        const pageNum = matchPage ? parseInt(matchPage[1], 10) : 1;
        const rendered = renderCategoryPageHtml('parcours-botaniques', pageNum);
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }

      if (cleanRecipePath === "/recettes/" || cleanRecipePath === "/recettes") {
        const rendered = renderHubPageHtml();
        let updated = html.replace(/<title>.*?<\/title>/i, `<title>${rendered.title}</title>`);
        updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${rendered.metaDescription}" />`);
        updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${rendered.metaDescription}">`);
        updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${rendered.canonical}">`);
        updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${rendered.canonical}" />`);
        updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${rendered.title}">`);
        updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${rendered.metaDescription}">`);
        updated = updated.replace("</head>", `  ${rendered.jsonLd}\n  </head>`);
        updated = updated.replace(/<div id=["']root["']>[\s\S]*?<\/div>/i, `<div id="root">${rendered.bodyHtml}</div>`);
        return updated;
      }
    }

    const route = SERVER_SEO_ROUTES[normalized] || SERVER_SEO_ROUTES[reqPath] || SERVER_SEO_ROUTES["/"];

    const full1200 = `https://bloombybotanik.com${route.image1200}`;
    const full1080 = `https://bloombybotanik.com${route.image1080}`;
    const canonical = `https://bloombybotanik.com${normalized}`;

    let updated = html;

    // 1. Update Title
    updated = updated.replace(/<title>.*?<\/title>/i, `<title>${route.title}</title>`);

    // 2. Update Meta Description
    updated = updated.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${route.description}" />`);

    // 3. Update OG Title, Description, URL, Type
    updated = updated.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${route.title}">`);
    updated = updated.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${route.description}">`);
    updated = updated.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${canonical}">`);
    updated = updated.replace(/<meta\s+property=["']og:type["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:type" content="${route.type}">`);

    // 4. Update OG Images Block cleanly
    const ogBlockRegex = /<!-- Primary OG Image[\s\S]*?<!-- Twitter Card -->/i;
    if (ogBlockRegex.test(updated)) {
      updated = updated.replace(
        ogBlockRegex,
        `<!-- Primary OG Image (1200x630) -->\n    <meta property="og:image" content="${full1200}">\n    <meta property="og:image:secure_url" content="${full1200}">\n    <meta property="og:image:type" content="image/jpeg">\n    <meta property="og:image:width" content="1200">\n    <meta property="og:image:height" content="630">\n    <meta property="og:image:alt" content="${route.alt}">\n    <!-- Secondary OG Image (1080x1080 Square Fallback) -->\n    <meta property="og:image" content="${full1080}">\n    <meta property="og:image:secure_url" content="${full1080}">\n    <meta property="og:image:type" content="image/jpeg">\n    <meta property="og:image:width" content="1080">\n    <meta property="og:image:height" content="1080">\n    <meta property="og:image:alt" content="${route.alt}">\n\n    <!-- Twitter Card -->`
      );
    }

    // 5. Update Canonical link & Hreflang
    updated = updated.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${canonical}" />`);

    if (normalized === "/phytotherapie-reset/protocole-psoriasis/") {
      updated = updated.replace(/<link\s+rel=["']alternate["']\s+hreflang=["'].*?["']\s+href=["'].*?["']\s*\/?>/gi, "");
      const customHreflang = `<link rel="alternate" hreflang="fr" href="${canonical}" />\n    <link rel="alternate" hreflang="x-default" href="${canonical}" />`;
      updated = updated.replace("<head>", `<head>\n    ${customHreflang}`);
    }

    // 6. Update Twitter Cards
    updated = updated.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${route.title}">`);
    updated = updated.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${route.description}">`);
    updated = updated.replace(/<meta\s+name=["']twitter:image["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:image" content="${full1200}">`);
    updated = updated.replace(/<meta\s+name=["']twitter:image:alt["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:image:alt" content="${route.alt}">`);

    // 7. Dynamic JSON-LD injection
    let schemaJson = "";
    if (route.type === "article") {
      const articleData: any = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": route.title,
        "description": route.description,
        "image": [full1200, full1080],
        "datePublished": (route as any).datePublished || "2026-09-01T08:00:00+02:00",
        "dateModified": (route as any).dateModified || "2026-09-20T10:00:00+02:00",
        "author": {
          "@type": "Organization",
          "name": "Bloom by BotaniK",
          "url": "https://bloombybotanik.com"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Bloom by BotaniK",
          "logo": {
            "@type": "ImageObject",
            "url": "https://bloombybotanik.com/assets/img/logo-bloom-square-512.png",
            "width": 512,
            "height": 512
          }
        },
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": canonical
        }
      };

      if ((route as any).isPaywalled) {
        articleData.isAccessibleForFree = false;
        articleData.hasPart = {
          "@type": "WebPageElement",
          "isAccessibleForFree": false,
          "cssSelector": ".premium-paywall-content"
        };
      }

      schemaJson = JSON.stringify(articleData);
    } else if (route.type === "product") {
      schemaJson = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Product",
        "name": route.title,
        "description": route.description,
        "image": [full1080, full1200],
        "sku": route.sku || "BLOOM-PROD",
        "brand": {
          "@type": "Brand",
          "name": "Bloom by BotaniK"
        },
        "offers": {
          "@type": "Offer",
          "url": canonical,
          "priceCurrency": "EUR",
          "price": route.price || "29.00",
          "availability": "https://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": "Bloom by BotaniK"
          },
          "shippingDetails": {
            "@type": "OfferShippingDetails",
            "shippingRate": {
              "@type": "MonetaryAmount",
              "value": (route.sku && route.sku.includes("BLOOMLAB")) ? "7.90" : "5.90",
              "currency": "EUR"
            },
            "shippingDestination": {
              "@type": "DefinedRegion",
              "addressCountry": "FR"
            },
            "deliveryTime": {
              "@type": "ShippingDeliveryTime",
              "handlingTime": {
                "@type": "QuantitativeValue",
                "minValue": 1,
                "maxValue": 2,
                "unitCode": "DAY"
              },
              "transitTime": {
                "@type": "QuantitativeValue",
                "minValue": 2,
                "maxValue": 4,
                "unitCode": "DAY"
              }
            }
          },
          "hasMerchantReturnPolicy": {
            "@type": "MerchantReturnPolicy",
            "applicableCountry": "FR",
            "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
            "merchantReturnDays": 14,
            "returnMethod": "https://schema.org/ReturnByMail",
            "returnFees": "https://schema.org/ReturnShippingFees"
          }
        }
      });
    }

    if (schemaJson) {
      const scriptTag = `<script type="application/ld+json" id="bloom-ssr-schema">\n${schemaJson}\n    </script>`;
      updated = updated.replace("</head>", `    ${scriptTag}\n  </head>`);
    }

    return updated;
  } catch (err) {
    console.error("[injectServerSEO error]", err);
    return html;
  }
}

/* ----------------------------------------------------------------------------
 * CATCH-ALL SPA (APRÈS Vite)
 * -------------------------------------------------------------------------- */
function registerCatchAll(app: express.Express, isProd: boolean) {
  const distPath = path.join(process.cwd(), "dist");
  if (isProd) {
    app.use(express.static(distPath, {
      index: false,
      maxAge: "1y",
      immutable: true,
      setHeaders: (res, filePath) => {
        if (filePath.endsWith(".html")) res.setHeader("Cache-Control", "no-cache, must-revalidate");
      },
    }));
  }
  app.get("*", async (req, res, next) => {
    try {
      if (req.path.startsWith("/@") || req.path.startsWith("/src/") || req.path.startsWith("/node_modules/")) {
        if (!isProd) return next();
        return res.status(404).send("Not found");
      }
      if (req.path.startsWith("/api") || /\.[a-z0-9]{2,5}$/i.test(req.path)) {
        return res.status(404).send("Not found");
      }
      const accept = req.get("accept") || "";
      if (accept && !accept.includes("text/html") && !accept.includes("*/*")) {
        return res.status(404).send("Not found");
      }
      if (isProd) {
        const cleanPath = req.path.replace(/^\//, "").replace(/\/$/, "");
        const specificHtml = path.join(distPath, cleanPath, "index.html");
        const flatHtml = path.join(distPath, `${cleanPath}.html`);
        if (cleanPath && fs.existsSync(specificHtml)) {
          res.setHeader("Content-Type", "text/html; charset=utf-8");
          res.setHeader("Cache-Control", "no-cache, must-revalidate");
          return res.send(injectServerSEO(fs.readFileSync(specificHtml, "utf-8"), req.path));
        }
        if (cleanPath && fs.existsSync(flatHtml)) {
          res.setHeader("Content-Type", "text/html; charset=utf-8");
          res.setHeader("Cache-Control", "no-cache, must-revalidate");
          return res.send(injectServerSEO(fs.readFileSync(flatHtml, "utf-8"), req.path));
        }
        const indexPath = path.join(distPath, "index.html");
        if (fs.existsSync(indexPath)) {
          res.setHeader("Content-Type", "text/html; charset=utf-8");
          res.setHeader("Cache-Control", "no-cache, must-revalidate");
          return res.send(injectServerSEO(fs.readFileSync(indexPath, "utf-8"), req.path));
        }
        return res.status(404).send("Index not found");
      } else {
        const indexPath = path.join(process.cwd(), "index.html");
        if (fs.existsSync(indexPath)) {
          let rawHtml = fs.readFileSync(indexPath, "utf-8");
          if (viteDevServer) {
            rawHtml = await viteDevServer.transformIndexHtml(req.originalUrl, rawHtml);
          }
          const finalHtml = injectServerSEO(rawHtml, req.path);
          return res.status(200).set({ "Content-Type": "text/html; charset=utf-8" }).end(finalHtml);
        }
        return res.status(404).send("Index not found");
      }
    } catch (err: any) {
      if (!isProd && viteDevServer) viteDevServer.ssrFixStacktrace(err);
      console.error("[CatchAll Error]", err);
      res.status(500).send("Internal Server Error");
    }
  });
}

/* ----------------------------------------------------------------------------
 * ERROR HANDLER GLOBAL
 * -------------------------------------------------------------------------- */
function errorHandler(err: any, req: express.Request, res: express.Response, next: express.NextFunction) {
  if (res.headersSent) return next(err);
  console.error("[Global Error]", req.method, req.originalUrl, err);
  res.status(err.status || 500).json({
    error: IS_PROD ? "Une erreur interne est survenue sur le serveur." : err.message || "Internal Server Error",
  });
}

/* ----------------------------------------------------------------------------
 * START + GRACEFUL SHUTDOWN + PROCESS SAFETY
 * -------------------------------------------------------------------------- */
async function startServer() {
  if (!IS_PROD) {
    viteDevServer = await setupVite(app);
    if (viteDevServer) {
      app.use(viteDevServer.middlewares);
      console.log("Vite middleware attached in dev");
    }
  }

  registerAppRoutes(app);

  registerCatchAll(app, IS_PROD);
  app.use(errorHandler);

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT} (${IS_PROD ? "production" : "development"})`);
  });

  const shutdown = (signal: string) => {
    console.log(`[Shutdown] ${signal} reçu, fermeture gracieuse…`);
    server.close(() => {
      console.log("[Shutdown] Fermeture propre terminée.");
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 10_000).unref();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

process.on("unhandledRejection", (reason, promise) => {
  console.error("[Process Safety] Unhandled Rejection at:", promise, "reason:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("[Process Safety] Uncaught Exception thrown:", err);
});

startServer().catch((err) => {
  console.error("Critical server startup error:", err);
  process.exit(1);
});