/**
 * BLOOM BY BOTANIK — REGISTRE OFFICIEL DES 153 RECETTES HERBIER MIGRÉES
 * 
 * Alignement strict avec :
 * - Les 13 registres de traditions (Égypte, Grèce, Avicenne, Hildegarde, Kabbale, MTC, Ayurveda...)
 * - Doctrina Signaturae (morphologie & résonance d'organes)
 * - Les 8 Terrains Bloom (T1 à T8) & 9 Axes opératoires (A1 à A9)
 * - Séquençage biphasé BloomLab® (Sachet A hydrosoluble / Sachet B liposoluble)
 * - Signature moléculaire & 6 labels de preuve scientifique
 * - Conformité DGCCRF (zéro allégation médicale, éducation et homéostasie)
 * - Règle Schema.org : Recipe pour culinaire & phytothérapie, Article STRICTEMENT pour cosmétique
 */

export interface HerbierRecipe {
  id: string;
  slug: string;
  canonicalUrl: string;
  oldUrls: string[];
  title: string;
  subtitle: string;
  category: 'phytotherapie' | 'cosmetique' | 'gastronomie';
  categorySlug: 'phytotherapie' | 'cosmetiques' | 'gastronomie';
  categoryLabel: string;
  subcategory: string;
  difficultyLevel: 1 | 2 | 3 | 4 | 5;
  difficultyLabel: 'Très facile' | 'Facile' | 'Intermédiaire' | 'Avancé' | 'Expert';
  prepTimeMinutes: number;
  machineTimeMinutes: number;
  totalTimeMinutes: number;
  tempSachetA: string;
  tempSachetB: string;
  shelfLife: string;
  yieldMl: number;
  heritage: {
    register: string;
    quote: string;
    period: string;
    description: string;
  };
  doctrinaSignaturae?: {
    visualAspect: string;
    doctrineInterpretation: string;
    organTarget: string;
  };
  terrains: string[];
  axes: string[];
  ingredients: string[];
  sachetA: {
    composition: string[];
    solvent: string;
    temp: string;
    duration: string;
  };
  sachetB?: {
    composition: string[];
    solvent: string;
    temp: string;
    duration: string;
  };
  instructions: string[];
  molecularSignature: {
    molecule: string;
    mechanism: string;
    evidenceLevel: string;
  }[];
  traditionalWisdom: string;
  precautions: string[];
  contraindications: string[];
  safetyWarning: string;
  observationsExpected: string;
  contextualLinks: {
    bloomLabKit?: { name: string; url: string };
    academyProtocol?: { name: string; url: string };
    plantMonograph?: { name: string; url: string };
    blogArticle?: { name: string; url: string };
  };
  image: string;
  imageAlt: string;
  schemaType: 'Recipe' | 'Article';
  gscImpressions90d: number;
  gscClicks90d: number;
  batchNumber: number;
  batchPriority: 'haute' | 'moyenne' | 'basse';
  isDuplicateWith81: boolean;
  duplicateCanonicalUrl?: string;
  datePublished: string;
  dateModified: string;
}

export const HERBIER_RECIPES: HerbierRecipe[] = [
  {
    "id": "herbier-therapeutic-chaga_vitality",
    "slug": "chaga-diamant-de-la-foret",
    "canonicalUrl": "/recettes/phytotherapie/chaga-diamant-de-la-foret/",
    "oldUrls": [
      "/herbier/chaga-diamant-de-la-foret/",
      "/herbier/chaga-diamant-de-la-foret",
      "/herbier/therapeutic-chaga_vitality/",
      "/herbier/therapeutic-chaga_vitality",
      "/herbier/therapeutic/chaga_vitality/",
      "/herbier/therapeutic/chaga_vitality",
      "/herbier/chaga_vitality/",
      "/herbier/chaga_vitality"
    ],
    "title": "Chaga (Diamant de la Forêt)",
    "subtitle": "Bouclier (Modulateur Immunitaire) — L'un des plus hauts scores ORAC au monde. L'acide bétulinique (issu du bouleau) est activé par le Chaga pour induire l'a...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "55°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T8",
      "T9"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sclérote (corps stérile) réduit en poudre fine de Chaga (Diamant de la Forêt) (30g)",
      "Fraction dense de Chaga (Diamant de la Forêt) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Sclérote (corps stérile) réduit en poudre fine de Chaga (Diamant de la Forêt) (30g)"
      ],
      "solvent": "Eau purifiée",
      "temp": "80°C",
      "duration": "4h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Chaga (Diamant de la Forêt) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "55°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Sclérote (corps stérile) réduit en poudre fine afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau purifiée. Activer le cycle thermo-cinétique à 80°C pendant 4h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 55°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Bêta-glucanes (1-3, 1-6)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acide bétulinique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Mélanine / Polyphénols",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Superoxyde Dismutase (SOD)",
        "mechanism": "Fraction Enzymatique ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Utilisé depuis le XVIe siècle en Sibérie et dans les pays nordiques comme tonique universel et soutien immunitaire majeur.",
    "precautions": [
      "Consultez un médecin en cas de prise d'anticoagulants ou de traitement contre le diabète (effet hypoglycémiant potentiel)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Chaga (Diamant de la Forêt)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Chaga (Diamant de la Forêt) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 450,
    "gscClicks90d": 50,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-cordyceps_performance",
    "slug": "cordyceps-l-or-de-l-himalaya",
    "canonicalUrl": "/recettes/phytotherapie/cordyceps-l-or-de-l-himalaya/",
    "oldUrls": [
      "/herbier/cordyceps-l-or-de-l-himalaya/",
      "/herbier/cordyceps-l-or-de-l-himalaya",
      "/herbier/therapeutic-cordyceps_performance/",
      "/herbier/therapeutic-cordyceps_performance",
      "/herbier/therapeutic/cordyceps_performance/",
      "/herbier/therapeutic/cordyceps_performance",
      "/herbier/cordyceps_performance/",
      "/herbier/cordyceps_performance"
    ],
    "title": "Cordyceps (L'Or de l'Himalaya)",
    "subtitle": "Moteur (Adaptogène Énergétique) — Augmente significativement la production d'ATP cellulaire et l'utilisation de l'oxygène par les mitochondries. Optimise ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T5",
      "T10"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Mycélium et corps de fructification en poudre de Cordyceps (L'Or de l'Himalaya) (30g)",
      "Fraction dense de Cordyceps (L'Or de l'Himalaya) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Mycélium et corps de fructification en poudre de Cordyceps (L'Or de l'Himalaya) (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "65°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Cordyceps (L'Or de l'Himalaya) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Mycélium et corps de fructification en poudre afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 65°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Cordycépine (3'-désoxyadénosine)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Adénosine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acide cordycépique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Ergostérol",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Trésor de la médecine tibétaine, réservé autrefois aux empereurs pour la longévité et la vigueur.",
    "precautions": [
      "Éviter en cas de maladies auto-immunes (stimulation immunitaire active)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cordyceps (L'Or de l'Himalaya)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Cordyceps (L'Or de l'Himalaya) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 435,
    "gscClicks90d": 48,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-hericium_focus",
    "slug": "hericium-criniere-de-lion",
    "canonicalUrl": "/recettes/phytotherapie/hericium-criniere-de-lion/",
    "oldUrls": [
      "/herbier/hericium-criniere-de-lion/",
      "/herbier/hericium-criniere-de-lion",
      "/herbier/therapeutic-hericium_focus/",
      "/herbier/therapeutic-hericium_focus",
      "/herbier/therapeutic/hericium_focus/",
      "/herbier/therapeutic/hericium_focus",
      "/herbier/hericium_focus/",
      "/herbier/hericium_focus"
    ],
    "title": "Hericium (Crinière de Lion)",
    "subtitle": "Architecte (Régénérateur Nerveux) — Seul composé naturel capable de stimuler la synthèse du NGF (Nerve Growth Factor), favorisant la neurogenèse et la répar...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "55°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T6",
      "T7",
      "T1"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Corps de fructification séché et réduit en poudre de Hericium (Crinière de Lion) (30g)",
      "Fraction dense de Hericium (Crinière de Lion) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Corps de fructification séché et réduit en poudre de Hericium (Crinière de Lion) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine",
      "temp": "75°C",
      "duration": "3h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Hericium (Crinière de Lion) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "55°C",
      "duration": "2h30"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Corps de fructification séché et réduit en poudre afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine. Activer le cycle thermo-cinétique à 75°C pendant 3h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 55°C pendant 2h30.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Héricénones",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Érinacines",
        "mechanism": "Fraction Hydrosoluble/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Bêta-glucanes spécifique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Surnommé 'la nourriture du cerveau' par les moines bouddhistes pour approfondir la méditation et la concentration.",
    "precautions": [
      "Généralement très sûr. Prudence en cas d'allergie aux champignons."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Hericium (Crinière de Lion)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Hericium (Crinière de Lion) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 420,
    "gscClicks90d": 46,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-reishi_zen",
    "slug": "reishi-champignon-de-l-immortalite",
    "canonicalUrl": "/recettes/phytotherapie/reishi-champignon-de-l-immortalite/",
    "oldUrls": [
      "/herbier/reishi-champignon-de-l-immortalite/",
      "/herbier/reishi-champignon-de-l-immortalite",
      "/herbier/therapeutic-reishi_zen/",
      "/herbier/therapeutic-reishi_zen",
      "/herbier/therapeutic/reishi_zen/",
      "/herbier/therapeutic/reishi_zen",
      "/herbier/reishi_zen/",
      "/herbier/reishi_zen"
    ],
    "title": "Reishi (Champignon de l'Immortalité)",
    "subtitle": "Médiateur (Régulateur du Stress) — Action adaptogène puissante. Les tritérpènes inhibent la libération d'histamine et protègent le foie, tandis que les pol...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "85°C",
    "tempSachetB": "60°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T6",
      "T4"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Corps de fructification tranché ou poudre de Reishi (Champignon de l'Immortalité) (30g)",
      "Fraction dense de Reishi (Champignon de l'Immortalité) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Corps de fructification tranché ou poudre de Reishi (Champignon de l'Immortalité) (30g)"
      ],
      "solvent": "Eau pure",
      "temp": "85°C",
      "duration": "4h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Reishi (Champignon de l'Immortalité) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "60°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Corps de fructification tranché ou poudre afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau pure. Activer le cycle thermo-cinétique à 85°C pendant 4h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 60°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acides ganodériques (Tritérpènes)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polysaccharides complexes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Peptidoglycanes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Plante supérieure classée n°1 dans le Shennong Ben Cao Jing, considérée comme le secret de la jeunesse éternelle.",
    "precautions": [
      "Prudence en cas de traitement anticoagulant ou de chirurgie prévue (effet antiagrégant)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Reishi (Champignon de l'Immortalité)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Reishi (Champignon de l'Immortalité) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 405,
    "gscClicks90d": 44,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-curcuma_longa_poivre",
    "slug": "curcuma-et-poivre-noir",
    "canonicalUrl": "/recettes/phytotherapie/curcuma-et-poivre-noir/",
    "oldUrls": [
      "/herbier/curcuma-et-poivre-noir/",
      "/herbier/curcuma-et-poivre-noir",
      "/herbier/therapeutic-curcuma_longa_poivre/",
      "/herbier/therapeutic-curcuma_longa_poivre",
      "/herbier/therapeutic/curcuma_longa_poivre/",
      "/herbier/therapeutic/curcuma_longa_poivre",
      "/herbier/curcuma_longa_poivre/",
      "/herbier/curcuma_longa_poivre"
    ],
    "title": "Curcuma et Poivre Noir",
    "subtitle": "Gâchette (Inhibiteur d'inflammation) — Inhibition puissante de NF-κB et de la 5-LOX. La pipérine augmente la biodisponibilité de la curcumine de 2000% en inhib...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "Thérapeutique",
      "T8",
      "T1",
      "T3"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Rhizome séché en poudre ou tranches / Baies séchées de Curcuma et Poivre Noir (30g)",
      "Fraction dense de Curcuma et Poivre Noir (15g)"
    ],
    "sachetA": {
      "composition": [
        "Rhizome séché en poudre ou tranches / Baies séchées de Curcuma et Poivre Noir (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Curcuma et Poivre Noir (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Rhizome séché en poudre ou tranches / Baies séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Curcuminoïdes",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Huiles essentielles (Turmérone)",
        "mechanism": "Fraction Liposoluble/Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Pipérine",
        "mechanism": "Fraction Alcaloïde lipophile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Pilier de l'Ayurveda depuis 4000 ans pour 'purifier le sang' et traiter les troubles articulaires. En MTC, il 'invigore le sang et brise les stases'.",
    "precautions": [
      "Contre-indiqué en cas de calculs biliaires obstructifs ou de traitement anticoagulant. Peut tacher les vêtements et les surfaces en marbre."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Curcuma et Poivre Noir",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Curcuma et Poivre Noir — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 390,
    "gscClicks90d": 42,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-boswellia_serrata",
    "slug": "boswellia-encens",
    "canonicalUrl": "/recettes/phytotherapie/boswellia-encens/",
    "oldUrls": [
      "/herbier/boswellia-encens/",
      "/herbier/boswellia-encens",
      "/herbier/therapeutic-boswellia_serrata/",
      "/herbier/therapeutic-boswellia_serrata",
      "/herbier/therapeutic/boswellia_serrata/",
      "/herbier/therapeutic/boswellia_serrata",
      "/herbier/boswellia_serrata/",
      "/herbier/boswellia_serrata"
    ],
    "title": "Boswellia (Encens)",
    "subtitle": "Réparateur (Muqueuses & Fascia) — Inhibiteur spécifique et puissant de la 5-LOX (5-lipoxygénase), bloquant la production de leucotriènes pro-inflammatoire...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T8",
      "T6"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Résine (gomme oléorésineuse) de Boswellia (Encens) (30g)",
      "Fraction dense de Boswellia (Encens) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Résine (gomme oléorésineuse) de Boswellia (Encens) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Boswellia (Encens) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "4h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Résine (gomme oléorésineuse) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 4h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acides boswelliques (AKBA)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Résines et huiles essentielles",
        "mechanism": "Fraction Liposoluble/Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Shallaki en Ayurveda, utilisé depuis 3000 ans pour les articulations et le 'feu digestif'.",
    "precautions": [
      "Peut causer de légers reflux gastriques chez les sujets très sensibles. À prendre de préférence au milieu du repas."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Boswellia (Encens)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Boswellia (Encens) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 375,
    "gscClicks90d": 40,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-crocus_sativus",
    "slug": "safran",
    "canonicalUrl": "/recettes/phytotherapie/safran/",
    "oldUrls": [
      "/herbier/safran/",
      "/herbier/safran",
      "/herbier/therapeutic-crocus_sativus/",
      "/herbier/therapeutic-crocus_sativus",
      "/herbier/therapeutic/crocus_sativus/",
      "/herbier/therapeutic/crocus_sativus",
      "/herbier/crocus_sativus/",
      "/herbier/crocus_sativus"
    ],
    "title": "Safran",
    "subtitle": "Chef d'Orchestre (Psycho-émotionnel) — Modulation de la recapture de la séonine, dopamine et noradrénaline. Effets antidépresseurs et anxiolytiques validés cli...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "50°C",
    "tempSachetB": "40°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T7",
      "T4",
      "T5"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Stigmates séchés (fils rouges) de Safran (30g)",
      "Fraction dense de Safran (15g)"
    ],
    "sachetA": {
      "composition": [
        "Stigmates séchés (fils rouges) de Safran (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "50°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Safran (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Stigmates séchés (fils rouges) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 50°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 40°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Safranal",
        "mechanism": "Fraction Volatile/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Crocine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Picrocrocine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé par Cléopâtre pour ses bains. En MTC, il 'fait circuler le Qi et le Sang, dissipe les stases et calme l'esprit (Shen)'.",
    "precautions": [
      "Ne pas dépasser 3g de safran par extraction. À haute dose (>5g), le safran devient toxique. Interdit aux femmes enceintes."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Safran",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Safran — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 360,
    "gscClicks90d": 38,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-urtica_dioica",
    "slug": "ortie-feuille-et-racine",
    "canonicalUrl": "/recettes/phytotherapie/ortie-feuille-et-racine/",
    "oldUrls": [
      "/herbier/ortie-feuille-et-racine/",
      "/herbier/ortie-feuille-et-racine",
      "/herbier/therapeutic-urtica_dioica/",
      "/herbier/therapeutic-urtica_dioica",
      "/herbier/therapeutic/urtica_dioica/",
      "/herbier/therapeutic/urtica_dioica",
      "/herbier/urtica_dioica/",
      "/herbier/urtica_dioica"
    ],
    "title": "Ortie (Feuille et Racine)",
    "subtitle": "Pharmacie Intérieure (Minéraux & Régulation) — La racine inhibe la liaison de la SHBG et la 5-alpha-réductase (réduisant le DHT libre). La feuille est l'une des source...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T9",
      "T10"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Feuilles séchées / Racines séchées de Ortie (Feuille et Racine) (30g)",
      "Fraction dense de Ortie (Feuille et Racine) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles séchées / Racines séchées de Ortie (Feuille et Racine) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Ortie (Feuille et Racine) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles séchées / Racines séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Silice organique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polyphénols et Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Phytostérols (Racine)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Chlorophylle",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Plante sacrée des druides. Utilisée depuis l'Antiquité pour 'nettoyer le sang' et fortifier les reins.",
    "precautions": [
      "La feuille d'ortie a un effet diurétique. Bien s'hydrater. La racine peut interagir avec les médicaments pour la prostate ou l'hypertension."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Ortie (Feuille et Racine)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Ortie (Feuille et Racine) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 345,
    "gscClicks90d": 36,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-equisetum_arvense",
    "slug": "prele-des-champs",
    "canonicalUrl": "/recettes/phytotherapie/prele-des-champs/",
    "oldUrls": [
      "/herbier/prele-des-champs/",
      "/herbier/prele-des-champs",
      "/herbier/therapeutic-equisetum_arvense/",
      "/herbier/therapeutic-equisetum_arvense",
      "/herbier/therapeutic/equisetum_arvense/",
      "/herbier/therapeutic/equisetum_arvense",
      "/herbier/equisetum_arvense/",
      "/herbier/equisetum_arvense"
    ],
    "title": "Prêle des champs",
    "subtitle": "Réparateur (Structure & Tissu conjonctif) — La plante terrestre la plus riche en silice (jusqu'à 10%). La silice est indispensable à la synthèse du collagène, à la ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T9",
      "T6",
      "T1"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Tiges stériles séchées de Prêle des champs (30g)",
      "Fraction dense de Prêle des champs (15g)"
    ],
    "sachetA": {
      "composition": [
        "Tiges stériles séchées de Prêle des champs (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "80°C",
      "duration": "2h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Prêle des champs (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Tiges stériles séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 80°C pendant 2h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Silice organique biodisponible",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Saponines",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée par les Romains pour souder les fractures osseuses. En Ayurveda, elle est connue sous le nom de 'Punarnava' (celle qui renouvelle le corps).",
    "precautions": [
      "Contre-indiquée en cas d'insuffisance rénale ou cardiaque. Cure de 3 semaines max, suivie d'une pause d'une semaine."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Prêle des champs",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Prêle des champs — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 330,
    "gscClicks90d": 34,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-zingiber_officinale",
    "slug": "gingembre",
    "canonicalUrl": "/recettes/phytotherapie/gingembre/",
    "oldUrls": [
      "/herbier/gingembre/",
      "/herbier/gingembre",
      "/herbier/therapeutic-zingiber_officinale/",
      "/herbier/therapeutic-zingiber_officinale",
      "/herbier/therapeutic/zingiber_officinale/",
      "/herbier/therapeutic/zingiber_officinale",
      "/herbier/zingiber_officinale/",
      "/herbier/zingiber_officinale"
    ],
    "title": "Gingembre",
    "subtitle": "Déclencheur (Activateur métabolique) — Activation de l'autophagie, stimulation de la microcirculation, inhibition du NLRP3 inflammasome et action anti-nauséeus...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T5",
      "T8"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Rhizome séché en tranches ou poudre de Gingembre (30g)",
      "Fraction dense de Gingembre (15g)"
    ],
    "sachetA": {
      "composition": [
        "Rhizome séché en tranches ou poudre de Gingembre (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Gingembre (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Rhizome séché en tranches ou poudre afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "[6]-Gingérols",
        "mechanism": "Fraction Liposoluble/Thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Shogaols",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Zingibérène",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Utilisé depuis 5000 ans en Ayurveda (Shunthi) pour allumer 'Agni' (le feu digestif) et en MTC pour réchauffer le Poumon et l'Estomac.",
    "precautions": [
      "Déconseillé à haute dose en cas d'ulcère gastrique actif ou de traitement anticoagulant."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gingembre",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Gingembre — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 315,
    "gscClicks90d": 32,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-scutellaria_baicalensis",
    "slug": "scutellaire-de-baikal",
    "canonicalUrl": "/recettes/phytotherapie/scutellaire-de-baikal/",
    "oldUrls": [
      "/herbier/scutellaire-de-baikal/",
      "/herbier/scutellaire-de-baikal",
      "/herbier/therapeutic-scutellaria_baicalensis/",
      "/herbier/therapeutic-scutellaria_baicalensis",
      "/herbier/therapeutic/scutellaria_baicalensis/",
      "/herbier/therapeutic/scutellaria_baicalensis",
      "/herbier/scutellaria_baicalensis/",
      "/herbier/scutellaria_baicalensis"
    ],
    "title": "Scutellaire de Baïkal",
    "subtitle": "Verrou (Neuro-inflammation) — Inhibition puissante de la neuro-inflammation, protection de la barrière hémato-encéphalique, modulation des récepteurs ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T7",
      "T8",
      "T4"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Racine séchée de Scutellaire de Baïkal (30g)",
      "Fraction dense de Scutellaire de Baïkal (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Scutellaire de Baïkal (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Scutellaire de Baïkal (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Baicaline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Wogonine",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Baicaléine",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Huang Qin en MTC. Utilisée depuis 2000 ans pour 'purger la chaleur et le feu', particulièrement du Poumon et du Foie (colère/frustration).",
    "precautions": [
      "Peut potentialiser les sédatifs. À éviter pendant la grossesse."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Scutellaire de Baïkal",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Scutellaire de Baïkal — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 300,
    "gscClicks90d": 30,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-rhodiola_rosea",
    "slug": "rhodiola-rosea",
    "canonicalUrl": "/recettes/phytotherapie/rhodiola-rosea/",
    "oldUrls": [
      "/herbier/rhodiola-rosea/",
      "/herbier/rhodiola-rosea",
      "/herbier/therapeutic-rhodiola_rosea/",
      "/herbier/therapeutic-rhodiola_rosea",
      "/herbier/therapeutic/rhodiola_rosea/",
      "/herbier/therapeutic/rhodiola_rosea",
      "/herbier/rhodiola_rosea/",
      "/herbier/rhodiola_rosea"
    ],
    "title": "Rhodiola Rosea",
    "subtitle": "Chef d'Orchestre (Adaptogène) — Réduction de la fatigue et du cortisol, amélioration de la performance cognitive et physique, modulation des neurotransm...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T5",
      "T7"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Rhizome et racine séchés de Rhodiola Rosea (30g)",
      "Fraction dense de Rhodiola Rosea (15g)"
    ],
    "sachetA": {
      "composition": [
        "Rhizome et racine séchés de Rhodiola Rosea (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Rhodiola Rosea (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Rhizome et racine séchés afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Rosavines",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Salidroside",
        "mechanism": "Fraction Hydrosoluble/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Huiles essentielles (arôme de rose)",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Plante sacrée des peuples sibériens et vikings pour l'endurance et la longévité. En MTC, elle tonifie le Qi et le Sang.",
    "precautions": [
      "À prendre le matin ou midi (peut perturber le sommeil si prise le soir). Déconseillée en cas de troubles bipolaires."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Rhodiola Rosea",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Rhodiola Rosea — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 285,
    "gscClicks90d": 28,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-griffonia_simplicifolia",
    "slug": "griffonia",
    "canonicalUrl": "/recettes/phytotherapie/griffonia/",
    "oldUrls": [
      "/herbier/griffonia/",
      "/herbier/griffonia",
      "/herbier/therapeutic-griffonia_simplicifolia/",
      "/herbier/therapeutic-griffonia_simplicifolia",
      "/herbier/therapeutic/griffonia_simplicifolia/",
      "/herbier/therapeutic/griffonia_simplicifolia",
      "/herbier/griffonia_simplicifolia/",
      "/herbier/griffonia_simplicifolia"
    ],
    "title": "Griffonia",
    "subtitle": "Pharmacie Intérieure (Précurseur neurochimique) — Le 5-HTP traverse la barrière hémato-encéphalique et est converti directement en sérotonine, puis en mélatonine. Efficac...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T7",
      "T9",
      "T10"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Graines séchées de Griffonia (30g)",
      "Fraction dense de Griffonia (15g)"
    ],
    "sachetA": {
      "composition": [
        "Graines séchées de Griffonia (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Griffonia (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Graines séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "5-HTP (5-Hydroxytryptophane)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Alcaloïdes indoliques",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Plante d'Afrique de l'Ouest traditionnellement utilisée pour la guérison des plaies, mais aussi comme tonique psychique.",
    "precautions": [
      "Interdiction absolue avec les antidépresseurs (IRS) : risque de syndrome sérotoninergique."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Griffonia",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Griffonia — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 270,
    "gscClicks90d": 26,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-gentiana_lutea",
    "slug": "gentiane-jaune",
    "canonicalUrl": "/recettes/phytotherapie/gentiane-jaune/",
    "oldUrls": [
      "/herbier/gentiane-jaune/",
      "/herbier/gentiane-jaune",
      "/herbier/therapeutic-gentiana_lutea/",
      "/herbier/therapeutic-gentiana_lutea",
      "/herbier/therapeutic/gentiana_lutea/",
      "/herbier/therapeutic/gentiana_lutea",
      "/herbier/gentiana_lutea/",
      "/herbier/gentiana_lutea"
    ],
    "title": "Gentiane Jaune",
    "subtitle": "Déclencheur (Amère majeur) — Stimulation puissante des récepteurs du goût amer (TAS2R), entraînant une augmentation réflexe de la sécrétion de bile, ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T2",
      "T4"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Racine séchée de Gentiane Jaune (30g)",
      "Fraction dense de Gentiane Jaune (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Gentiane Jaune (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Gentiane Jaune (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Gentiopicroside",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Amarogentine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Xanthones",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée depuis l'Antiquité européenne comme tonique amer majeur pour 'réveiller le feu digestif' et purifier le sang.",
    "precautions": [
      "Contre-indiquée en cas d'ulcère gastrique ou duodénal actif, et d'obstruction des voies biliaires."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gentiane Jaune",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Gentiane Jaune — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 255,
    "gscClicks90d": 24,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-raphanus_sativus_niger",
    "slug": "radis-noir",
    "canonicalUrl": "/recettes/phytotherapie/radis-noir/",
    "oldUrls": [
      "/herbier/radis-noir/",
      "/herbier/radis-noir",
      "/herbier/therapeutic-raphanus_sativus_niger/",
      "/herbier/therapeutic-raphanus_sativus_niger",
      "/herbier/therapeutic/raphanus_sativus_niger/",
      "/herbier/therapeutic/raphanus_sativus_niger",
      "/herbier/raphanus_sativus_niger/",
      "/herbier/raphanus_sativus_niger"
    ],
    "title": "Radis Noir",
    "subtitle": "Déclencheur (Drainage hépato-biliaire) — Stimulation cholérétique (production de bile) et cholagogue (évacuation de la bile). Soutien des enzymes de détoxificati...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T6",
      "T1"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Racine séchée de Radis Noir (30g)",
      "Fraction dense de Radis Noir (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Radis Noir (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Radis Noir (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Glucosinolates",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Isothiocyanates",
        "mechanism": "Fraction Liposoluble/Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Raphanines",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Remède traditionnel européen de printemps pour 'nettoyer le foie' après les excès de l'hiver.",
    "precautions": [
      "Contre-indiqué en cas de calculs biliaires obstructifs ou d'obstruction des voies biliaires. Peut irriter les muqueuses gastriques sensibles."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Radis Noir",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Radis Noir — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 240,
    "gscClicks90d": 22,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-chrysanthellum_indicum",
    "slug": "chrysanthellum",
    "canonicalUrl": "/recettes/phytotherapie/chrysanthellum/",
    "oldUrls": [
      "/herbier/chrysanthellum/",
      "/herbier/chrysanthellum",
      "/herbier/therapeutic-chrysanthellum_indicum/",
      "/herbier/therapeutic-chrysanthellum_indicum",
      "/herbier/therapeutic/chrysanthellum_indicum/",
      "/herbier/therapeutic/chrysanthellum_indicum",
      "/herbier/chrysanthellum_indicum/",
      "/herbier/chrysanthellum_indicum"
    ],
    "title": "Chrysanthellum",
    "subtitle": "Réparateur (Hépatoprotecteur & Veineux) — Action hépatoprotectrice puissante, réduction de la stéatose hépatique, et amélioration de la microcirculation veineuse ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T8",
      "T6"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Parties aériennes séchées de Chrysanthellum (30g)",
      "Fraction dense de Chrysanthellum (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Chrysanthellum (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Chrysanthellum (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Flavonoïdes (lutéoline)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Saponines stéroïdiques",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acides phénoliques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en Amérique du Sud et en médecine traditionnelle pour les troubles hépatiques et la circulation.",
    "precautions": [
      "Allergie aux Astéracées. Déconseillé en cas d'obstruction des voies biliaires."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Chrysanthellum",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Chrysanthellum — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 225,
    "gscClicks90d": 20,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-desmodium_adscendens",
    "slug": "desmodium",
    "canonicalUrl": "/recettes/phytotherapie/desmodium/",
    "oldUrls": [
      "/herbier/desmodium/",
      "/herbier/desmodium",
      "/herbier/therapeutic-desmodium_adscendens/",
      "/herbier/therapeutic-desmodium_adscendens",
      "/herbier/therapeutic/desmodium_adscendens/",
      "/herbier/therapeutic/desmodium_adscendens",
      "/herbier/desmodium_adscendens/",
      "/herbier/desmodium_adscendens"
    ],
    "title": "Desmodium",
    "subtitle": "Réparateur (Régénération hépatique) — Protection spécifique des membranes des hépatocytes contre les toxines (médicaments, alcool, virus). Action anti-allergi...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T3",
      "T8"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Parties aériennes séchées de Desmodium (30g)",
      "Fraction dense de Desmodium (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Desmodium (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Desmodium (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Saponosides triterpéniques",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Alcaloïdes",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en médecine traditionnelle africaine et amazonienne pour les troubles hépatiques et les réactions allergiques.",
    "precautions": [
      "Peut avoir un effet légèrement sédatif à haute dose. Déconseillé en cas d'obstruction des voies biliaires."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Desmodium",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Desmodium — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 210,
    "gscClicks90d": 18,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-arctium_lappa",
    "slug": "bardane",
    "canonicalUrl": "/recettes/phytotherapie/bardane/",
    "oldUrls": [
      "/herbier/bardane/",
      "/herbier/bardane",
      "/herbier/therapeutic-arctium_lappa/",
      "/herbier/therapeutic-arctium_lappa",
      "/herbier/therapeutic/arctium_lappa/",
      "/herbier/therapeutic/arctium_lappa",
      "/herbier/arctium_lappa/",
      "/herbier/arctium_lappa"
    ],
    "title": "Bardane",
    "subtitle": "Réparateur (Dépuratif sanguin & cutané) — Action dépurative, prébiotique (inuline), et modulation du microbiote cutané et intestinal. Efficace dans les dermatoses...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "Thérapeutique",
      "T9",
      "T1",
      "T2"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Racine séchée de Bardane (30g)",
      "Fraction dense de Bardane (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Bardane (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Bardane (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Inuline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polyacétylènes",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Plante majeure de la médecine traditionnelle chinoise (Niu Bang Zi) et européenne pour 'purifier le sang' et traiter les affections cutanées.",
    "precautions": [
      "Effet diurétique. Bien s'hydrater. Déconseillé en cas d'allergie aux Astéracées."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Bardane",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Bardane — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 195,
    "gscClicks90d": 16,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-astragalus_membranaceus",
    "slug": "astragale",
    "canonicalUrl": "/recettes/phytotherapie/astragale/",
    "oldUrls": [
      "/herbier/astragale/",
      "/herbier/astragale",
      "/herbier/therapeutic-astragalus_membranaceus/",
      "/herbier/therapeutic-astragalus_membranaceus",
      "/herbier/therapeutic/astragalus_membranaceus/",
      "/herbier/therapeutic/astragalus_membranaceus",
      "/herbier/astragalus_membranaceus/",
      "/herbier/astragalus_membranaceus"
    ],
    "title": "Astragale",
    "subtitle": "Chef d'Orchestre (Immunité & Longévité) — Modulation immunitaire (activation des macrophages et des cellules NK), protection des télomères (action sur la téloméra...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T5",
      "T4"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Racine séchée de Astragale (30g)",
      "Fraction dense de Astragale (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Astragale (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Astragale (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Astragaloside IV",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Huang Qi en MTC. Utilisé depuis 2000 ans comme tonique majeur du 'Qi' et de l'immunité.",
    "precautions": [
      "À éviter en cas de maladie auto-immune active (lupus, polyarthrite) ou de fièvre aiguë, car il stimule l'immunité."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Astragale",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Astragale — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 180,
    "gscClicks90d": 14,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-eleutherococcus_senticosus",
    "slug": "eleutherocoque",
    "canonicalUrl": "/recettes/phytotherapie/eleutherocoque/",
    "oldUrls": [
      "/herbier/eleutherocoque/",
      "/herbier/eleutherocoque",
      "/herbier/therapeutic-eleutherococcus_senticosus/",
      "/herbier/therapeutic-eleutherococcus_senticosus",
      "/herbier/therapeutic/eleutherococcus_senticosus/",
      "/herbier/therapeutic/eleutherococcus_senticosus",
      "/herbier/eleutherococcus_senticosus/",
      "/herbier/eleutherococcus_senticosus"
    ],
    "title": "Eleuthérocoque",
    "subtitle": "Chef d'Orchestre (Adaptogène) — Augmentation de la résistance non-spécifique au stress, amélioration de l'endurance physique et mentale, modulation de l...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T5",
      "T3"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Racine séchée de Eleuthérocoque (30g)",
      "Fraction dense de Eleuthérocoque (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Eleuthérocoque (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Eleuthérocoque (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Éleuthérosides",
        "mechanism": "Fraction Hydrosoluble/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisé en Russie soviétique pour les cosmonautes et les athlètes. En MTC, il tonifie le Qi et renforce la rate.",
    "precautions": [
      "À éviter en cas d'hypertension sévère non contrôlée. À prendre le matin ou midi."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Eleuthérocoque",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Eleuthérocoque — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 165,
    "gscClicks90d": 12,
    "batchNumber": 1,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-bacopa_monnieri",
    "slug": "bacopa",
    "canonicalUrl": "/recettes/phytotherapie/bacopa/",
    "oldUrls": [
      "/herbier/bacopa/",
      "/herbier/bacopa",
      "/herbier/therapeutic-bacopa_monnieri/",
      "/herbier/therapeutic-bacopa_monnieri",
      "/herbier/therapeutic/bacopa_monnieri/",
      "/herbier/therapeutic/bacopa_monnieri",
      "/herbier/bacopa_monnieri/",
      "/herbier/bacopa_monnieri"
    ],
    "title": "Bacopa",
    "subtitle": "Réparateur (Neuroplasticité) — Amélioration de la mémoire et de la vitesse de traitement de l'information. Réduction de l'anxiété via la modulation des...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4",
      "T1"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Parties aériennes séchées de Bacopa (30g)",
      "Fraction dense de Bacopa (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Bacopa (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Bacopa (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Bacosides",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Alcaloïdes",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Brahmi en Ayurveda. Utilisé depuis des millénaires par les érudits pour améliorer la mémoire et la concentration.",
    "precautions": [
      "Peut causer des troubles digestifs légers au début. À prendre au milieu d'un repas. Déconseillé en cas de bradycardie."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Bacopa",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Bacopa — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 85,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-ganoderma_lucidum",
    "slug": "reishi",
    "canonicalUrl": "/recettes/phytotherapie/reishi/",
    "oldUrls": [
      "/herbier/reishi/",
      "/herbier/reishi",
      "/herbier/therapeutic-ganoderma_lucidum/",
      "/herbier/therapeutic-ganoderma_lucidum",
      "/herbier/therapeutic/ganoderma_lucidum/",
      "/herbier/therapeutic/ganoderma_lucidum",
      "/herbier/ganoderma_lucidum/",
      "/herbier/ganoderma_lucidum"
    ],
    "title": "Reishi",
    "subtitle": "Chef d'Orchestre (Immunité & Calme) — Modulation immunitaire (équilibre Th1/Th2, augmentation des cellules NK), action hépatoprotectrice, et effet calmant sur...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T7",
      "T2"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Fruit (champignon) séché de Reishi (30g)",
      "Fraction dense de Reishi (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruit (champignon) séché de Reishi (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "80°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Reishi (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruit (champignon) séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 80°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides (Bêta-glucanes)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Triterpènes",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Ling Zhi en MTC, le 'champignon de l'immortalité'. Utilisé pour calmer l'esprit (Shen) et tonifier le Qi.",
    "precautions": [
      "Peut fluidifier le sang. À utiliser avec prudence en cas de traitement anticoagulant ou avant une intervention chirurgicale."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Reishi",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Reishi — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 21,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-cannabis_sativa_fleurs",
    "slug": "chanvre-industriel-fleurs",
    "canonicalUrl": "/recettes/phytotherapie/chanvre-industriel-fleurs/",
    "oldUrls": [
      "/herbier/chanvre-industriel-fleurs/",
      "/herbier/chanvre-industriel-fleurs",
      "/herbier/therapeutic-cannabis_sativa_fleurs/",
      "/herbier/therapeutic-cannabis_sativa_fleurs",
      "/herbier/therapeutic/cannabis_sativa_fleurs/",
      "/herbier/therapeutic/cannabis_sativa_fleurs",
      "/herbier/cannabis_sativa_fleurs/",
      "/herbier/cannabis_sativa_fleurs"
    ],
    "title": "Chanvre Industriel (Fleurs)",
    "subtitle": "Réparateur (Système Endocannabinoïde) — Modulation du système endocannabinoïde (récepteurs CB1 et CB2). Réduction de l'inflammation intestinale (leaky gut), act...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "50°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Fleurs séchées de Chanvre Industriel (Fleurs) (30g)",
      "Fraction dense de Chanvre Industriel (Fleurs) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fleurs séchées de Chanvre Industriel (Fleurs) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "50°C",
      "duration": "1h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Chanvre Industriel (Fleurs) (15g)"
      ],
      "solvent": "Huile de Jojoba ou Huile de Coco MCT",
      "temp": "45°C",
      "duration": "4h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fleurs séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 50°C pendant 1h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Huile de Jojoba ou Huile de Coco MCT pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 4h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Cannabidiol (CBD)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Cannabigérol (CBG)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Terpènes (Myrcène, Pinène)",
        "mechanism": "Fraction Volatile/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en médecine traditionnelle chinoise et ayurvédique pour calmer l'esprit, réduire la douleur et harmoniser le corps.",
    "precautions": [
      "Vérifiez la législation locale sur le CBD. Déconseillé en cas de grossesse, d'allaitement ou de traitement par inhibiteurs du cytochrome P450 (demandez l'avis d'un professionnel de santé)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Chanvre Industriel (Fleurs)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Chanvre Industriel (Fleurs) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 87,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-ginkgo_biloba",
    "slug": "ginkgo",
    "canonicalUrl": "/recettes/phytotherapie/ginkgo/",
    "oldUrls": [
      "/herbier/ginkgo/",
      "/herbier/ginkgo",
      "/herbier/therapeutic-ginkgo_biloba/",
      "/herbier/therapeutic-ginkgo_biloba",
      "/herbier/therapeutic/ginkgo_biloba/",
      "/herbier/therapeutic/ginkgo_biloba",
      "/herbier/ginkgo_biloba/",
      "/herbier/ginkgo_biloba"
    ],
    "title": "Ginkgo",
    "subtitle": "Pharmacie Intérieure (Microcirculation & Neuro) — Amélioration de la microcirculation cérébrale et périphérique, protection contre le stress oxydatif neuronal, et inhibit...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Feuilles séchées de Ginkgo (30g)",
      "Fraction dense de Ginkgo (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles séchées de Ginkgo (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Ginkgo (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Ginkgolides (A, B, C)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavones glycosides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acide ginkgolique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en MTC depuis des millénaires pour 'nourrir le cerveau' et 'débloquer les méridiens'.",
    "precautions": [
      "Contre-indiqué en cas de traitement anticoagulant ou antiagrégant plaquettaire. À arrêter 1 semaine avant toute intervention chirurgicale."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Ginkgo",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Ginkgo — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 43,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-trigonella_foenum_graecum",
    "slug": "fenugrec",
    "canonicalUrl": "/recettes/phytotherapie/fenugrec/",
    "oldUrls": [
      "/herbier/fenugrec/",
      "/herbier/fenugrec",
      "/herbier/therapeutic-trigonella_foenum_graecum/",
      "/herbier/therapeutic-trigonella_foenum_graecum",
      "/herbier/therapeutic/trigonella_foenum_graecum/",
      "/herbier/therapeutic/trigonella_foenum_graecum",
      "/herbier/trigonella_foenum_graecum/",
      "/herbier/trigonella_foenum_graecum"
    ],
    "title": "Fenugrec",
    "subtitle": "Réparateur (Métabolique & Capillaire) — Modulation de la glycémie (stimulation de la sécrétion d'insuline), action galactogène, et apport de précurseurs hormona...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Graines séchées de Fenugrec (30g)",
      "Fraction dense de Fenugrec (15g)"
    ],
    "sachetA": {
      "composition": [
        "Graines séchées de Fenugrec (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Fenugrec (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Graines séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Saponines stéroïdiques",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Mucilages",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "4-hydroxyisoleucine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en Égypte ancienne et en Ayurveda pour la vitalité, la digestion et la santé reproductive.",
    "precautions": [
      "Déconseillé en cas de diabète sous traitement (risque d'hypoglycémie) et pendant la grossesse (effet utérotonique à haute dose)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Fenugrec",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Fenugrec — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 44,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-plantago_major",
    "slug": "plantain-majeur",
    "canonicalUrl": "/recettes/phytotherapie/plantain-majeur/",
    "oldUrls": [
      "/herbier/plantain-majeur/",
      "/herbier/plantain-majeur",
      "/herbier/therapeutic-plantago_major/",
      "/herbier/therapeutic-plantago_major",
      "/herbier/therapeutic/plantago_major/",
      "/herbier/therapeutic/plantago_major",
      "/herbier/plantago_major/",
      "/herbier/plantago_major"
    ],
    "title": "Plantain majeur",
    "subtitle": "Réparateur (Muqueuses & Peau) — Action émolliente, anti-inflammatoire et cicatrisante sur les muqueuses (intestinales, respiratoires) et la peau. Réduct...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Feuilles séchées de Plantain majeur (30g)",
      "Fraction dense de Plantain majeur (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles séchées de Plantain majeur (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Plantain majeur (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Mucilages",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Iridoïdes (Aucuboside)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Considéré comme la 'trace de pas du blanc' par les Amérindiens, utilisé universellement pour cicatriser les plaies et apaiser les inflammations.",
    "precautions": [
      "Aucune contre-indication majeure. Peut ralentir légèrement l'absorption d'autres médicaments pris simultanément (prendre à distance)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Plantain majeur",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Plantain majeur — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 65,
    "gscClicks90d": 6,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-reynoutria_japonica",
    "slug": "renouee-du-japon-racine",
    "canonicalUrl": "/recettes/phytotherapie/renouee-du-japon-racine/",
    "oldUrls": [
      "/herbier/renouee-du-japon-racine/",
      "/herbier/renouee-du-japon-racine",
      "/herbier/therapeutic-reynoutria_japonica/",
      "/herbier/therapeutic-reynoutria_japonica",
      "/herbier/therapeutic/reynoutria_japonica/",
      "/herbier/therapeutic/reynoutria_japonica",
      "/herbier/reynoutria_japonica/",
      "/herbier/reynoutria_japonica"
    ],
    "title": "Renouée du Japon (Racine)",
    "subtitle": "Gâchette (Anti-inflammatoire & Antioxydant) — Inhibition puissante du NLRP3 inflammasome, protection mitochondriale, et action hépatoprotectrice. C'est l'une des sour...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Racine et rhizome séchés de Renouée du Japon (Racine) (30g)",
      "Fraction dense de Renouée du Japon (Racine) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine et rhizome séchés de Renouée du Japon (Racine) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "2h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Renouée du Japon (Racine) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine et rhizome séchés afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 2h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Resvératrol",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Émodine",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Polyphénols",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée en MTC (Hu Zhang) pour 'invigorer le sang, disperser les stases et clarifier la chaleur'.",
    "precautions": [
      "Peut avoir un effet laxatif à haute dose (présence d'émodine). Déconseillé en cas de grossesse ou de traitement anticoagulant."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Renouée du Japon (Racine)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Renouée du Japon (Racine) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 46,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-picrasma_quassioides",
    "slug": "quassia-amer",
    "canonicalUrl": "/recettes/phytotherapie/quassia-amer/",
    "oldUrls": [
      "/herbier/quassia-amer/",
      "/herbier/quassia-amer",
      "/herbier/therapeutic-picrasma_quassioides/",
      "/herbier/therapeutic-picrasma_quassioides",
      "/herbier/therapeutic/picrasma_quassioides/",
      "/herbier/therapeutic/picrasma_quassioides",
      "/herbier/picrasma_quassioides/",
      "/herbier/picrasma_quassioides"
    ],
    "title": "Quassia amer",
    "subtitle": "Déclencheur (Amère & Antiparasitaire) — L'une des substances les plus amères connues. Stimule fortement la sécrétion de bile et de sucs gastriques. Action antip...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2",
      "T1"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Bois séché de Quassia amer (30g)",
      "Fraction dense de Quassia amer (15g)"
    ],
    "sachetA": {
      "composition": [
        "Bois séché de Quassia amer (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Quassia amer (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Bois séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Quassinoïdes",
        "mechanism": "Fraction Hydrosoluble/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisé en Amérique du Sud et en Afrique de l'Ouest comme tonique amer et vermifuge naturel.",
    "precautions": [
      "Amertume extrême : commencer par de très petites doses. Déconseillé en cas d'ulcère gastrique ou de calculs biliaires."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Quassia amer",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Quassia amer — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 67,
    "gscClicks90d": 8,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-euphrasia_officinalis",
    "slug": "euphraise",
    "canonicalUrl": "/recettes/phytotherapie/euphraise/",
    "oldUrls": [
      "/herbier/euphraise/",
      "/herbier/euphraise",
      "/herbier/therapeutic-euphrasia_officinalis/",
      "/herbier/therapeutic-euphrasia_officinalis",
      "/herbier/therapeutic/euphrasia_officinalis/",
      "/herbier/therapeutic/euphrasia_officinalis",
      "/herbier/euphrasia_officinalis/",
      "/herbier/euphrasia_officinalis"
    ],
    "title": "Euphraise",
    "subtitle": "Réparateur (Muqueuses & Immunité) — Action astringente, anti-inflammatoire et décongestionnante spécifique des muqueuses (oculaires, respiratoires, intestin...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Parties aériennes séchées de Euphraise (30g)",
      "Fraction dense de Euphraise (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Euphraise (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Euphraise (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Iridoïdes (Euphrosine)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Nommée 'l'herbe aux yeux' depuis le Moyen Âge, utilisée par Hildegarde de Bingen pour les affections oculaires et respiratoires.",
    "precautions": [
      "Aucune contre-indication majeure connue. Peut causer une légère constipation à très haute dose (effet astringent des tanins)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Euphraise",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Euphraise — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 48,
    "gscClicks90d": 4,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-vaccinium_myrtillus",
    "slug": "myrtille",
    "canonicalUrl": "/recettes/phytotherapie/myrtille/",
    "oldUrls": [
      "/herbier/myrtille/",
      "/herbier/myrtille",
      "/herbier/therapeutic-vaccinium_myrtillus/",
      "/herbier/therapeutic-vaccinium_myrtillus",
      "/herbier/therapeutic/vaccinium_myrtillus/",
      "/herbier/therapeutic/vaccinium_myrtillus",
      "/herbier/vaccinium_myrtillus/",
      "/herbier/vaccinium_myrtillus"
    ],
    "title": "Myrtille",
    "subtitle": "Réparateur (Microcirculation & Collagène) — Protection de la microcirculation (rétine, peau, cerveau), renforcement du collagène, et action antioxydante puissante....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Fruits séchés (ou feuilles pour usage spécifique) de Myrtille (30g)",
      "Fraction dense de Myrtille (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruits séchés (ou feuilles pour usage spécifique) de Myrtille (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Myrtille (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruits séchés (ou feuilles pour usage spécifique) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Anthocyanes",
        "mechanism": "Fraction Hydrosoluble/Thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Myrtilline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée par les aviateurs de la RAF pendant la Seconde Guerre mondiale pour améliorer la vision nocturne.",
    "precautions": [
      "Généralement sûre. Aucune contre-indication majeure."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Myrtille",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Myrtille — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 49,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-lepidium_meyenii",
    "slug": "maca",
    "canonicalUrl": "/recettes/phytotherapie/maca/",
    "oldUrls": [
      "/herbier/maca/",
      "/herbier/maca",
      "/herbier/therapeutic-lepidium_meyenii/",
      "/herbier/therapeutic-lepidium_meyenii",
      "/herbier/therapeutic/lepidium_meyenii/",
      "/herbier/therapeutic/lepidium_meyenii",
      "/herbier/lepidium_meyenii/",
      "/herbier/lepidium_meyenii"
    ],
    "title": "Maca",
    "subtitle": "Chef d'Orchestre (Adaptogène Hormonal) — Modulation de l'axe HPA sans contenir d'hormones exogènes. Amélioration de la libido, de l'énergie et de l'humeur via l'...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Racine (hypocotyle) séchée de Maca (30g)",
      "Fraction dense de Maca (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine (hypocotyle) séchée de Maca (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Maca (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine (hypocotyle) séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Macamides et Macaènes",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Glucosinolates",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Cultivée depuis 2000 ans dans les Andes péruviennes comme 'viagra des Incas' et tonique de vitalité globale.",
    "precautions": [
      "Déconseillée en cas de pathologies hormonales sensibles (sein, utérus, prostate) sans avis médical, bien qu'elle ne contienne pas d'hormones."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Maca",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Maca — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 50,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-alchemilla_vulgaris",
    "slug": "alchemille",
    "canonicalUrl": "/recettes/phytotherapie/alchemille/",
    "oldUrls": [
      "/herbier/alchemille/",
      "/herbier/alchemille",
      "/herbier/therapeutic-alchemilla_vulgaris/",
      "/herbier/therapeutic-alchemilla_vulgaris",
      "/herbier/therapeutic/alchemilla_vulgaris/",
      "/herbier/therapeutic/alchemilla_vulgaris",
      "/herbier/alchemilla_vulgaris/",
      "/herbier/alchemilla_vulgaris"
    ],
    "title": "Alchémille",
    "subtitle": "Réparateur (Cycle Féminin & Muqueuses) — Action astringente, hémostatique et régulatrice sur les muqueuses, en particulier l'utérus et le tube digestif. Soulage ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Parties aériennes séchées de Alchémille (30g)",
      "Fraction dense de Alchémille (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Alchémille (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Alchémille (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Tanins ellagiques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acide salicylique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Plante sacrée des alchimistes du Moyen Âge, associée à la Vierge Marie pour ses vertus 'purificatrices' et gynécologiques.",
    "precautions": [
      "En raison de sa teneur en tanins, une consommation excessive et prolongée peut causer de la constipation. Faire des pauses."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Alchémille",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Alchémille — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 51,
    "gscClicks90d": 4,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-artemisia_annua",
    "slug": "armoise-annuelle",
    "canonicalUrl": "/recettes/phytotherapie/armoise-annuelle/",
    "oldUrls": [
      "/herbier/armoise-annuelle/",
      "/herbier/armoise-annuelle",
      "/herbier/therapeutic-artemisia_annua/",
      "/herbier/therapeutic-artemisia_annua",
      "/herbier/therapeutic/artemisia_annua/",
      "/herbier/therapeutic/artemisia_annua",
      "/herbier/artemisia_annua/",
      "/herbier/artemisia_annua"
    ],
    "title": "Armoise annuelle",
    "subtitle": "Gâchette (Immunité & Modulation) — Action immunomodulatrice puissante, antiparasitaire, et anti-inflammatoire via l'inhibition de la voie NF-κB. L'artémisi...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Parties aériennes séchées de Armoise annuelle (30g)",
      "Fraction dense de Armoise annuelle (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes séchées de Armoise annuelle (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Armoise annuelle (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Artémisinine",
        "mechanism": "Fraction Liposoluble/Thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Huiles essentielles",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Qing Hao en MTC, utilisée depuis 1600 ans pour les 'fièvres'. Prix Nobel de Médecine 2015 pour la découverte de l'artémisinine.",
    "precautions": [
      "Déconseillée pendant la grossesse et l'allaitement. Peut interagir avec certains médicaments métabolisés par le foie."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Armoise annuelle",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Armoise annuelle — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 72,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-vitex_agnus_castus",
    "slug": "gattilier-vitex",
    "canonicalUrl": "/recettes/phytotherapie/gattilier-vitex/",
    "oldUrls": [
      "/herbier/gattilier-vitex/",
      "/herbier/gattilier-vitex",
      "/herbier/therapeutic-vitex_agnus_castus/",
      "/herbier/therapeutic-vitex_agnus_castus",
      "/herbier/therapeutic/vitex_agnus_castus/",
      "/herbier/therapeutic/vitex_agnus_castus",
      "/herbier/vitex_agnus_castus/",
      "/herbier/vitex_agnus_castus"
    ],
    "title": "Gattilier (Vitex)",
    "subtitle": "Chef d'Orchestre (Régulateur Hormonal) — Action dopaminergique au niveau de l'hypophyse, inhibant la sécrétion de prolactine et favorisant la production de proge...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5",
      "T7"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Fruits séchés de Gattilier (Vitex) (30g)",
      "Fraction dense de Gattilier (Vitex) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruits séchés de Gattilier (Vitex) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Gattilier (Vitex) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruits séchés afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Diterpènes cycliques",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes (Casticine)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Iridoïdes (Agnuside)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Herbe des 'veuves' et des moines au Moyen Âge. Utilisé depuis l'Antiquité pour l'équilibre féminin.",
    "precautions": [
      "Contre-indiqué en cas de prise de contraceptifs oraux, de traitements dopaminergiques ou d'antécédents de cancers hormono-dépendants sans avis médical. Action lente (3 cycles minimum)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gattilier (Vitex)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Gattilier (Vitex) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 53,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-nigella_sativa",
    "slug": "nigelle",
    "canonicalUrl": "/recettes/phytotherapie/nigelle/",
    "oldUrls": [
      "/herbier/nigelle/",
      "/herbier/nigelle",
      "/herbier/therapeutic-nigella_sativa/",
      "/herbier/therapeutic-nigella_sativa",
      "/herbier/therapeutic/nigella_sativa/",
      "/herbier/therapeutic/nigella_sativa",
      "/herbier/nigella_sativa/",
      "/herbier/nigella_sativa"
    ],
    "title": "Nigelle",
    "subtitle": "Gâchette (Immunomodulateur & Anti-inflammatoire) — La thymoquinone est un puissant inhibiteur de NF-κB et des leucotriènes. Action antihistaminique, bronchodilatatrice et ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Graines séchées de Nigelle (30g)",
      "Fraction dense de Nigelle (15g)"
    ],
    "sachetA": {
      "composition": [
        "Graines séchées de Nigelle (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Nigelle (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Graines séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Thymoquinone",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Nigellone",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acides gras insaturés",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "La 'graine de bénédiction' de l'Islam et de la médecine unani. Utilisée pour 'tout sauf la mort'.",
    "precautions": [
      "Généralement très sûre. À haute dose peut avoir un léger effet fluidifiant sanguin."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Nigelle",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Nigelle — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 74,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-cordyceps_militaris",
    "slug": "cordyceps",
    "canonicalUrl": "/recettes/phytotherapie/cordyceps/",
    "oldUrls": [
      "/herbier/cordyceps/",
      "/herbier/cordyceps",
      "/herbier/therapeutic-cordyceps_militaris/",
      "/herbier/therapeutic-cordyceps_militaris",
      "/herbier/therapeutic/cordyceps_militaris/",
      "/herbier/therapeutic/cordyceps_militaris",
      "/herbier/cordyceps_militaris/",
      "/herbier/cordyceps_militaris"
    ],
    "title": "Cordyceps",
    "subtitle": "Chef d'Orchestre (Énergie Mitochondriale) — Augmentation de la production d'ATP mitochondrial, amélioration de l'utilisation de l'oxygène (VO2 max), et modulation d...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T6",
      "T5",
      "T3"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Fruit (champignon) séché de Cordyceps (30g)",
      "Fraction dense de Cordyceps (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruit (champignon) séché de Cordyceps (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "80°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Cordyceps (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruit (champignon) séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 80°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Cordycépine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Adénosine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Stérols (Ergostérol)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Champignon de l'énergie en MTC, utilisé par les sherpas pour l'endurance en altitude.",
    "precautions": [
      "Déconseillé en cas de maladies auto-immunes actives (stimulation immunitaire) ou de prise d'anticoagulants."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cordyceps",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Cordyceps — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 25,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-hieracium_pilosella",
    "slug": "piloselle",
    "canonicalUrl": "/recettes/phytotherapie/piloselle/",
    "oldUrls": [
      "/herbier/piloselle/",
      "/herbier/piloselle",
      "/herbier/therapeutic-hieracium_pilosella/",
      "/herbier/therapeutic-hieracium_pilosella",
      "/herbier/therapeutic/hieracium_pilosella/",
      "/herbier/therapeutic/hieracium_pilosella",
      "/herbier/hieracium_pilosella/",
      "/herbier/hieracium_pilosella"
    ],
    "title": "Piloselle",
    "subtitle": "Déclencheur (Drainage Rénal) — Puissant diurétique épargnant le potassium (contrairement aux diurétiques chimiques). Action anti-inflammatoire sur les ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Plante entière séchée de Piloselle (30g)",
      "Fraction dense de Piloselle (15g)"
    ],
    "sachetA": {
      "composition": [
        "Plante entière séchée de Piloselle (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Piloselle (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Plante entière séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acide chlorogénique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Ombelliférone",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée depuis le Moyen Âge en Europe pour les 'eaux' (œdèmes) et les infections urinaires.",
    "precautions": [
      "Déconseillé en cas d'insuffisance rénale ou cardiaque sévère (nécessitant une restriction hydrique)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Piloselle",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Piloselle — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 76,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-malva_sylvestris",
    "slug": "mauve",
    "canonicalUrl": "/recettes/phytotherapie/mauve/",
    "oldUrls": [
      "/herbier/mauve/",
      "/herbier/mauve",
      "/herbier/therapeutic-malva_sylvestris/",
      "/herbier/therapeutic-malva_sylvestris",
      "/herbier/therapeutic/malva_sylvestris/",
      "/herbier/therapeutic/malva_sylvestris",
      "/herbier/malva_sylvestris/",
      "/herbier/malva_sylvestris"
    ],
    "title": "Mauve",
    "subtitle": "Réparateur (Muqueuse Intestinale) — Action émolliente, anti-inflammatoire et protectrice des muqueuses (intestin, gorge, peau). Les mucilages forment un fil...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "50°C",
    "tempSachetB": "40°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Feuilles et fleurs séchées de Mauve (30g)",
      "Fraction dense de Mauve (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles et fleurs séchées de Mauve (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "50°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Mauve (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles et fleurs séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 50°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 40°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Mucilages",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Anthocyanes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "La 'mauvaise' (malva) d'Hildegarde de Bingen, utilisée pour adoucir toutes les inflammations internes et externes.",
    "precautions": [
      "Généralement sûre. À haute dose peut avoir un léger effet laxatif."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Mauve",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Mauve — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 77,
    "gscClicks90d": 6,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-asparagus_racemosus",
    "slug": "shatavari",
    "canonicalUrl": "/recettes/phytotherapie/shatavari/",
    "oldUrls": [
      "/herbier/shatavari/",
      "/herbier/shatavari",
      "/herbier/therapeutic-asparagus_racemosus/",
      "/herbier/therapeutic-asparagus_racemosus",
      "/herbier/therapeutic/asparagus_racemosus/",
      "/herbier/therapeutic/asparagus_racemosus",
      "/herbier/asparagus_racemosus/",
      "/herbier/asparagus_racemosus"
    ],
    "title": "Shatavari",
    "subtitle": "Réparateur (Yin Féminin & Muqueuses) — Adaptogène féminin majeur. Soutient la production d'œstrogènes naturels, hydrate les muqueuses (sècheresse vaginale, dig...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Racine séchée de Shatavari (30g)",
      "Fraction dense de Shatavari (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Shatavari (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Shatavari (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Shatavarines (Saponines stéroïdiques)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Mucilages",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Alcaloïdes",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "'Celle qui possède cent maris' en Ayurveda. Tonique féminin sacré pour la fertilité et la longévité.",
    "precautions": [
      "Déconseillé en cas de cancers hormono-dépendants (sein, utérus) ou d'endométriose sévère sans avis médical (effet phyto-œstrogénique)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Shatavari",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Shatavari — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 58,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-hericium_erinaceus",
    "slug": "lion-s-mane-hydne-herisson",
    "canonicalUrl": "/recettes/phytotherapie/lion-s-mane-hydne-herisson/",
    "oldUrls": [
      "/herbier/lion-s-mane-hydne-herisson/",
      "/herbier/lion-s-mane-hydne-herisson",
      "/herbier/therapeutic-hericium_erinaceus/",
      "/herbier/therapeutic-hericium_erinaceus",
      "/herbier/therapeutic/hericium_erinaceus/",
      "/herbier/therapeutic/hericium_erinaceus",
      "/herbier/hericium_erinaceus/",
      "/herbier/hericium_erinaceus"
    ],
    "title": "Lion's Mane (Hydne hérisson)",
    "subtitle": "Réparateur (Neuroplasticité) — Stimulation de la synthèse du NGF (Nerve Growth Factor). Amélioration de la cognition, de la mémoire et de l'humeur. Rép...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T7",
      "T5",
      "T2"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Fruit (champignon) séché de Lion's Mane (Hydne hérisson) (30g)",
      "Fraction dense de Lion's Mane (Hydne hérisson) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruit (champignon) séché de Lion's Mane (Hydne hérisson) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "80°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Lion's Mane (Hydne hérisson) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruit (champignon) séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 80°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Héricénones",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Érinacines",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Bêta-glucanes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Champignon de la clarté mentale en MTC, utilisé par les moines bouddhistes pour la méditation.",
    "precautions": [
      "Peut causer de légères démangeaisons chez les sujets très sensibles (stimulation du NGF). Déconseillé en cas d'allergie aux champignons."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lion's Mane (Hydne hérisson)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Lion's Mane (Hydne hérisson) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-inonotus_obliquus",
    "slug": "chaga",
    "canonicalUrl": "/recettes/phytotherapie/chaga/",
    "oldUrls": [
      "/herbier/chaga/",
      "/herbier/chaga",
      "/herbier/therapeutic-inonotus_obliquus/",
      "/herbier/therapeutic-inonotus_obliquus",
      "/herbier/therapeutic/inonotus_obliquus/",
      "/herbier/therapeutic/inonotus_obliquus",
      "/herbier/inonotus_obliquus/",
      "/herbier/inonotus_obliquus"
    ],
    "title": "Chaga",
    "subtitle": "Chef d'Orchestre (Antioxydant Majeur) — L'un des antioxydants les plus puissants de la planète (ORAC > 100 000). Modulation immunitaire, protection de l'ADN con...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T6",
      "T8"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Sclérote (champignon) séché de Chaga (30g)",
      "Fraction dense de Chaga (15g)"
    ],
    "sachetA": {
      "composition": [
        "Sclérote (champignon) séché de Chaga (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "75°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Chaga (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Sclérote (champignon) séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 75°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Mélanine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acide bétulinique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "SOD (Superoxyde Dismutase)",
        "mechanism": "Fraction Hydrosoluble/Thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Champignon de l'immortalité en Sibérie et en MTC. Utilisé depuis des siècles pour la longévité.",
    "precautions": [
      "Déconseillé en cas de maladies auto-immunes (stimulation immunitaire) ou de prise d'anticoagulants (acide bétulinique)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Chaga",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Chaga — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 20,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-hamamelis_virginiana",
    "slug": "hamamelis",
    "canonicalUrl": "/recettes/phytotherapie/hamamelis/",
    "oldUrls": [
      "/herbier/hamamelis/",
      "/herbier/hamamelis",
      "/herbier/therapeutic-hamamelis_virginiana/",
      "/herbier/therapeutic-hamamelis_virginiana",
      "/herbier/therapeutic/hamamelis_virginiana/",
      "/herbier/therapeutic/hamamelis_virginiana",
      "/herbier/hamamelis_virginiana/",
      "/herbier/hamamelis_virginiana"
    ],
    "title": "Hamamélis",
    "subtitle": "Réparateur (Circulation Veineuse & Lymphatique) — Action veinotonique, lymphagogue et anti-inflammatoire puissante. Réduit la perméabilité capillaire et l'œdème. Maître d...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Feuilles et écorce séchées de Hamamélis (30g)",
      "Fraction dense de Hamamélis (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles et écorce séchées de Hamamélis (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Hamamélis (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles et écorce séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Tanins galliques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Hamamélitane",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Arbre magique des Amérindiens, utilisé pour les saignements et les inflammations.",
    "precautions": [
      "En raison de sa teneur en tanins, une consommation excessive peut causer de la constipation. Faire des pauses."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Hamamélis",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Hamamélis — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 41,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-moringa_oleifera",
    "slug": "moringa",
    "canonicalUrl": "/recettes/phytotherapie/moringa/",
    "oldUrls": [
      "/herbier/moringa/",
      "/herbier/moringa",
      "/herbier/therapeutic-moringa_oleifera/",
      "/herbier/therapeutic-moringa_oleifera",
      "/herbier/therapeutic/moringa_oleifera/",
      "/herbier/therapeutic/moringa_oleifera",
      "/herbier/moringa_oleifera/",
      "/herbier/moringa_oleifera"
    ],
    "title": "Moringa",
    "subtitle": "Pharmacie Intérieure (Nutrition Cellulaire Dense) — Densité nutritionnelle exceptionnelle. Action anti-inflammatoire via les isothiocyanates (similaires au sulforaphane). S...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Feuilles séchées de Moringa (30g)",
      "Fraction dense de Moringa (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles séchées de Moringa (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Moringa (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Isothiocyanates",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Vitamines (A, C, E)",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Minéraux (Fer, Calcium)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "L'arbre de vie en Ayurveda et en médecine traditionnelle africaine. Utilisé pour la malnutrition et la vitalité.",
    "precautions": [
      "Déconseillé en début de grossesse (effet utérotonique léger des racines/écorces, moins les feuilles, mais prudence). Peut avoir un effet laxatif à haute dose."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Moringa",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Moringa — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 82,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-allium_sativum",
    "slug": "ail-vieilli-ou-noir",
    "canonicalUrl": "/recettes/phytotherapie/ail-vieilli-ou-noir/",
    "oldUrls": [
      "/herbier/ail-vieilli-ou-noir/",
      "/herbier/ail-vieilli-ou-noir",
      "/herbier/therapeutic-allium_sativum/",
      "/herbier/therapeutic-allium_sativum",
      "/herbier/therapeutic/allium_sativum/",
      "/herbier/therapeutic/allium_sativum",
      "/herbier/allium_sativum/",
      "/herbier/allium_sativum"
    ],
    "title": "Ail (Vieilli ou Noir)",
    "subtitle": "Pharmacie Intérieure (Cardiovasculaire & Antimicrobien) — L'ail vieilli contient de la SAC, stable et hydrosoluble, qui inhibe l'Enzyme de Conversion de l'Angiotensine (ECA). L'a...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "35°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Gousses séchées de Ail (Vieilli ou Noir) (30g)",
      "Fraction dense de Ail (Vieilli ou Noir) (15g)"
    ],
    "sachetA": {
      "composition": [
        "Gousses séchées de Ail (Vieilli ou Noir) (30g)"
      ],
      "solvent": "Eau distillée + Glycérine (70/30)",
      "temp": "35°C",
      "duration": "4h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Ail (Vieilli ou Noir) (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Gousses séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine (70/30). Activer le cycle thermo-cinétique à 35°C pendant 4h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "S-allyl-cystéine (SAC)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Ajoène",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Allicine",
        "mechanism": "Fraction Volatile/Enzymatique ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Pungent de la médecine égyptienne et grecque, utilisé pour 'nettoyer les artères' et combattre les infections.",
    "precautions": [
      "Interactions possibles avec les anticoagulants."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Ail (Vieilli ou Noir)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Ail (Vieilli ou Noir) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 83,
    "gscClicks90d": 8,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-salix_alba",
    "slug": "saule-blanc",
    "canonicalUrl": "/recettes/phytotherapie/saule-blanc/",
    "oldUrls": [
      "/herbier/saule-blanc/",
      "/herbier/saule-blanc",
      "/herbier/therapeutic-salix_alba/",
      "/herbier/therapeutic-salix_alba",
      "/herbier/therapeutic/salix_alba/",
      "/herbier/therapeutic/salix_alba",
      "/herbier/salix_alba/",
      "/herbier/salix_alba"
    ],
    "title": "Saule Blanc",
    "subtitle": "Gâchette (Anti-inflammatoire) — La salicine est convertie par la flore intestinale en acide salicylique. Contrairement à l'aspirine de synthèse, le saul...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Écorce interne (Liber) de Saule Blanc (30g)",
      "Fraction dense de Saule Blanc (15g)"
    ],
    "sachetA": {
      "composition": [
        "Écorce interne (Liber) de Saule Blanc (30g)"
      ],
      "solvent": "Eau distillée + Glycérine",
      "temp": "80°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Saule Blanc (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Écorce interne (Liber) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine. Activer le cycle thermo-cinétique à 80°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Salicine (Hétéroside phénolique)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes & Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Remède ancestral contre la douleur et la fièvre, utilisé par Hippocrate et les peuples amérindiens.",
    "precautions": [
      "Contre-indiqué en cas d'allergie aux salicylés ou de traitement anticoagulant."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Saule Blanc",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Saule Blanc — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 44,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-berberis_vulgaris",
    "slug": "epine-vinette",
    "canonicalUrl": "/recettes/phytotherapie/epine-vinette/",
    "oldUrls": [
      "/herbier/epine-vinette/",
      "/herbier/epine-vinette",
      "/herbier/therapeutic-berberis_vulgaris/",
      "/herbier/therapeutic-berberis_vulgaris",
      "/herbier/therapeutic/berberis_vulgaris/",
      "/herbier/therapeutic/berberis_vulgaris",
      "/herbier/berberis_vulgaris/",
      "/herbier/berberis_vulgaris"
    ],
    "title": "Épine-vinette",
    "subtitle": "Verrou (Métabolisme & Glycémie) — La berbérine est un activateur puissant de l'AMPK (protéine kinase activée par l'AMP), régulant le métabolisme du glucos...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "60°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Écorce de racine ou de tige de Épine-vinette (30g)",
      "Fraction dense de Épine-vinette (15g)"
    ],
    "sachetA": {
      "composition": [
        "Écorce de racine ou de tige de Épine-vinette (30g)"
      ],
      "solvent": "Eau distillée + Glycérine",
      "temp": "75°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Épine-vinette (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "60°C",
      "duration": "4h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Écorce de racine ou de tige afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine. Activer le cycle thermo-cinétique à 75°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 60°C pendant 4h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Berbérine (Alcaloïde)",
        "mechanism": "Fraction Peu hydrosoluble / Alcoolosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Berbamine",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisé en médecine persane et chinoise pour 'nettoyer le foie' et rafraîchir le sang.",
    "precautions": [
      "Ne pas utiliser pendant la grossesse. Peut interférer avec certains médicaments métabolisés par le foie (CYP450)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Épine-vinette",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Épine-vinette — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 45,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-crataegus_monogyna",
    "slug": "aubepine",
    "canonicalUrl": "/recettes/phytotherapie/aubepine/",
    "oldUrls": [
      "/herbier/aubepine/",
      "/herbier/aubepine",
      "/herbier/therapeutic-crataegus_monogyna/",
      "/herbier/therapeutic-crataegus_monogyna",
      "/herbier/therapeutic/crataegus_monogyna/",
      "/herbier/therapeutic/crataegus_monogyna",
      "/herbier/crataegus_monogyna/",
      "/herbier/crataegus_monogyna"
    ],
    "title": "Aubépine",
    "subtitle": "Chef d'Orchestre (Cœur & Système Nerveux) — Action inotrope positive et chronotrope négative (renforce le cœur et ralentit le rythme). Régule la tension artérielle ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités fleuries et fruits de Aubépine (30g)",
      "Fraction dense de Aubépine (15g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités fleuries et fruits de Aubépine (30g)"
      ],
      "solvent": "Eau distillée + Glycérine",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Aubépine (15g)"
      ],
      "solvent": "Alcool bio 45°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Sommités fleuries et fruits afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + Glycérine. Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 45° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Vitexine / Hypéroside",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Proanthocyanidines (OPC)",
        "mechanism": "Fraction Hydrosoluble/Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Plante du cœur physique et émotionnel, utilisée depuis le Moyen Âge pour 'chasser les peines'.",
    "precautions": [
      "Généralement très sûre. Prudence en cas de prise de digitaliques (digoxine)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Aubépine",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Aubépine — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 86,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-cinchona_succirubra",
    "slug": "quinquina-rouge",
    "canonicalUrl": "/recettes/phytotherapie/quinquina-rouge/",
    "oldUrls": [
      "/herbier/quinquina-rouge/",
      "/herbier/quinquina-rouge",
      "/herbier/therapeutic-cinchona_succirubra/",
      "/herbier/therapeutic-cinchona_succirubra",
      "/herbier/therapeutic/cinchona_succirubra/",
      "/herbier/therapeutic/cinchona_succirubra",
      "/herbier/cinchona_succirubra/",
      "/herbier/cinchona_succirubra"
    ],
    "title": "Quinquina Rouge",
    "subtitle": "Moteur (Tonique & Vitalité) — La quinine possède des propriétés antipyrétiques, antipaludéennes et toniques amères. Stimule les sécrétions digestives ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "85°C",
    "tempSachetB": "60°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1",
      "T2"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Écorce séchée de Quinquina Rouge (30g)",
      "Fraction dense de Quinquina Rouge (15g)"
    ],
    "sachetA": {
      "composition": [
        "Écorce séchée de Quinquina Rouge (30g)"
      ],
      "solvent": "Eau + Acide Citrique (léger)",
      "temp": "85°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Quinquina Rouge (15g)"
      ],
      "solvent": "Alcool bio 96°",
      "temp": "60°C",
      "duration": "4h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Écorce séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau + Acide Citrique (léger). Activer le cycle thermo-cinétique à 85°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 60°C pendant 4h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Quinine / Quinidine (Alcaloïdes)",
        "mechanism": "Fraction Peu hydrosoluble / Très soluble dans l'alcool ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Tanins cinchoniques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Plante sacrée des Andes, introduite en Europe au XVIIe siècle pour sauver les têtes couronnées de la fièvre.",
    "precautions": [
      "Interdit en cas de grossesse ou de troubles graves du rythme cardiaque."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Quinquina Rouge",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Quinquina Rouge — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 87,
    "gscClicks90d": 8,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-taraxacum_officinale",
    "slug": "pissenlit",
    "canonicalUrl": "/recettes/phytotherapie/pissenlit/",
    "oldUrls": [
      "/herbier/pissenlit/",
      "/herbier/pissenlit",
      "/herbier/therapeutic-taraxacum_officinale/",
      "/herbier/therapeutic-taraxacum_officinale",
      "/herbier/therapeutic/taraxacum_officinale/",
      "/herbier/therapeutic/taraxacum_officinale",
      "/herbier/taraxacum_officinale/",
      "/herbier/taraxacum_officinale"
    ],
    "title": "Pissenlit",
    "subtitle": "Médiateur (Détoxication & Digestion) — Stimulation de la diurèse (augmentation du volume d'urine) sans perte de potassium. Effet cholérétique et cholagogue fac...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T2",
      "T1"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Feuilles et Racines de Pissenlit (30g)",
      "Fraction dense de Pissenlit (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles et Racines de Pissenlit (30g)"
      ],
      "solvent": "Eau purifiée",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Pissenlit (15g)"
      ],
      "solvent": "Eau / Glycérine",
      "temp": "45°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles et Racines afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau purifiée. Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Eau / Glycérine pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Principes amers (Lactones)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Potassium",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé depuis l'Antiquité pour 'nettoyer les filtres' du corps au printemps.",
    "precautions": [
      "Prudence en cas de calculs biliaires. Effet diurétique marqué."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Pissenlit",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Pissenlit — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 88,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-ribes_nigrum",
    "slug": "cassis",
    "canonicalUrl": "/recettes/phytotherapie/cassis/",
    "oldUrls": [
      "/herbier/cassis/",
      "/herbier/cassis",
      "/herbier/therapeutic-ribes_nigrum/",
      "/herbier/therapeutic-ribes_nigrum",
      "/herbier/therapeutic/ribes_nigrum/",
      "/herbier/therapeutic/ribes_nigrum",
      "/herbier/ribes_nigrum/",
      "/herbier/ribes_nigrum"
    ],
    "title": "Cassis",
    "subtitle": "Médiateur (Anti-inflammatoire & Vitalité) — Effet 'cortisone-like' naturel en stimulant doucement les glandes surrénales. Puissant antioxydant et anti-inflammatoire...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "55°C",
    "tempSachetB": "40°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6",
      "T8"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Feuilles et Baies de Cassis (30g)",
      "Fraction dense de Cassis (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles et Baies de Cassis (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "55°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Cassis (15g)"
      ],
      "solvent": "Glycérine",
      "temp": "40°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles et Baies afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 55°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Glycérine pour extraire la fraction lipophile et les principes actifs thermosensibles à 40°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Anthocyanes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes (Quercétine)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Vitamine C",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Surnommé 'l'élixir de vie' au XVIIIe siècle pour ses propriétés polyvalentes.",
    "precautions": [
      "Prudence en cas d'insuffisance cardiaque ou rénale sévère."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cassis",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Cassis — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 49,
    "gscClicks90d": 4,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-melissa_officinalis",
    "slug": "melisse",
    "canonicalUrl": "/recettes/phytotherapie/melisse/",
    "oldUrls": [
      "/herbier/melisse/",
      "/herbier/melisse",
      "/herbier/therapeutic-melissa_officinalis/",
      "/herbier/therapeutic-melissa_officinalis",
      "/herbier/therapeutic/melissa_officinalis/",
      "/herbier/therapeutic/melissa_officinalis",
      "/herbier/melissa_officinalis/",
      "/herbier/melissa_officinalis"
    ],
    "title": "Mélisse",
    "subtitle": "Médiateur (Apaisement & Digestion) — Action antispasmodique sur le tube digestif et régulatrice du système nerveux. Aide à l'endormissement et réduit l'anxié...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "35°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4",
      "T1"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Feuilles de Mélisse (30g)",
      "Fraction dense de Mélisse (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles de Mélisse (30g)"
      ],
      "solvent": "Eau / Glycérine",
      "temp": "45°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Mélisse (15g)"
      ],
      "solvent": "Eau",
      "temp": "35°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau / Glycérine. Activer le cycle thermo-cinétique à 45°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Eau pour extraire la fraction lipophile et les principes actifs thermosensibles à 35°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acide Rosmarinique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Huiles essentielles (Citral)",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Ingrédient principal de 'l'Eau des Carmes', célèbre remède de réconfort depuis le XVIIe siècle.",
    "precautions": [
      "Généralement sans danger. Peut interférer avec les traitements thyroïdiens à très haute dose."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Mélisse",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Mélisse — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 65,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-passiflora_incarnata",
    "slug": "passiflore",
    "canonicalUrl": "/recettes/phytotherapie/passiflore/",
    "oldUrls": [
      "/herbier/passiflore/",
      "/herbier/passiflore",
      "/herbier/therapeutic-passiflora_incarnata/",
      "/herbier/therapeutic-passiflora_incarnata",
      "/herbier/therapeutic/passiflora_incarnata/",
      "/herbier/therapeutic/passiflora_incarnata",
      "/herbier/passiflora_incarnata/",
      "/herbier/passiflora_incarnata"
    ],
    "title": "Passiflore",
    "subtitle": "Médiateur (Sédation Douce) — Augmentation des niveaux de GABA dans le cerveau, favorisant la détente musculaire et nerveuse sans accoutumance....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Parties aériennes de Passiflore (30g)",
      "Fraction dense de Passiflore (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes de Passiflore (30g)"
      ],
      "solvent": "Eau",
      "temp": "60°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Passiflore (15g)"
      ],
      "solvent": "Alcool bio 45°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau. Activer le cycle thermo-cinétique à 60°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 45° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Flavonoïdes (Vitexine)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Alcaloïdes (Harmala)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Découverte par les missionnaires en Amérique, associée à la Passion pour sa structure florale unique.",
    "precautions": [
      "Éviter avec d'autres sédatifs puissants ou antidépresseurs IMAO."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Passiflore",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Passiflore — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 66,
    "gscClicks90d": 8,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-valeriana_officinalis",
    "slug": "valeriane",
    "canonicalUrl": "/recettes/phytotherapie/valeriane/",
    "oldUrls": [
      "/herbier/valeriane/",
      "/herbier/valeriane",
      "/herbier/therapeutic-valeriana_officinalis/",
      "/herbier/therapeutic-valeriana_officinalis",
      "/herbier/therapeutic/valeriana_officinalis/",
      "/herbier/therapeutic/valeriana_officinalis",
      "/herbier/valeriana_officinalis/",
      "/herbier/valeriana_officinalis"
    ],
    "title": "Valériane",
    "subtitle": "Gâchette (Sommeil Profond) — Réduit le temps d'endormissement et améliore la qualité du sommeil profond. Action sur les récepteurs GABA....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "50°C",
    "tempSachetB": "40°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Racines et Rhizomes de Valériane (30g)",
      "Fraction dense de Valériane (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racines et Rhizomes de Valériane (30g)"
      ],
      "solvent": "Eau / Alcool 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Valériane (15g)"
      ],
      "solvent": "Alcool",
      "temp": "40°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racines et Rhizomes afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau / Alcool 70°. Activer le cycle thermo-cinétique à 50°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool pour extraire la fraction lipophile et les principes actifs thermosensibles à 40°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acide valérénique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Valépotriates",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Le 'Phu' des Grecs anciens, utilisé pour calmer les nerfs et les spasmes.",
    "precautions": [
      "Odeur caractéristique puissante. Éviter avant de conduire."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Valériane",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Valériane — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 67,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-eschscholzia_californica",
    "slug": "eschscholtzia",
    "canonicalUrl": "/recettes/phytotherapie/eschscholtzia/",
    "oldUrls": [
      "/herbier/eschscholtzia/",
      "/herbier/eschscholtzia",
      "/herbier/therapeutic-eschscholzia_californica/",
      "/herbier/therapeutic-eschscholzia_californica",
      "/herbier/therapeutic/eschscholzia_californica/",
      "/herbier/therapeutic/eschscholzia_californica",
      "/herbier/eschscholzia_californica/",
      "/herbier/eschscholzia_californica"
    ],
    "title": "Eschscholtzia",
    "subtitle": "Médiateur (Sommeil & Relaxation) — Action anxiolytique et sédative légère sans accoutumance. Aide à maintenir le sommeil tout au long de la nuit....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "55°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Parties aériennes fleuries de Eschscholtzia (30g)",
      "Fraction dense de Eschscholtzia (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes fleuries de Eschscholtzia (30g)"
      ],
      "solvent": "Eau / Glycérine",
      "temp": "55°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Eschscholtzia (15g)"
      ],
      "solvent": "Alcool bio 45°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes fleuries afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau / Glycérine. Activer le cycle thermo-cinétique à 55°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 45° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Alcaloïdes (Pavine)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Le 'Pavot de Californie', utilisé par les Amérindiens pour apaiser les enfants et les douleurs.",
    "precautions": [
      "Généralement très sûr. Éviter en cas de glaucome."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Eschscholtzia",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Eschscholtzia — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 68,
    "gscClicks90d": 6,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-rosmarinus_officinalis",
    "slug": "romarin",
    "canonicalUrl": "/recettes/phytotherapie/romarin/",
    "oldUrls": [
      "/herbier/romarin/",
      "/herbier/romarin",
      "/herbier/therapeutic-rosmarinus_officinalis/",
      "/herbier/therapeutic-rosmarinus_officinalis",
      "/herbier/therapeutic/rosmarinus_officinalis/",
      "/herbier/therapeutic/rosmarinus_officinalis",
      "/herbier/rosmarinus_officinalis/",
      "/herbier/rosmarinus_officinalis"
    ],
    "title": "Romarin",
    "subtitle": "Gâchette (Dynamisation & Foie) — Puissant antioxydant protecteur du foie et stimulant de la concentration et de la mémoire (neuroprotection)....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Feuilles et Sommités fleuries de Romarin (30g)",
      "Fraction dense de Romarin (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles et Sommités fleuries de Romarin (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Romarin (15g)"
      ],
      "solvent": "Eau / Alcool",
      "temp": "45°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles et Sommités fleuries afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 65°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Eau / Alcool pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acide Rosmarinique",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Diterpènes (Carnosol)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Huiles essentielles (Cinole)",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "L'herbe du souvenir et de la fidélité, utilisée pour 'éclaircir l'esprit' et fortifier le corps.",
    "precautions": [
      "Éviter à haute dose en cas d'hypertension sévère le soir (stimulant)."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Romarin",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Romarin — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 69,
    "gscClicks90d": 7,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-lavandula_angustifolia",
    "slug": "lavande",
    "canonicalUrl": "/recettes/phytotherapie/lavande/",
    "oldUrls": [
      "/herbier/lavande/",
      "/herbier/lavande",
      "/herbier/therapeutic-lavandula_angustifolia/",
      "/herbier/therapeutic-lavandula_angustifolia",
      "/herbier/therapeutic/lavandula_angustifolia/",
      "/herbier/therapeutic/lavandula_angustifolia",
      "/herbier/lavandula_angustifolia/",
      "/herbier/lavandula_angustifolia"
    ],
    "title": "Lavande",
    "subtitle": "Médiateur (Apaisement & Harmonie) — Action anxiolytique démontrée par inhalation et ingestion. Régule l'humeur et apaise les tensions nerveuses....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "35°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Fleurs séchées de Lavande (30g)",
      "Fraction dense de Lavande (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fleurs séchées de Lavande (30g)"
      ],
      "solvent": "Eau / Glycérine",
      "temp": "45°C",
      "duration": "1h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Lavande (15g)"
      ],
      "solvent": "Eau",
      "temp": "35°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fleurs séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau / Glycérine. Activer le cycle thermo-cinétique à 45°C pendant 1h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Eau pour extraire la fraction lipophile et les principes actifs thermosensibles à 35°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Linalol",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acétate de linalyle",
        "mechanism": "Fraction Volatile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Tanins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée dans les bains romains pour ses vertus purifiantes et apaisantes.",
    "precautions": [
      "Généralement très sûre. Prudence en cas d'hypotension."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lavande",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Lavande — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 70,
    "gscClicks90d": 8,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-artichaut",
    "slug": "artichaut",
    "canonicalUrl": "/recettes/phytotherapie/artichaut/",
    "oldUrls": [
      "/herbier/artichaut/",
      "/herbier/artichaut",
      "/herbier/therapeutic-artichaut/",
      "/herbier/therapeutic-artichaut",
      "/herbier/therapeutic/artichaut/",
      "/herbier/therapeutic/artichaut",
      "/herbier/artichaut/",
      "/herbier/artichaut"
    ],
    "title": "Artichaut",
    "subtitle": "Médiateur (Soutien Hépatique) — La cynarine et les acides phénoliques stimulent la sécrétion biliaire (effet cholérétique) et son évacuation (effet chol...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Feuilles séchées de Artichaut (30g)",
      "Fraction dense de Artichaut (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles séchées de Artichaut (30g)"
      ],
      "solvent": "Eau purifiée",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Artichaut (15g)"
      ],
      "solvent": "Glycérine / Eau",
      "temp": "45°C",
      "duration": "1h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau purifiée. Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Glycérine / Eau pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 1h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Cynarine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acides phénoliques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Lutéoline",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Inuline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Utilisé depuis l'Égypte ancienne pour favoriser la digestion. En Europe, il est le remède phare du drainage hépato-biliaire.",
    "precautions": [
      "Contre-indiqué en cas d'obstruction des voies biliaires ou d'allergie aux Astéracées."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 71,
    "gscClicks90d": 5,
    "batchNumber": 2,
    "batchPriority": "haute",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-saule_blanc",
    "slug": "saule-blanc-gachette-anti-douleur",
    "canonicalUrl": "/recettes/phytotherapie/saule-blanc-gachette-anti-douleur/",
    "oldUrls": [
      "/herbier/saule-blanc/",
      "/herbier/saule-blanc",
      "/herbier/therapeutic-saule_blanc/",
      "/herbier/therapeutic-saule_blanc",
      "/herbier/therapeutic/saule_blanc/",
      "/herbier/therapeutic/saule_blanc",
      "/herbier/saule_blanc/",
      "/herbier/saule_blanc"
    ],
    "title": "Saule Blanc",
    "subtitle": "Gâchette (Anti-douleur) — Inhibition COX-2, protection muqueuses par tannins....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T8",
      "T1"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Écorce de Saule Blanc (30g)",
      "Fraction dense de Saule Blanc (15g)"
    ],
    "sachetA": {
      "composition": [
        "Écorce de Saule Blanc (30g)"
      ],
      "solvent": "Eau/Glycérine",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Saule Blanc (15g)"
      ],
      "solvent": "Alcool 70°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Écorce afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau/Glycérine. Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Salicine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Tannins",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Grèce : calme la douleur.",
    "precautions": [
      "Allergie aspirine, <16 ans."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Saule Blanc",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Saule Blanc — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 27,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-valeriane",
    "slug": "valeriane-verrou-sommeil-anxiete",
    "canonicalUrl": "/recettes/phytotherapie/valeriane-verrou-sommeil-anxiete/",
    "oldUrls": [
      "/herbier/valeriane/",
      "/herbier/valeriane",
      "/herbier/therapeutic-valeriane/",
      "/herbier/therapeutic-valeriane",
      "/herbier/therapeutic/valeriane/",
      "/herbier/therapeutic/valeriane",
      "/herbier/valeriane/",
      "/herbier/valeriane"
    ],
    "title": "Valériane",
    "subtitle": "Verrou (Sommeil & Anxiété) — Modulation GABA-A, latence endormissement....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T7",
      "T9"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Racine de Valériane (30g)",
      "Fraction dense de Valériane (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine de Valériane (30g)"
      ],
      "solvent": "Eau/Glycérine",
      "temp": "65°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Valériane (15g)"
      ],
      "solvent": "Alcool 96°",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau/Glycérine. Activer le cycle thermo-cinétique à 65°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Acide valérénique",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Valépotriates",
        "mechanism": "Fraction Très thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Grèce antique.",
    "precautions": [
      "Somnolence, grossesse."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Valériane",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Valériane — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-artichaut_souverain",
    "slug": "artichaut-reparateur-hepatique-biliaire",
    "canonicalUrl": "/recettes/phytotherapie/artichaut-reparateur-hepatique-biliaire/",
    "oldUrls": [
      "/herbier/artichaut/",
      "/herbier/artichaut",
      "/herbier/therapeutic-artichaut_souverain/",
      "/herbier/therapeutic-artichaut_souverain",
      "/herbier/therapeutic/artichaut_souverain/",
      "/herbier/therapeutic/artichaut_souverain",
      "/herbier/artichaut_souverain/",
      "/herbier/artichaut_souverain"
    ],
    "title": "Artichaut",
    "subtitle": "Réparateur (Hépatique & Biliaire) — Stimulation cholérétique, réduction cholestérol, prébiotique....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T10"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Feuilles de Artichaut (30g)",
      "Fraction dense de Artichaut (15g)"
    ],
    "sachetA": {
      "composition": [
        "Feuilles de Artichaut (30g)"
      ],
      "solvent": "Eau/Glycérine",
      "temp": "70°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Artichaut (15g)"
      ],
      "solvent": "Alcool 96°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Feuilles afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau/Glycérine. Activer le cycle thermo-cinétique à 70°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Cynarine",
        "mechanism": "Fraction Thermolabile ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Inuline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Égypte ancienne.",
    "precautions": [
      "Calculs biliaires obstructifs."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-millepertuis",
    "slug": "millepertuis",
    "canonicalUrl": "/recettes/phytotherapie/millepertuis/",
    "oldUrls": [
      "/herbier/millepertuis/",
      "/herbier/millepertuis",
      "/herbier/therapeutic-millepertuis/",
      "/herbier/therapeutic-millepertuis",
      "/herbier/therapeutic/millepertuis/",
      "/herbier/therapeutic/millepertuis",
      "/herbier/millepertuis/",
      "/herbier/millepertuis"
    ],
    "title": "Millepertuis",
    "subtitle": "Verrou (Neurochimie) — Inhibition recapture sérotonine/dopamine/noradrénaline....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "60°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Parties aériennes de Millepertuis (30g)",
      "Fraction dense de Millepertuis (15g)"
    ],
    "sachetA": {
      "composition": [
        "Parties aériennes de Millepertuis (30g)"
      ],
      "solvent": "Eau/Glycérine",
      "temp": "60°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Millepertuis (15g)"
      ],
      "solvent": "Alcool 96°",
      "temp": "45°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Parties aériennes afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau/Glycérine. Activer le cycle thermo-cinétique à 60°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool 96° pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Hyperforine",
        "mechanism": "Fraction Liposoluble/Photosensible ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Hypericine",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Antiquité : protège l'âme.",
    "precautions": [
      "PHOTOSENSIBILISANT. JAMAIS avec ISRS/pilule."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Millepertuis",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Millepertuis — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 40,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-shiquandabutang",
    "slug": "shi-quan-da-bu-tang-la-grande-formule-de-reconstruction",
    "canonicalUrl": "/recettes/phytotherapie/shi-quan-da-bu-tang-la-grande-formule-de-reconstruction/",
    "oldUrls": [
      "/herbier/shi-quan-da-bu-tang-la-grande-formule-de-reconstruction/",
      "/herbier/shi-quan-da-bu-tang-la-grande-formule-de-reconstruction",
      "/herbier/therapeutic-shiquandabutang/",
      "/herbier/therapeutic-shiquandabutang",
      "/herbier/therapeutic/shiquandabutang/",
      "/herbier/therapeutic/shiquandabutang",
      "/herbier/shiquandabutang/",
      "/herbier/shiquandabutang"
    ],
    "title": "Shi Quan Da Bu Tang — La Grande Formule de Reconstruction",
    "subtitle": "Chef d’Orchestre (Qi, Sang, Convalescence) — Grande formule de la médecine chinoise, Shi Quan Da Bu Tang est utilisée depuis des siècles pour relever le Qi et le San...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T5",
      "T7",
      "T6"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Formule composée (racines, écorces, rhizomes) de Shi Quan Da Bu Tang — La Grande Formule de Reconstruction (30g)",
      "Fraction dense de Shi Quan Da Bu Tang — La Grande Formule de Reconstruction (15g)"
    ],
    "sachetA": {
      "composition": [
        "Formule composée (racines, écorces, rhizomes) de Shi Quan Da Bu Tang — La Grande Formule de Reconstruction (30g)"
      ],
      "solvent": "Eau distillée + glycérine légère",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Shi Quan Da Bu Tang — La Grande Formule de Reconstruction (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Formule composée (racines, écorces, rhizomes) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + glycérine légère. Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides toniques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Saponines",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Composés aromatiques chauds",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée en Chine pour relever Qi et Sang, souvent dans les états de fatigue profonde et de convalescence.",
    "precautions": [
      "À manier avec prudence en cas de terrain inflammatoire très actif, d’hypertension non contrôlée, de fièvre ou de surcharge digestive marquée."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Shi Quan Da Bu Tang — La Grande Formule de Reconstruction",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Shi Quan Da Bu Tang — La Grande Formule de Reconstruction — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 21,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-lycium_barbarum_herbarium",
    "slug": "lycium-barbarum-le-goji-nourrissant-du-sang",
    "canonicalUrl": "/recettes/phytotherapie/lycium-barbarum-le-goji-nourrissant-du-sang/",
    "oldUrls": [
      "/herbier/lycium-barbarum-le-goji-nourrissant-du-sang/",
      "/herbier/lycium-barbarum-le-goji-nourrissant-du-sang",
      "/herbier/therapeutic-lycium_barbarum_herbarium/",
      "/herbier/therapeutic-lycium_barbarum_herbarium",
      "/herbier/therapeutic/lycium_barbarum_herbarium/",
      "/herbier/therapeutic/lycium_barbarum_herbarium",
      "/herbier/lycium_barbarum_herbarium/",
      "/herbier/lycium_barbarum_herbarium"
    ],
    "title": "Lycium barbarum — Le Goji, Nourrissant du Sang",
    "subtitle": "Réparateur (Sang, Foie, Réserve) — Fruit majeur de la pharmacopée chinoise, le goji est traditionnellement orienté Foie-Rein, vision, longévité et soutien ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "72°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T2",
      "T9",
      "T5"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Baies séchées de Lycium barbarum — Le Goji, Nourrissant du Sang (30g)",
      "Fraction dense de Lycium barbarum — Le Goji, Nourrissant du Sang (15g)"
    ],
    "sachetA": {
      "composition": [
        "Baies séchées de Lycium barbarum — Le Goji, Nourrissant du Sang (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "72°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Lycium barbarum — Le Goji, Nourrissant du Sang (15g)"
      ],
      "solvent": "Huile végétale légère ou alcool doux",
      "temp": "45°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Baies séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 72°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Huile végétale légère ou alcool doux pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides de Lycium (LBP)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Caroténoïdes (zéaxanthine)",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Composés phénoliques et bétaïne",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Fruit traditionnellement associé à la vision, à la longévité et au soutien du Sang.",
    "precautions": [
      "Prudence en cas de traitement anticoagulant ou de terrain très chaud/agité. Surveiller la tolérance digestive."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lycium barbarum — Le Goji, Nourrissant du Sang",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Lycium barbarum — Le Goji, Nourrissant du Sang — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 22,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-runfeitang",
    "slug": "run-fei-tang-formule-nourrissant-le-poumon",
    "canonicalUrl": "/recettes/phytotherapie/run-fei-tang-formule-nourrissant-le-poumon/",
    "oldUrls": [
      "/herbier/run-fei-tang-formule-nourrissant-le-poumon/",
      "/herbier/run-fei-tang-formule-nourrissant-le-poumon",
      "/herbier/therapeutic-runfeitang/",
      "/herbier/therapeutic-runfeitang",
      "/herbier/therapeutic/runfeitang/",
      "/herbier/therapeutic/runfeitang",
      "/herbier/runfeitang/",
      "/herbier/runfeitang"
    ],
    "title": "Run Fei Tang — Formule Nourrissant le Poumon",
    "subtitle": "Réparateur (Muqueuses, Poumon, Peau sèche) — Issue de la médecine chinoise, la logique Run-Fei vise à nourrir le Yin, humidifier les poumons et restaurer les barrièr...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "72°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T3",
      "T9",
      "T1"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Formule composée (fruits, graines, racines, matières adoucissantes) de Run Fei Tang — Formule Nourrissant le Poumon (30g)",
      "Fraction dense de Run Fei Tang — Formule Nourrissant le Poumon (15g)"
    ],
    "sachetA": {
      "composition": [
        "Formule composée (fruits, graines, racines, matières adoucissantes) de Run Fei Tang — Formule Nourrissant le Poumon (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "72°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Run Fei Tang — Formule Nourrissant le Poumon (15g)"
      ],
      "solvent": "Glycérine renforcée ou alcool doux",
      "temp": "45°C",
      "duration": "2h30"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Formule composée (fruits, graines, racines, matières adoucissantes) afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 72°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Glycérine renforcée ou alcool doux pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h30.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides et mucilages",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Saponines douces",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes nourrissants",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Formule chinoise pour “humidifier les poumons et arrêter la toux”.",
    "precautions": [
      "La composition exacte variant selon les écoles, vérifier chaque ingrédient en cas de grossesse, de diabète, d’allergies ou de traitement concomitant."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Run Fei Tang — Formule Nourrissant le Poumon",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Run Fei Tang — Formule Nourrissant le Poumon — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 23,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-ziziphus_jujuba_herbarium",
    "slug": "ziziphus-jujuba-le-jujube-harmonisateur-des-muqueuses",
    "canonicalUrl": "/recettes/phytotherapie/ziziphus-jujuba-le-jujube-harmonisateur-des-muqueuses/",
    "oldUrls": [
      "/herbier/ziziphus-jujuba-le-jujube-harmonisateur-des-muqueuses/",
      "/herbier/ziziphus-jujuba-le-jujube-harmonisateur-des-muqueuses",
      "/herbier/therapeutic-ziziphus_jujuba_herbarium/",
      "/herbier/therapeutic-ziziphus_jujuba_herbarium",
      "/herbier/therapeutic/ziziphus_jujuba_herbarium/",
      "/herbier/therapeutic/ziziphus_jujuba_herbarium",
      "/herbier/ziziphus_jujuba_herbarium/",
      "/herbier/ziziphus_jujuba_herbarium"
    ],
    "title": "Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses",
    "subtitle": "Harmonisateur (Qi, Muqueuses, Système nerveux) — Grand harmonisateur des terrains secs, épuisés, irrités ou trop mobilisés. Utilisé dans les médecines chinoise, persane ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "45°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T3",
      "T7",
      "T2",
      "T9"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Fruit séché de Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses (30g)",
      "Fraction dense de Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses (15g)"
    ],
    "sachetA": {
      "composition": [
        "Fruit séché de Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "70°C",
      "duration": "1h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses (15g)"
      ],
      "solvent": "Alcool doux ou glycérine végétale renforcée",
      "temp": "45°C",
      "duration": "2h30"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Fruit séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 70°C pendant 1h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool doux ou glycérine végétale renforcée pour extraire la fraction lipophile et les principes actifs thermosensibles à 45°C pendant 2h30.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides, flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Saponines",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Tritérpénoïdes",
        "mechanism": "Fraction Liposoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Fruit majeur des médecines chinoise, persane et islamique, relié à l’apaisement, au Sang et aux muqueuses.",
    "precautions": [
      "Prudence en cas de diabète mal équilibré ou de sensibilité digestive aux fruits très concentrés."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Ziziphus jujuba — Le Jujube, Harmonisateur des Muqueuses — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 24,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-schisandra_chinensis_herbarium",
    "slug": "schisandra-chinensis-la-baie-des-cinq-saveurs",
    "canonicalUrl": "/recettes/phytotherapie/schisandra-chinensis-la-baie-des-cinq-saveurs/",
    "oldUrls": [
      "/herbier/schisandra-chinensis-la-baie-des-cinq-saveurs/",
      "/herbier/schisandra-chinensis-la-baie-des-cinq-saveurs",
      "/herbier/therapeutic-schisandra_chinensis_herbarium/",
      "/herbier/therapeutic-schisandra_chinensis_herbarium",
      "/herbier/therapeutic/schisandra_chinensis_herbarium/",
      "/herbier/therapeutic/schisandra_chinensis_herbarium",
      "/herbier/schisandra_chinensis_herbarium/",
      "/herbier/schisandra_chinensis_herbarium"
    ],
    "title": "Schisandra chinensis — La Baie des Cinq Saveurs",
    "subtitle": "Réparateur (Foie, Cellule, Adaptation) — Baie des cinq saveurs en médecine chinoise, symbole de convergence organique et de capacité à retenir, protéger et raffe...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "70°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T5",
      "T6",
      "T3"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Baies séchées de Schisandra chinensis — La Baie des Cinq Saveurs (30g)",
      "Fraction dense de Schisandra chinensis — La Baie des Cinq Saveurs (15g)"
    ],
    "sachetA": {
      "composition": [
        "Baies séchées de Schisandra chinensis — La Baie des Cinq Saveurs (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "70°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Schisandra chinensis — La Baie des Cinq Saveurs (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Baies séchées afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 70°C pendant 1h30.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Lignanes de schisandra",
        "mechanism": "Fraction Liposoluble/Alcoolosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Acides organiques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Composés phénoliques",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Symbole de convergence organique, utilisée pour retenir et protéger la vitalité.",
    "precautions": [
      "Prudence en cas de reflux sévère, d’ulcère actif ou de traitement hépatique spécifique."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Schisandra chinensis — La Baie des Cinq Saveurs",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Schisandra chinensis — La Baie des Cinq Saveurs — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 25,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-arctium_lappa_herbarium",
    "slug": "arctium-lappa-la-bardane-grand-depuratif",
    "canonicalUrl": "/recettes/phytotherapie/arctium-lappa-la-bardane-grand-depuratif/",
    "oldUrls": [
      "/herbier/arctium-lappa-la-bardane-grand-depuratif/",
      "/herbier/arctium-lappa-la-bardane-grand-depuratif",
      "/herbier/therapeutic-arctium_lappa_herbarium/",
      "/herbier/therapeutic-arctium_lappa_herbarium",
      "/herbier/therapeutic/arctium_lappa_herbarium/",
      "/herbier/therapeutic/arctium_lappa_herbarium",
      "/herbier/arctium_lappa_herbarium/",
      "/herbier/arctium_lappa_herbarium"
    ],
    "title": "Arctium lappa — La Bardane, Grand Dépuratif",
    "subtitle": "Déclencheur (Peau–Foie–Intestin) — Grande dépurative des traditions européennes et asiatiques, la bardane est utilisée depuis l’Antiquité pour ses propriét...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T2",
      "T2",
      "T9"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Racine séchée de Arctium lappa — La Bardane, Grand Dépuratif (30g)",
      "Fraction dense de Arctium lappa — La Bardane, Grand Dépuratif (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Arctium lappa — La Bardane, Grand Dépuratif (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Arctium lappa — La Bardane, Grand Dépuratif (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Inuline",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Arctiine/arctigénine",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Acides phénoliques (chlorogénique)",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Lignanes",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Études pharmacologiques in vivo & modèles cellulaires"
      }
    ],
    "traditionalWisdom": "Utilisée en Europe et en Asie pour “purifier le sang” et traiter les affections cutanées.",
    "precautions": [
      "Prudence en cas d’hypoglycémie, d’allergie aux Astéracées, de grossesse ou d’allaitement sans avis professionnel."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Arctium lappa — La Bardane, Grand Dépuratif",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Arctium lappa — La Bardane, Grand Dépuratif — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 26,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-astragalus_membranaceus_herbarium",
    "slug": "astragalus-membranaceus-l-astragale-protecteur-du-qi",
    "canonicalUrl": "/recettes/phytotherapie/astragalus-membranaceus-l-astragale-protecteur-du-qi/",
    "oldUrls": [
      "/herbier/astragalus-membranaceus-l-astragale-protecteur-du-qi/",
      "/herbier/astragalus-membranaceus-l-astragale-protecteur-du-qi",
      "/herbier/therapeutic-astragalus_membranaceus_herbarium/",
      "/herbier/therapeutic-astragalus_membranaceus_herbarium",
      "/herbier/therapeutic/astragalus_membranaceus_herbarium/",
      "/herbier/therapeutic/astragalus_membranaceus_herbarium",
      "/herbier/astragalus_membranaceus_herbarium/",
      "/herbier/astragalus_membranaceus_herbarium"
    ],
    "title": "Astragalus membranaceus — L’Astragale, Protecteur du Qi",
    "subtitle": "Chef d’Orchestre (Immunité, Barrière, Réserve) — Grand tonique du Qi protecteur en médecine chinoise, l’astragale est historiquement associé à la résistance, à la récupé...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "75°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T5",
      "T6",
      "T1"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Racine séchée de Astragalus membranaceus — L’Astragale, Protecteur du Qi (30g)",
      "Fraction dense de Astragalus membranaceus — L’Astragale, Protecteur du Qi (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Astragalus membranaceus — L’Astragale, Protecteur du Qi (30g)"
      ],
      "solvent": "Eau distillée + glycérine légère",
      "temp": "75°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Astragalus membranaceus — L’Astragale, Protecteur du Qi (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + glycérine légère. Activer le cycle thermo-cinétique à 75°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Polysaccharides d’astragale",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Astragalosides",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Grand tonique du Qi protecteur en médecine chinoise.",
    "precautions": [
      "Prudence en cas de maladie auto-immune active, d’immunosuppresseurs ou d’hypertension mal contrôlée."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Astragalus membranaceus — L’Astragale, Protecteur du Qi",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Astragalus membranaceus — L’Astragale, Protecteur du Qi — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 27,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-ganoderma_lucidum_herbarium",
    "slug": "ganoderma-lucidum-le-reishi-champignon-de-longevite",
    "canonicalUrl": "/recettes/phytotherapie/ganoderma-lucidum-le-reishi-champignon-de-longevite/",
    "oldUrls": [
      "/herbier/ganoderma-lucidum-le-reishi-champignon-de-longevite/",
      "/herbier/ganoderma-lucidum-le-reishi-champignon-de-longevite",
      "/herbier/therapeutic-ganoderma_lucidum_herbarium/",
      "/herbier/therapeutic-ganoderma_lucidum_herbarium",
      "/herbier/therapeutic/ganoderma_lucidum_herbarium/",
      "/herbier/therapeutic/ganoderma_lucidum_herbarium",
      "/herbier/ganoderma_lucidum_herbarium/",
      "/herbier/ganoderma_lucidum_herbarium"
    ],
    "title": "Ganoderma lucidum — Le Reishi, Champignon de Longévité",
    "subtitle": "Chef d’Orchestre (Immunité, Stress, Longévité) — Champignon de longévité et de stabilité intérieure dans les traditions chinoise et japonaise, le Reishi est recherché po...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Mycélium interconnecté et sporophores adaptatifs croissant en symbiose avec les arbres séculaires.",
      "doctrineInterpretation": "Les champignons sylvestres symbolisent la communication systémique, l’endurance face aux rigueurs climatiques et l’immunité maîtresse.",
      "organTarget": "Système immunitaire inné, axe neuro-endocrinien et vitalité mitochondriale"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T5",
      "T6",
      "T7"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Champignon séché de Ganoderma lucidum — Le Reishi, Champignon de Longévité (30g)",
      "Fraction dense de Ganoderma lucidum — Le Reishi, Champignon de Longévité (15g)"
    ],
    "sachetA": {
      "composition": [
        "Champignon séché de Ganoderma lucidum — Le Reishi, Champignon de Longévité (30g)"
      ],
      "solvent": "Eau distillée + glycérine légère",
      "temp": "80°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Ganoderma lucidum — Le Reishi, Champignon de Longévité (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "3h00"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Champignon séché afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée + glycérine légère. Activer le cycle thermo-cinétique à 80°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 3h00.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Bêta-glucanes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Triterpènes",
        "mechanism": "Fraction Liposoluble/Alcoolosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Polysaccharides",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "“Ling Zhi” en chinois, champignon de l’immortalité utilisé pour calmer l’esprit et tonifier le Qi.",
    "precautions": [
      "Prudence en cas d’anticoagulants, de chirurgie proche, de maladie auto-immune active ou d’allergie aux champignons."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Ganoderma lucidum — Le Reishi, Champignon de Longévité",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Ganoderma lucidum — Le Reishi, Champignon de Longévité — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-glycyrrhiza_glabra_herbarium",
    "slug": "glycyrrhiza-glabra-la-reglisse-catalyseur-et-protecteur",
    "canonicalUrl": "/recettes/phytotherapie/glycyrrhiza-glabra-la-reglisse-catalyseur-et-protecteur/",
    "oldUrls": [
      "/herbier/glycyrrhiza-glabra-la-reglisse-catalyseur-et-protecteur/",
      "/herbier/glycyrrhiza-glabra-la-reglisse-catalyseur-et-protecteur",
      "/herbier/therapeutic-glycyrrhiza_glabra_herbarium/",
      "/herbier/therapeutic-glycyrrhiza_glabra_herbarium",
      "/herbier/therapeutic/glycyrrhiza_glabra_herbarium/",
      "/herbier/therapeutic/glycyrrhiza_glabra_herbarium",
      "/herbier/glycyrrhiza_glabra_herbarium/",
      "/herbier/glycyrrhiza_glabra_herbarium"
    ],
    "title": "Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur",
    "subtitle": "Catalyseur (Muqueuses, Surrénales, Harmonie) — Racine millénaire des médecines chinoise, grecque et proche-orientale, la réglisse est utilisée pour adoucir, harmoniser...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "72°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T2",
      "T5",
      "T3"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Racine séchée de Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur (30g)",
      "Fraction dense de Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur (15g)"
    ],
    "sachetA": {
      "composition": [
        "Racine séchée de Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "72°C",
      "duration": "2h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur (15g)"
      ],
      "solvent": "Alcool bio 70°",
      "temp": "50°C",
      "duration": "2h30"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Racine séchée afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 72°C pendant 2h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter Alcool bio 70° pour extraire la fraction lipophile et les principes actifs thermosensibles à 50°C pendant 2h30.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Glycyrrhizine",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Flavonoïdes",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Saponines",
        "mechanism": "Fraction Mixte ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisée depuis l’Antiquité pour adoucir et harmoniser les tissus irrités.",
    "precautions": [
      "Contre-indiquée ou à surveiller étroitement en cas d’hypertension, d’hypokaliémie, d’insuffisance rénale, de grossesse ou de prise prolongée à dose élevée. Une consommation excessive peut entraîner une hypokaliémie et une hypertension artérielle."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Glycyrrhiza glabra — La Réglisse, Catalyseur et Protecteur — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-vigna_angularis_herbarium",
    "slug": "vigna-angularis-l-adzuki-drainant-nourrissant",
    "canonicalUrl": "/recettes/phytotherapie/vigna-angularis-l-adzuki-drainant-nourrissant/",
    "oldUrls": [
      "/herbier/vigna-angularis-l-adzuki-drainant-nourrissant/",
      "/herbier/vigna-angularis-l-adzuki-drainant-nourrissant",
      "/herbier/therapeutic-vigna_angularis_herbarium/",
      "/herbier/therapeutic-vigna_angularis_herbarium",
      "/herbier/therapeutic/vigna_angularis_herbarium/",
      "/herbier/therapeutic/vigna_angularis_herbarium",
      "/herbier/vigna_angularis_herbarium/",
      "/herbier/vigna_angularis_herbarium"
    ],
    "title": "Vigna angularis — L’Adzuki, Drainant Nourrissant",
    "subtitle": "Drainant nourrissant (Humidité, stagnation, surcharge) — Très utilisé en diététique asiatique pour alléger l’humidité, soutenir les reins au sens traditionnel et accompagner la ...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "85°C",
    "tempSachetB": "—",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T1",
      "T2",
      "T3",
      "T8"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Graine sèche de Vigna angularis — L’Adzuki, Drainant Nourrissant (30g)",
      "Fraction dense de Vigna angularis — L’Adzuki, Drainant Nourrissant (15g)"
    ],
    "sachetA": {
      "composition": [
        "Graine sèche de Vigna angularis — L’Adzuki, Drainant Nourrissant (30g)"
      ],
      "solvent": "Eau distillée",
      "temp": "85°C",
      "duration": "3h00"
    },
    "sachetB": {
      "composition": [
        "Fraction dense de Vigna angularis — L’Adzuki, Drainant Nourrissant (15g)"
      ],
      "solvent": "—",
      "temp": "—",
      "duration": "2h30"
    },
    "instructions": [
      "Étape 1 : Préparation des matières premières — Concasser délicatement Graine sèche afin de rompre la cuticule cellulaire sans broyage excessif.",
      "Étape 2 : Séquençage Sachet A — Introduire la phase A dans le panier inox BloomLab® avec Eau distillée. Activer le cycle thermo-cinétique à 85°C pendant 3h00.",
      "Étape 3 : Séquençage Sachet B — Après descente thermique contrôlée sous 50°C, ajouter — pour extraire la fraction lipophile et les principes actifs thermosensibles à — pendant 2h30.",
      "Étape 4 : Filtration et conditionnement — Réaliser une filtration fine sur tamis inox 304, puis presser doucement la matière végétale. Transférer dans un flacon en verre violet Miron ou ambré stérile.",
      "Étape 5 : Conservation optimale — Conserver à l’abri de la lumière et des variations de température. Utiliser dans les jours jours."
    ],
    "molecularSignature": [
      {
        "molecule": "Fibres solubles et insolubles",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Niveau de preuve Bloom A+ (Essais cliniques randomisés en double aveugle)"
      },
      {
        "molecule": "Polyphénols",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      },
      {
        "molecule": "Protéines végétales et minéraux",
        "mechanism": "Fraction Hydrosoluble ciblant la régulation du terrain cellulaire et la protection tissulaire contre le stress oxydatif.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisé en diététique asiatique pour alléger l’humidité et soutenir la récupération.",
    "precautions": [
      "Prudence en cas de faiblesse digestive marquée, de maigreur extrême ou de terrain déjà trop sec."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Vigna angularis — L’Adzuki, Drainant Nourrissant",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Vigna angularis — L’Adzuki, Drainant Nourrissant — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 20,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-recipe-artichaut-classique-750ml",
    "slug": "artichaut-classique-750-ml",
    "canonicalUrl": "/recettes/phytotherapie/artichaut-classique-750-ml/",
    "oldUrls": [
      "/herbier/artichaut-classique-750-ml/",
      "/herbier/artichaut-classique-750-ml",
      "/herbier/therapeutic-recipe-artichaut-classique-750ml/",
      "/herbier/therapeutic-recipe-artichaut-classique-750ml",
      "/herbier/therapeutic/recipe-artichaut-classique-750ml/",
      "/herbier/therapeutic/recipe-artichaut-classique-750ml",
      "/herbier/recipe-artichaut-classique-750ml/",
      "/herbier/recipe-artichaut-classique-750ml"
    ],
    "title": "Artichaut classique 750 ml",
    "subtitle": "Médiateur (Soutien Hépatique) — Extraire un concentré polyphénolique doux pour soutien hépatique quotidien....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T1",
      "T8"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "30g de Artichaut classique 750 ml séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Artichaut classique 750 ml séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Artichaut classique 750 ml une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut classique 750 ml",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut classique 750 ml — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 21,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-recipe-artichaut-intense-750ml",
    "slug": "artichaut-intense-750-ml",
    "canonicalUrl": "/recettes/phytotherapie/artichaut-intense-750-ml/",
    "oldUrls": [
      "/herbier/artichaut-intense-750-ml/",
      "/herbier/artichaut-intense-750-ml",
      "/herbier/therapeutic-recipe-artichaut-intense-750ml/",
      "/herbier/therapeutic-recipe-artichaut-intense-750ml",
      "/herbier/therapeutic/recipe-artichaut-intense-750ml/",
      "/herbier/therapeutic/recipe-artichaut-intense-750ml",
      "/herbier/recipe-artichaut-intense-750ml/",
      "/herbier/recipe-artichaut-intense-750ml"
    ],
    "title": "Artichaut intense 750 ml",
    "subtitle": "Médiateur (Soutien Hépatique) — Extraire un concentré plus riche en polyphénols avec une intensité supérieure....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T1",
      "T8"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "30g de Artichaut intense 750 ml séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Artichaut intense 750 ml séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Artichaut intense 750 ml une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut intense 750 ml",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut intense 750 ml — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 22,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-recipe-artichaut-citron-750ml",
    "slug": "artichaut-citron-750-ml",
    "canonicalUrl": "/recettes/phytotherapie/artichaut-citron-750-ml/",
    "oldUrls": [
      "/herbier/artichaut-citron-750-ml/",
      "/herbier/artichaut-citron-750-ml",
      "/herbier/therapeutic-recipe-artichaut-citron-750ml/",
      "/herbier/therapeutic-recipe-artichaut-citron-750ml",
      "/herbier/therapeutic/recipe-artichaut-citron-750ml/",
      "/herbier/therapeutic/recipe-artichaut-citron-750ml",
      "/herbier/recipe-artichaut-citron-750ml/",
      "/herbier/recipe-artichaut-citron-750ml"
    ],
    "title": "Artichaut + citron 750 ml",
    "subtitle": "Médiateur (Soutien Hépatique) — Stabiliser légèrement l'infusion grâce à l'acidification et améliorer la tolérance....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T1",
      "T8"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "30g de Artichaut + citron 750 ml séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Artichaut + citron 750 ml séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Artichaut + citron 750 ml une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut + citron 750 ml",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut + citron 750 ml — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 23,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-therapeutic-recipe-artichaut-base-quotidienne-24h",
    "slug": "artichaut-base-quotidienne-24-h",
    "canonicalUrl": "/recettes/phytotherapie/artichaut-base-quotidienne-24-h/",
    "oldUrls": [
      "/herbier/artichaut-base-quotidienne-24-h/",
      "/herbier/artichaut-base-quotidienne-24-h",
      "/herbier/therapeutic-recipe-artichaut-base-quotidienne-24h/",
      "/herbier/therapeutic-recipe-artichaut-base-quotidienne-24h",
      "/herbier/therapeutic/recipe-artichaut-base-quotidienne-24h/",
      "/herbier/therapeutic/recipe-artichaut-base-quotidienne-24h",
      "/herbier/recipe-artichaut-base-quotidienne-24h/",
      "/herbier/recipe-artichaut-base-quotidienne-24h"
    ],
    "title": "Artichaut base quotidienne 24 h",
    "subtitle": "Médiateur (Soutien Hépatique) — Protocole simple pour consommation journalière régulière....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique",
      "T4",
      "T1",
      "T8"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "30g de Artichaut base quotidienne 24 h séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Artichaut base quotidienne 24 h séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Artichaut base quotidienne 24 h une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Artichaut base quotidienne 24 h",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Artichaut base quotidienne 24 h — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 24,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-01",
    "slug": "infusion-sommeil-profond",
    "canonicalUrl": "/recettes/phytotherapie/infusion-sommeil-profond/",
    "oldUrls": [
      "/herbier/infusion-sommeil-profond/",
      "/herbier/infusion-sommeil-profond",
      "/herbier/extra-recipe-01/",
      "/herbier/extra-recipe-01",
      "/herbier/therapeutic/extra-recipe-01/",
      "/herbier/therapeutic/extra-recipe-01",
      "/herbier/extra-recipe-01/",
      "/herbier/extra-recipe-01"
    ],
    "title": "Infusion Sommeil Profond",
    "subtitle": "Protocole Spécifique — Un mélange apaisant pour favoriser l'endormissement et un sommeil réparateur par extraction séquentielle des actifs....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "30g de Infusion Sommeil Profond séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Infusion Sommeil Profond séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Infusion Sommeil Profond une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Infusion Sommeil Profond",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Infusion Sommeil Profond — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 25,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/culinaires/infusion-sommeil-profond/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-02",
    "slug": "huile-de-massage-articulaire",
    "canonicalUrl": "/recettes/phytotherapie/huile-de-massage-articulaire/",
    "oldUrls": [
      "/herbier/huile-de-massage-articulaire/",
      "/herbier/huile-de-massage-articulaire",
      "/herbier/extra-recipe-02/",
      "/herbier/extra-recipe-02",
      "/herbier/therapeutic/extra-recipe-02/",
      "/herbier/therapeutic/extra-recipe-02",
      "/herbier/extra-recipe-02/",
      "/herbier/extra-recipe-02"
    ],
    "title": "Huile de Massage Articulaire",
    "subtitle": "Protocole Spécifique — Une huile de soin concentrée pour soulager les tensions et l'inflammation par extraction liposoluble....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "30g de Huile de Massage Articulaire séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Huile de Massage Articulaire séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Huile de Massage Articulaire une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile de Massage Articulaire",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Huile de Massage Articulaire — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 26,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/cosmetiques/huile-massage-articulaire/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-03",
    "slug": "serum-visage-eclat-botanique",
    "canonicalUrl": "/recettes/phytotherapie/serum-visage-eclat-botanique/",
    "oldUrls": [
      "/herbier/serum-visage-eclat-botanique/",
      "/herbier/serum-visage-eclat-botanique",
      "/herbier/extra-recipe-03/",
      "/herbier/extra-recipe-03",
      "/herbier/therapeutic/extra-recipe-03/",
      "/herbier/therapeutic/extra-recipe-03",
      "/herbier/extra-recipe-03/",
      "/herbier/extra-recipe-03"
    ],
    "title": "Sérum Visage Éclat Botanique",
    "subtitle": "Protocole Spécifique — Un sérum précieux régénérant, conçu pour une pénétration cutanée optimale des actifs végétaux....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "30g de Sérum Visage Éclat Botanique séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Sérum Visage Éclat Botanique séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Sérum Visage Éclat Botanique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sérum Visage Éclat Botanique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Sérum Visage Éclat Botanique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 27,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/cosmetiques/serum-visage-eclat-botanique/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-04",
    "slug": "baume-a-levres-au-calendula",
    "canonicalUrl": "/recettes/phytotherapie/baume-a-levres-au-calendula/",
    "oldUrls": [
      "/herbier/baume-a-levres-au-calendula/",
      "/herbier/baume-a-levres-au-calendula",
      "/herbier/extra-recipe-04/",
      "/herbier/extra-recipe-04",
      "/herbier/therapeutic/extra-recipe-04/",
      "/herbier/therapeutic/extra-recipe-04",
      "/herbier/extra-recipe-04/",
      "/herbier/extra-recipe-04"
    ],
    "title": "Baume à Lèvres au Calendula",
    "subtitle": "Protocole Spécifique — Un baume protecteur et réparateur utilisant l'extraction par fusion contrôlée....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "30g de Baume à Lèvres au Calendula séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Baume à Lèvres au Calendula séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Baume à Lèvres au Calendula une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Baume à Lèvres au Calendula",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Baume à Lèvres au Calendula — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/cosmetiques/baume-levres-calendula/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-05",
    "slug": "teinture-de-propolis-maison",
    "canonicalUrl": "/recettes/phytotherapie/teinture-de-propolis-maison/",
    "oldUrls": [
      "/herbier/teinture-de-propolis-maison/",
      "/herbier/teinture-de-propolis-maison",
      "/herbier/extra-recipe-05/",
      "/herbier/extra-recipe-05",
      "/herbier/therapeutic/extra-recipe-05/",
      "/herbier/therapeutic/extra-recipe-05",
      "/herbier/extra-recipe-05/",
      "/herbier/extra-recipe-05"
    ],
    "title": "Teinture de Propolis Maison",
    "subtitle": "Protocole Spécifique — Un concentré protecteur issu d'une extraction hydro-alcoolique assistée par vortex....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "30g de Teinture de Propolis Maison séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Teinture de Propolis Maison séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Teinture de Propolis Maison une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Teinture de Propolis Maison",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Teinture de Propolis Maison — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/parcours-botaniques/teinture-propolis-maison/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-06",
    "slug": "sirop-de-sureau-immunite",
    "canonicalUrl": "/recettes/phytotherapie/sirop-de-sureau-immunite/",
    "oldUrls": [
      "/herbier/sirop-de-sureau-immunite/",
      "/herbier/sirop-de-sureau-immunite",
      "/herbier/extra-recipe-06/",
      "/herbier/extra-recipe-06",
      "/herbier/therapeutic/extra-recipe-06/",
      "/herbier/therapeutic/extra-recipe-06",
      "/herbier/extra-recipe-06/",
      "/herbier/extra-recipe-06"
    ],
    "title": "Sirop de Sureau Immunité",
    "subtitle": "Protocole Spécifique — Un remède d'hiver traditionnel optimisé par une décoction basse température....",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thérapeutique"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "30g de Sirop de Sureau Immunité séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Sirop de Sureau Immunité séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Sirop de Sureau Immunité une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thérapeutique",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sirop de Sureau Immunité",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Sirop de Sureau Immunité — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 20,
    "gscClicks90d": 1,
    "batchNumber": 8,
    "batchPriority": "basse",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/culinaires/sirop-sureau-immunite/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-07",
    "slug": "decoction-detox-soutien-hepatique",
    "canonicalUrl": "/recettes/phytotherapie/decoction-detox-soutien-hepatique/",
    "oldUrls": [
      "/herbier/decoction-detox-soutien-hepatique/",
      "/herbier/decoction-detox-soutien-hepatique",
      "/herbier/extra-recipe-07/",
      "/herbier/extra-recipe-07",
      "/herbier/therapeutic/extra-recipe-07/",
      "/herbier/therapeutic/extra-recipe-07",
      "/herbier/extra-recipe-07/",
      "/herbier/extra-recipe-07"
    ],
    "title": "Décoction Détox & Soutien Hépatique",
    "subtitle": "Protocole Spécifique — Une préparation traditionnelle de plantes amères pour accompagner le travail hépato-biliaire et la légèreté digestive (T...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8",
      "T2"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "30g de Décoction Détox & Soutien Hépatique séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Décoction Détox & Soutien Hépatique séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Décoction Détox & Soutien Hépatique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Décoction Détox & Soutien Hépatique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Décoction Détox & Soutien Hépatique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 41,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/parcours-botaniques/decoction-detox-soutien-hepatique/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-08",
    "slug": "elixir-regulateur-metabolique",
    "canonicalUrl": "/recettes/phytotherapie/elixir-regulateur-metabolique/",
    "oldUrls": [
      "/herbier/elixir-regulateur-metabolique/",
      "/herbier/elixir-regulateur-metabolique",
      "/herbier/extra-recipe-08/",
      "/herbier/extra-recipe-08",
      "/herbier/therapeutic/extra-recipe-08/",
      "/herbier/therapeutic/extra-recipe-08",
      "/herbier/extra-recipe-08/",
      "/herbier/extra-recipe-08"
    ],
    "title": "Élixir Régulateur Métabolique",
    "subtitle": "Protocole Spécifique — Synergie végétale aux graines de fenugrec et écorce d'épine-vinette pour accompagner l'équilibre métabolique et le rythm...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "30g de Élixir Régulateur Métabolique séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Élixir Régulateur Métabolique séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Élixir Régulateur Métabolique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Élixir Régulateur Métabolique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Élixir Régulateur Métabolique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 42,
    "gscClicks90d": 4,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/parcours-botaniques/elixir-regulateur-metabolique/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-09",
    "slug": "infusion-drainage-elimination",
    "canonicalUrl": "/recettes/phytotherapie/infusion-drainage-elimination/",
    "oldUrls": [
      "/herbier/infusion-drainage-elimination/",
      "/herbier/infusion-drainage-elimination",
      "/herbier/extra-recipe-09/",
      "/herbier/extra-recipe-09",
      "/herbier/therapeutic/extra-recipe-09/",
      "/herbier/therapeutic/extra-recipe-09",
      "/herbier/extra-recipe-09/",
      "/herbier/extra-recipe-09"
    ],
    "title": "Infusion Drainage & Élimination",
    "subtitle": "Protocole Spécifique — Formule drainante aux sommités de reine des prés et racines de pissenlit pour accompagner les fonctions d'élimination de...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8",
      "T2"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "30g de Infusion Drainage & Élimination séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Infusion Drainage & Élimination séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Infusion Drainage & Élimination une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Infusion Drainage & Élimination",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Infusion Drainage & Élimination — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 43,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/culinaires/infusion-drainage-elimination/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-10",
    "slug": "remede-psoriasis-emonctoires-regulation-epidermique",
    "canonicalUrl": "/recettes/phytotherapie/remede-psoriasis-emonctoires-regulation-epidermique/",
    "oldUrls": [
      "/herbier/remede-psoriasis-emonctoires-regulation-epidermique/",
      "/herbier/remede-psoriasis-emonctoires-regulation-epidermique",
      "/herbier/extra-recipe-10/",
      "/herbier/extra-recipe-10",
      "/herbier/therapeutic/extra-recipe-10/",
      "/herbier/therapeutic/extra-recipe-10",
      "/herbier/extra-recipe-10/",
      "/herbier/extra-recipe-10"
    ],
    "title": "Remède Psoriasis — Émonctoires & Régulation Épidermique",
    "subtitle": "Protocole Spécifique — Plaques squameuses, hyperprolifération kératinocytaire et surcharge hépato-cutanée...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7",
      "T2"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "30g de Remède Psoriasis — Émonctoires & Régulation Épidermique séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Remède Psoriasis — Émonctoires & Régulation Épidermique séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Remède Psoriasis — Émonctoires & Régulation Épidermique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Remède Psoriasis — Émonctoires & Régulation Épidermique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Remède Psoriasis — Émonctoires & Régulation Épidermique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 44,
    "gscClicks90d": 3,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/parcours-botaniques/remede-psoriasis-emonctoires-regulation/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-11",
    "slug": "remede-eczema-desamorcage-histaminique-barriere",
    "canonicalUrl": "/recettes/phytotherapie/remede-eczema-desamorcage-histaminique-barriere/",
    "oldUrls": [
      "/herbier/remede-eczema-desamorcage-histaminique-barriere/",
      "/herbier/remede-eczema-desamorcage-histaminique-barriere",
      "/herbier/extra-recipe-11/",
      "/herbier/extra-recipe-11",
      "/herbier/therapeutic/extra-recipe-11/",
      "/herbier/therapeutic/extra-recipe-11",
      "/herbier/extra-recipe-11/",
      "/herbier/extra-recipe-11"
    ],
    "title": "Remède Eczéma — Désamorçage Histaminique & Barrière",
    "subtitle": "Protocole Spécifique — Dermatite atopique, réactivité cutanée, prurit intense et déficience de la barrière épidermique...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7",
      "T1"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "30g de Remède Eczéma — Désamorçage Histaminique & Barrière séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Remède Eczéma — Désamorçage Histaminique & Barrière séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Remède Eczéma — Désamorçage Histaminique & Barrière une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Remède Eczéma — Désamorçage Histaminique & Barrière",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Remède Eczéma — Désamorçage Histaminique & Barrière — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 45,
    "gscClicks90d": 4,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/parcours-botaniques/remede-eczema-desamorcage-histaminique/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-extra-recipe-12",
    "slug": "remede-alopecie-anti-dht-matrice-folliculaire",
    "canonicalUrl": "/recettes/phytotherapie/remede-alopecie-anti-dht-matrice-folliculaire/",
    "oldUrls": [
      "/herbier/remede-alopecie-anti-dht-matrice-folliculaire/",
      "/herbier/remede-alopecie-anti-dht-matrice-folliculaire",
      "/herbier/extra-recipe-12/",
      "/herbier/extra-recipe-12",
      "/herbier/therapeutic/extra-recipe-12/",
      "/herbier/therapeutic/extra-recipe-12",
      "/herbier/extra-recipe-12/",
      "/herbier/extra-recipe-12"
    ],
    "title": "Remède Alopécie — Anti-DHT & Matrice Folliculaire",
    "subtitle": "Protocole Spécifique — Alopécie androgénétique, excès de DHT, fibrose du bulbe et perte de densité capillaire...",
    "category": "phytotherapie",
    "categorySlug": "phytotherapie",
    "categoryLabel": "Phytothérapie",
    "subcategory": "Infusion & Dual-Extract Thérapeutique",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "80°C",
    "tempSachetB": "50°C",
    "shelfLife": "30 jours au réfrigérateur dans un flacon ambré hermétique",
    "yieldMl": 300,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "30g de Remède Alopécie — Anti-DHT & Matrice Folliculaire séché de qualité herboristerie certifiée",
      "10g de sommités florales et feuilles de soutien synergie"
    ],
    "sachetA": {
      "composition": [
        "30g de Remède Alopécie — Anti-DHT & Matrice Folliculaire séché de qualité herboristerie certifiée"
      ],
      "solvent": "Eau purifiée osmosée (300ml)",
      "temp": "80°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "10g de sommités florales et feuilles de soutien synergie"
      ],
      "solvent": "Alcool de grain bio 96° ou glycérine végétale (150ml)",
      "temp": "50°C",
      "duration": "2h00"
    },
    "instructions": [],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Remède Alopécie — Anti-DHT & Matrice Folliculaire une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Remède Alopécie — Anti-DHT & Matrice Folliculaire",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/articles-savoirs-herboristerie-botanique-1200x630.jpg",
    "imageAlt": "Remède Alopécie — Anti-DHT & Matrice Folliculaire — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 46,
    "gscClicks90d": 5,
    "batchNumber": 3,
    "batchPriority": "moyenne",
    "isDuplicateWith81": true,
    "duplicateCanonicalUrl": "/recettes/cosmetiques/soin-alopecie-anti-dht-matrice-folliculaire/",
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-romarin_culinaire-huile",
    "slug": "romarin-a-cineole-huile",
    "canonicalUrl": "/recettes/gastronomie/romarin-a-cineole-huile/",
    "oldUrls": [
      "/herbier/romarin-a-cineole-huile/",
      "/herbier/romarin-a-cineole-huile",
      "/herbier/culinary-romarin_culinaire-huile/",
      "/herbier/culinary-romarin_culinaire-huile",
      "/herbier/culinaire/romarin_culinaire-huile/",
      "/herbier/culinaire/romarin_culinaire-huile",
      "/herbier/gastronomie/romarin_culinaire-huile/",
      "/herbier/gastronomie/romarin_culinaire-huile"
    ],
    "title": "Romarin à Cinéole (Huile)",
    "subtitle": "Culinaire — Boisé, camphré, notes d'eucalyptus - Pommes de terre rôties, agneau, poissons gras...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Sommités aromatiques de Romarin à Cinéole (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Romarin à Cinéole (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Romarin à Cinéole (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Romarin à Cinéole (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Romarin à Cinéole (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 35,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-romarin_culinaire-beurre-ghee",
    "slug": "romarin-a-cineole-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/romarin-a-cineole-beurre-ghee/",
    "oldUrls": [
      "/herbier/romarin-a-cineole-beurre-ghee/",
      "/herbier/romarin-a-cineole-beurre-ghee",
      "/herbier/culinary-romarin_culinaire-beurre-ghee/",
      "/herbier/culinary-romarin_culinaire-beurre-ghee",
      "/herbier/culinaire/romarin_culinaire-beurre-ghee/",
      "/herbier/culinaire/romarin_culinaire-beurre-ghee",
      "/herbier/gastronomie/romarin_culinaire-beurre-ghee/",
      "/herbier/gastronomie/romarin_culinaire-beurre-ghee"
    ],
    "title": "Romarin à Cinéole (Beurre/Ghee)",
    "subtitle": "Culinaire — Boisé, camphré, notes d'eucalyptus - Finition steaks, pâtes fraîches...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Sommités aromatiques de Romarin à Cinéole (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Romarin à Cinéole (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Romarin à Cinéole (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Romarin à Cinéole (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Romarin à Cinéole (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 36,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-romarin_culinaire-miel",
    "slug": "romarin-a-cineole-miel",
    "canonicalUrl": "/recettes/gastronomie/romarin-a-cineole-miel/",
    "oldUrls": [
      "/herbier/romarin-a-cineole-miel/",
      "/herbier/romarin-a-cineole-miel",
      "/herbier/culinary-romarin_culinaire-miel/",
      "/herbier/culinary-romarin_culinaire-miel",
      "/herbier/culinaire/romarin_culinaire-miel/",
      "/herbier/culinaire/romarin_culinaire-miel",
      "/herbier/gastronomie/romarin_culinaire-miel/",
      "/herbier/gastronomie/romarin_culinaire-miel"
    ],
    "title": "Romarin à Cinéole (Miel)",
    "subtitle": "Culinaire — Boisé, camphré, notes d'eucalyptus - Marinades sucrées-salées, infusions digestives...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Sommités aromatiques de Romarin à Cinéole (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Romarin à Cinéole (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Romarin à Cinéole (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Romarin à Cinéole (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Romarin à Cinéole (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 37,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-thym_culinaire-huile",
    "slug": "thym-commun-huile",
    "canonicalUrl": "/recettes/gastronomie/thym-commun-huile/",
    "oldUrls": [
      "/herbier/thym-commun-huile/",
      "/herbier/thym-commun-huile",
      "/herbier/culinary-thym_culinaire-huile/",
      "/herbier/culinary-thym_culinaire-huile",
      "/herbier/culinaire/thym_culinaire-huile/",
      "/herbier/culinaire/thym_culinaire-huile",
      "/herbier/gastronomie/thym_culinaire-huile/",
      "/herbier/gastronomie/thym_culinaire-huile"
    ],
    "title": "Thym commun (Huile)",
    "subtitle": "Culinaire — Herbacé, poivré, légèrement camphré - Pizzas, grillades, tomates confites...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sommités aromatiques de Thym commun (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Thym commun (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Thym commun (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Thym commun (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Thym commun (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-thym_culinaire-beurre-ghee",
    "slug": "thym-commun-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/thym-commun-beurre-ghee/",
    "oldUrls": [
      "/herbier/thym-commun-beurre-ghee/",
      "/herbier/thym-commun-beurre-ghee",
      "/herbier/culinary-thym_culinaire-beurre-ghee/",
      "/herbier/culinary-thym_culinaire-beurre-ghee",
      "/herbier/culinaire/thym_culinaire-beurre-ghee/",
      "/herbier/culinaire/thym_culinaire-beurre-ghee",
      "/herbier/gastronomie/thym_culinaire-beurre-ghee/",
      "/herbier/gastronomie/thym_culinaire-beurre-ghee"
    ],
    "title": "Thym commun (Beurre/Ghee)",
    "subtitle": "Culinaire — Herbacé, poivré, légèrement camphré - Escargots, moules marinières...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités aromatiques de Thym commun (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Thym commun (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Thym commun (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Thym commun (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Thym commun (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-thym_culinaire-vinaigre",
    "slug": "thym-commun-vinaigre",
    "canonicalUrl": "/recettes/gastronomie/thym-commun-vinaigre/",
    "oldUrls": [
      "/herbier/thym-commun-vinaigre/",
      "/herbier/thym-commun-vinaigre",
      "/herbier/culinary-thym_culinaire-vinaigre/",
      "/herbier/culinary-thym_culinaire-vinaigre",
      "/herbier/culinaire/thym_culinaire-vinaigre/",
      "/herbier/culinaire/thym_culinaire-vinaigre",
      "/herbier/gastronomie/thym_culinaire-vinaigre/",
      "/herbier/gastronomie/thym_culinaire-vinaigre"
    ],
    "title": "Thym commun (Vinaigre)",
    "subtitle": "Culinaire — Herbacé, poivré, légèrement camphré - Vinaigrettes, marinades de viande rouge...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Sommités aromatiques de Thym commun (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Thym commun (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Thym commun (Vinaigre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Thym commun (Vinaigre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Thym commun (Vinaigre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 30,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-basilic_culinaire-huile",
    "slug": "basilic-grand-vert-huile",
    "canonicalUrl": "/recettes/gastronomie/basilic-grand-vert-huile/",
    "oldUrls": [
      "/herbier/basilic-grand-vert-huile/",
      "/herbier/basilic-grand-vert-huile",
      "/herbier/culinary-basilic_culinaire-huile/",
      "/herbier/culinary-basilic_culinaire-huile",
      "/herbier/culinaire/basilic_culinaire-huile/",
      "/herbier/culinaire/basilic_culinaire-huile",
      "/herbier/gastronomie/basilic_culinaire-huile/",
      "/herbier/gastronomie/basilic_culinaire-huile"
    ],
    "title": "Basilic grand vert (Huile)",
    "subtitle": "Culinaire — Anisé, poivré, frais, très volatil - Pesto, carpaccio, tomates...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Sommités aromatiques de Basilic grand vert (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Basilic grand vert (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Basilic grand vert (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Basilic grand vert (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Basilic grand vert (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 31,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-basilic_culinaire-vinaigre",
    "slug": "basilic-grand-vert-vinaigre",
    "canonicalUrl": "/recettes/gastronomie/basilic-grand-vert-vinaigre/",
    "oldUrls": [
      "/herbier/basilic-grand-vert-vinaigre/",
      "/herbier/basilic-grand-vert-vinaigre",
      "/herbier/culinary-basilic_culinaire-vinaigre/",
      "/herbier/culinary-basilic_culinaire-vinaigre",
      "/herbier/culinaire/basilic_culinaire-vinaigre/",
      "/herbier/culinaire/basilic_culinaire-vinaigre",
      "/herbier/gastronomie/basilic_culinaire-vinaigre/",
      "/herbier/gastronomie/basilic_culinaire-vinaigre"
    ],
    "title": "Basilic grand vert (Vinaigre)",
    "subtitle": "Culinaire — Anisé, poivré, frais, très volatil - Vinaigre aromatique pour salades d'été...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Sommités aromatiques de Basilic grand vert (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Basilic grand vert (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Basilic grand vert (Vinaigre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Basilic grand vert (Vinaigre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Basilic grand vert (Vinaigre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 32,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-origan_culinaire-huile",
    "slug": "origan-compact-huile",
    "canonicalUrl": "/recettes/gastronomie/origan-compact-huile/",
    "oldUrls": [
      "/herbier/origan-compact-huile/",
      "/herbier/origan-compact-huile",
      "/herbier/culinary-origan_culinaire-huile/",
      "/herbier/culinary-origan_culinaire-huile",
      "/herbier/culinaire/origan_culinaire-huile/",
      "/herbier/culinaire/origan_culinaire-huile",
      "/herbier/gastronomie/origan_culinaire-huile/",
      "/herbier/gastronomie/origan_culinaire-huile"
    ],
    "title": "Origan compact (Huile)",
    "subtitle": "Culinaire — Intense, camphré, chaud - Pizzas, pâtes, salades grecques...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Sommités aromatiques de Origan compact (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Origan compact (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Origan compact (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Origan compact (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Origan compact (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 33,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-origan_culinaire-beurre-ghee",
    "slug": "origan-compact-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/origan-compact-beurre-ghee/",
    "oldUrls": [
      "/herbier/origan-compact-beurre-ghee/",
      "/herbier/origan-compact-beurre-ghee",
      "/herbier/culinary-origan_culinaire-beurre-ghee/",
      "/herbier/culinary-origan_culinaire-beurre-ghee",
      "/herbier/culinaire/origan_culinaire-beurre-ghee/",
      "/herbier/culinaire/origan_culinaire-beurre-ghee",
      "/herbier/gastronomie/origan_culinaire-beurre-ghee/",
      "/herbier/gastronomie/origan_culinaire-beurre-ghee"
    ],
    "title": "Origan compact (Beurre/Ghee)",
    "subtitle": "Culinaire — Intense, camphré, chaud - Grillades, légumes rôtis...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Tomate"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Sommités aromatiques de Origan compact (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Origan compact (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Origan compact (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Tomate",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Origan compact (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Origan compact (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 34,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-laurier_culinaire-huile",
    "slug": "laurier-sauce-huile",
    "canonicalUrl": "/recettes/gastronomie/laurier-sauce-huile/",
    "oldUrls": [
      "/herbier/laurier-sauce-huile/",
      "/herbier/laurier-sauce-huile",
      "/herbier/culinary-laurier_culinaire-huile/",
      "/herbier/culinary-laurier_culinaire-huile",
      "/herbier/culinaire/laurier_culinaire-huile/",
      "/herbier/culinaire/laurier_culinaire-huile",
      "/herbier/gastronomie/laurier_culinaire-huile/",
      "/herbier/gastronomie/laurier_culinaire-huile"
    ],
    "title": "Laurier sauce (Huile)",
    "subtitle": "Culinaire — Boisé, floral, légèrement amer - Marinades, daubes, confits...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Sommités aromatiques de Laurier sauce (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Laurier sauce (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Laurier sauce (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Laurier sauce (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Laurier sauce (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 35,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-laurier_culinaire-beurre-ghee",
    "slug": "laurier-sauce-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/laurier-sauce-beurre-ghee/",
    "oldUrls": [
      "/herbier/laurier-sauce-beurre-ghee/",
      "/herbier/laurier-sauce-beurre-ghee",
      "/herbier/culinary-laurier_culinaire-beurre-ghee/",
      "/herbier/culinary-laurier_culinaire-beurre-ghee",
      "/herbier/culinaire/laurier_culinaire-beurre-ghee/",
      "/herbier/culinaire/laurier_culinaire-beurre-ghee",
      "/herbier/gastronomie/laurier_culinaire-beurre-ghee/",
      "/herbier/gastronomie/laurier_culinaire-beurre-ghee"
    ],
    "title": "Laurier sauce (Beurre/Ghee)",
    "subtitle": "Culinaire — Boisé, floral, légèrement amer - Sauces crème, poissons...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Sommités aromatiques de Laurier sauce (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Laurier sauce (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Laurier sauce (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Laurier sauce (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Laurier sauce (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 36,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-sauge_culinaire-huile",
    "slug": "sauge-officinale-huile",
    "canonicalUrl": "/recettes/gastronomie/sauge-officinale-huile/",
    "oldUrls": [
      "/herbier/sauge-officinale-huile/",
      "/herbier/sauge-officinale-huile",
      "/herbier/culinary-sauge_culinaire-huile/",
      "/herbier/culinary-sauge_culinaire-huile",
      "/herbier/culinaire/sauge_culinaire-huile/",
      "/herbier/culinaire/sauge_culinaire-huile",
      "/herbier/gastronomie/sauge_culinaire-huile/",
      "/herbier/gastronomie/sauge_culinaire-huile"
    ],
    "title": "Sauge officinale (Huile)",
    "subtitle": "Culinaire — Camphré, eucalyptus, légèrement amer - Fois gras, canard...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sommités aromatiques de Sauge officinale (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Sauge officinale (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Sauge officinale (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sauge officinale (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Sauge officinale (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 37,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-sauge_culinaire-beurre-ghee",
    "slug": "sauge-officinale-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/sauge-officinale-beurre-ghee/",
    "oldUrls": [
      "/herbier/sauge-officinale-beurre-ghee/",
      "/herbier/sauge-officinale-beurre-ghee",
      "/herbier/culinary-sauge_culinaire-beurre-ghee/",
      "/herbier/culinary-sauge_culinaire-beurre-ghee",
      "/herbier/culinaire/sauge_culinaire-beurre-ghee/",
      "/herbier/culinaire/sauge_culinaire-beurre-ghee",
      "/herbier/gastronomie/sauge_culinaire-beurre-ghee/",
      "/herbier/gastronomie/sauge_culinaire-beurre-ghee"
    ],
    "title": "Sauge officinale (Beurre/Ghee)",
    "subtitle": "Culinaire — Camphré, eucalyptus, légèrement amer - Ravioles, gnocchis, viandes blanches...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités aromatiques de Sauge officinale (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Sauge officinale (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Sauge officinale (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sauge officinale (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Sauge officinale (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-menthe_culinaire-huile",
    "slug": "menthe-poivree-huile",
    "canonicalUrl": "/recettes/gastronomie/menthe-poivree-huile/",
    "oldUrls": [
      "/herbier/menthe-poivree-huile/",
      "/herbier/menthe-poivree-huile",
      "/herbier/culinary-menthe_culinaire-huile/",
      "/herbier/culinary-menthe_culinaire-huile",
      "/herbier/culinaire/menthe_culinaire-huile/",
      "/herbier/culinaire/menthe_culinaire-huile",
      "/herbier/gastronomie/menthe_culinaire-huile/",
      "/herbier/gastronomie/menthe_culinaire-huile"
    ],
    "title": "Menthe poivrée (Huile)",
    "subtitle": "Culinaire — Frais, mentholé, très volatil - Salades, taboulé, desserts...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "Taboulé",
      "Thé vert"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Sommités aromatiques de Menthe poivrée (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Menthe poivrée (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Menthe poivrée (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Taboulé",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Menthe poivrée (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Menthe poivrée (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-menthe_culinaire-miel",
    "slug": "menthe-poivree-miel",
    "canonicalUrl": "/recettes/gastronomie/menthe-poivree-miel/",
    "oldUrls": [
      "/herbier/menthe-poivree-miel/",
      "/herbier/menthe-poivree-miel",
      "/herbier/culinary-menthe_culinaire-miel/",
      "/herbier/culinary-menthe_culinaire-miel",
      "/herbier/culinaire/menthe_culinaire-miel/",
      "/herbier/culinaire/menthe_culinaire-miel",
      "/herbier/gastronomie/menthe_culinaire-miel/",
      "/herbier/gastronomie/menthe_culinaire-miel"
    ],
    "title": "Menthe poivrée (Miel)",
    "subtitle": "Culinaire — Frais, mentholé, très volatil - Thé, yaourts, fruits rouges...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Nervures foliaires ramifiées rappelant le réseau capillaire et vasculaire pulmonaire.",
      "doctrineInterpretation": "La structure foliaire évoque la respiration cellulaire, la microcirculation et l’oxygénation tissulaire active.",
      "organTarget": "Microcirculation capillaire, poumons et tonus vagal"
    },
    "terrains": [
      "Taboulé",
      "Thé vert"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Sommités aromatiques de Menthe poivrée (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Menthe poivrée (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Menthe poivrée (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Taboulé",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Menthe poivrée (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Menthe poivrée (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 30,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-estragon_culinaire-huile",
    "slug": "estragon-huile",
    "canonicalUrl": "/recettes/gastronomie/estragon-huile/",
    "oldUrls": [
      "/herbier/estragon-huile/",
      "/herbier/estragon-huile",
      "/herbier/culinary-estragon_culinaire-huile/",
      "/herbier/culinary-estragon_culinaire-huile",
      "/herbier/culinaire/estragon_culinaire-huile/",
      "/herbier/culinaire/estragon_culinaire-huile",
      "/herbier/gastronomie/estragon_culinaire-huile/",
      "/herbier/gastronomie/estragon_culinaire-huile"
    ],
    "title": "Estragon (Huile)",
    "subtitle": "Culinaire — Anisé, réglissé, délicat - Poulet, poissons délicats, œufs...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Sommités aromatiques de Estragon (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Estragon (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Estragon (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Estragon (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Estragon (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 31,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-estragon_culinaire-vinaigre",
    "slug": "estragon-vinaigre",
    "canonicalUrl": "/recettes/gastronomie/estragon-vinaigre/",
    "oldUrls": [
      "/herbier/estragon-vinaigre/",
      "/herbier/estragon-vinaigre",
      "/herbier/culinary-estragon_culinaire-vinaigre/",
      "/herbier/culinary-estragon_culinaire-vinaigre",
      "/herbier/culinaire/estragon_culinaire-vinaigre/",
      "/herbier/culinaire/estragon_culinaire-vinaigre",
      "/herbier/gastronomie/estragon_culinaire-vinaigre/",
      "/herbier/gastronomie/estragon_culinaire-vinaigre"
    ],
    "title": "Estragon (Vinaigre)",
    "subtitle": "Culinaire — Anisé, réglissé, délicat - Sauce béarnaise, vinaigrettes fines...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Sommités aromatiques de Estragon (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Estragon (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Estragon (Vinaigre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Estragon (Vinaigre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Estragon (Vinaigre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 32,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-gingembre_culinaire-huile",
    "slug": "gingembre-huile",
    "canonicalUrl": "/recettes/gastronomie/gingembre-huile/",
    "oldUrls": [
      "/herbier/gingembre-huile/",
      "/herbier/gingembre-huile",
      "/herbier/culinary-gingembre_culinaire-huile/",
      "/herbier/culinary-gingembre_culinaire-huile",
      "/herbier/culinaire/gingembre_culinaire-huile/",
      "/herbier/culinaire/gingembre_culinaire-huile",
      "/herbier/gastronomie/gingembre_culinaire-huile/",
      "/herbier/gastronomie/gingembre_culinaire-huile"
    ],
    "title": "Gingembre (Huile)",
    "subtitle": "Culinaire — Piquant, citronné, chaud - Wok, nouilles, poissons...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Sommités aromatiques de Gingembre (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Gingembre (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Gingembre (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gingembre (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Gingembre (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 33,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-gingembre_culinaire-miel",
    "slug": "gingembre-miel",
    "canonicalUrl": "/recettes/gastronomie/gingembre-miel/",
    "oldUrls": [
      "/herbier/gingembre-miel/",
      "/herbier/gingembre-miel",
      "/herbier/culinary-gingembre_culinaire-miel/",
      "/herbier/culinary-gingembre_culinaire-miel",
      "/herbier/culinaire/gingembre_culinaire-miel/",
      "/herbier/culinaire/gingembre_culinaire-miel",
      "/herbier/gastronomie/gingembre_culinaire-miel/",
      "/herbier/gastronomie/gingembre_culinaire-miel"
    ],
    "title": "Gingembre (Miel)",
    "subtitle": "Culinaire — Piquant, citronné, chaud - Shot immunité, marinades...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Sommités aromatiques de Gingembre (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Gingembre (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Gingembre (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gingembre (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Gingembre (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 34,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-curcuma_culinaire-huile",
    "slug": "curcuma-huile",
    "canonicalUrl": "/recettes/gastronomie/curcuma-huile/",
    "oldUrls": [
      "/herbier/curcuma-huile/",
      "/herbier/curcuma-huile",
      "/herbier/culinary-curcuma_culinaire-huile/",
      "/herbier/culinary-curcuma_culinaire-huile",
      "/herbier/culinaire/curcuma_culinaire-huile/",
      "/herbier/culinaire/curcuma_culinaire-huile",
      "/herbier/gastronomie/curcuma_culinaire-huile/",
      "/herbier/gastronomie/curcuma_culinaire-huile"
    ],
    "title": "Curcuma (Huile)",
    "subtitle": "Culinaire — Terreux, poivré, légèrement amer - Curry maison, riz doré...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Sommités aromatiques de Curcuma (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Curcuma (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Curcuma (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Curcuma (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Curcuma (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 35,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-curcuma_culinaire-beurre-ghee",
    "slug": "curcuma-beurre-ghee",
    "canonicalUrl": "/recettes/gastronomie/curcuma-beurre-ghee/",
    "oldUrls": [
      "/herbier/curcuma-beurre-ghee/",
      "/herbier/curcuma-beurre-ghee",
      "/herbier/culinary-curcuma_culinaire-beurre-ghee/",
      "/herbier/culinary-curcuma_culinaire-beurre-ghee",
      "/herbier/culinaire/curcuma_culinaire-beurre-ghee/",
      "/herbier/culinaire/curcuma_culinaire-beurre-ghee",
      "/herbier/gastronomie/curcuma_culinaire-beurre-ghee/",
      "/herbier/gastronomie/curcuma_culinaire-beurre-ghee"
    ],
    "title": "Curcuma (Beurre/Ghee)",
    "subtitle": "Culinaire — Terreux, poivré, légèrement amer - Beurre doré indien, naan, dahl...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sommités aromatiques de Curcuma (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Curcuma (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Curcuma (Beurre/Ghee) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Curcuma (Beurre/Ghee)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Curcuma (Beurre/Ghee) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 36,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-cannelle_culinaire-huile",
    "slug": "cannelle-de-ceylan-huile",
    "canonicalUrl": "/recettes/gastronomie/cannelle-de-ceylan-huile/",
    "oldUrls": [
      "/herbier/cannelle-de-ceylan-huile/",
      "/herbier/cannelle-de-ceylan-huile",
      "/herbier/culinary-cannelle_culinaire-huile/",
      "/herbier/culinary-cannelle_culinaire-huile",
      "/herbier/culinaire/cannelle_culinaire-huile/",
      "/herbier/culinaire/cannelle_culinaire-huile",
      "/herbier/gastronomie/cannelle_culinaire-huile/",
      "/herbier/gastronomie/cannelle_culinaire-huile"
    ],
    "title": "Cannelle de Ceylan (Huile)",
    "subtitle": "Culinaire — Doux, épicé, boisé, sucré - Porridge, compotes, courges rôties...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités aromatiques de Cannelle de Ceylan (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Cannelle de Ceylan (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Cannelle de Ceylan (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cannelle de Ceylan (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Cannelle de Ceylan (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 37,
    "gscClicks90d": 1,
    "batchNumber": 6,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-cannelle_culinaire-miel",
    "slug": "cannelle-de-ceylan-miel",
    "canonicalUrl": "/recettes/gastronomie/cannelle-de-ceylan-miel/",
    "oldUrls": [
      "/herbier/cannelle-de-ceylan-miel/",
      "/herbier/cannelle-de-ceylan-miel",
      "/herbier/culinary-cannelle_culinaire-miel/",
      "/herbier/culinary-cannelle_culinaire-miel",
      "/herbier/culinaire/cannelle_culinaire-miel/",
      "/herbier/culinaire/cannelle_culinaire-miel",
      "/herbier/gastronomie/cannelle_culinaire-miel/",
      "/herbier/gastronomie/cannelle_culinaire-miel"
    ],
    "title": "Cannelle de Ceylan (Miel)",
    "subtitle": "Culinaire — Doux, épicé, boisé, sucré - Tartines, lait chaud, pâtisseries...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Sommités aromatiques de Cannelle de Ceylan (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Cannelle de Ceylan (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Cannelle de Ceylan (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cannelle de Ceylan (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Cannelle de Ceylan (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 25,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-cardamome_culinaire-huile",
    "slug": "cardamome-verte-huile",
    "canonicalUrl": "/recettes/gastronomie/cardamome-verte-huile/",
    "oldUrls": [
      "/herbier/cardamome-verte-huile/",
      "/herbier/cardamome-verte-huile",
      "/herbier/culinary-cardamome_culinaire-huile/",
      "/herbier/culinary-cardamome_culinaire-huile",
      "/herbier/culinaire/cardamome_culinaire-huile/",
      "/herbier/culinaire/cardamome_culinaire-huile",
      "/herbier/gastronomie/cardamome_culinaire-huile/",
      "/herbier/gastronomie/cardamome_culinaire-huile"
    ],
    "title": "Cardamome verte (Huile)",
    "subtitle": "Culinaire — Floral, citronné, eucalyptus, très puissant - Risottos, fruits de mer...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Sommités aromatiques de Cardamome verte (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Cardamome verte (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Cardamome verte (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cardamome verte (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Cardamome verte (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 26,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-cardamome_culinaire-miel",
    "slug": "cardamome-verte-miel",
    "canonicalUrl": "/recettes/gastronomie/cardamome-verte-miel/",
    "oldUrls": [
      "/herbier/cardamome-verte-miel/",
      "/herbier/cardamome-verte-miel",
      "/herbier/culinary-cardamome_culinaire-miel/",
      "/herbier/culinary-cardamome_culinaire-miel",
      "/herbier/culinaire/cardamome_culinaire-miel/",
      "/herbier/culinaire/cardamome_culinaire-miel",
      "/herbier/gastronomie/cardamome_culinaire-miel/",
      "/herbier/gastronomie/cardamome_culinaire-miel"
    ],
    "title": "Cardamome verte (Miel)",
    "subtitle": "Culinaire — Floral, citronné, eucalyptus, très puissant - Thé, pâtisseries orientales...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Sommités aromatiques de Cardamome verte (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Cardamome verte (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Cardamome verte (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Cardamome verte (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Cardamome verte (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 27,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-lavande_culinaire-miel",
    "slug": "lavande-angustifolia-miel",
    "canonicalUrl": "/recettes/gastronomie/lavande-angustifolia-miel/",
    "oldUrls": [
      "/herbier/lavande-angustifolia-miel/",
      "/herbier/lavande-angustifolia-miel",
      "/herbier/culinary-lavande_culinaire-miel/",
      "/herbier/culinary-lavande_culinaire-miel",
      "/herbier/culinaire/lavande_culinaire-miel/",
      "/herbier/culinaire/lavande_culinaire-miel",
      "/herbier/gastronomie/lavande_culinaire-miel/",
      "/herbier/gastronomie/lavande_culinaire-miel"
    ],
    "title": "Lavande (Angustifolia) (Miel)",
    "subtitle": "Culinaire — Floral, camphré, délicat - Yaourts, fromages frais...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Sommités aromatiques de Lavande (Angustifolia) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Lavande (Angustifolia) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Lavande (Angustifolia) (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lavande (Angustifolia) (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Lavande (Angustifolia) (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-lavande_culinaire-sucre",
    "slug": "lavande-angustifolia-sucre",
    "canonicalUrl": "/recettes/gastronomie/lavande-angustifolia-sucre/",
    "oldUrls": [
      "/herbier/lavande-angustifolia-sucre/",
      "/herbier/lavande-angustifolia-sucre",
      "/herbier/culinary-lavande_culinaire-sucre/",
      "/herbier/culinary-lavande_culinaire-sucre",
      "/herbier/culinaire/lavande_culinaire-sucre/",
      "/herbier/culinaire/lavande_culinaire-sucre",
      "/herbier/gastronomie/lavande_culinaire-sucre/",
      "/herbier/gastronomie/lavande_culinaire-sucre"
    ],
    "title": "Lavande (Angustifolia) (Sucre)",
    "subtitle": "Culinaire — Floral, camphré, délicat - Biscuits, crème brûlée...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Corolles radieuses, pétales délicats et fragrances volatiles apaisantes.",
      "doctrineInterpretation": "Les sommités fleuries reflètent l’apaisement nerveux, la clarté sensorielle et la régénération cutanée superficielle.",
      "organTarget": "Système nerveux central, sphère émotionnelle et épithélium"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Sommités aromatiques de Lavande (Angustifolia) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Lavande (Angustifolia) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Lavande (Angustifolia) (Sucre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lavande (Angustifolia) (Sucre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Lavande (Angustifolia) (Sucre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-citronnelle_culinaire-huile",
    "slug": "citronnelle-huile",
    "canonicalUrl": "/recettes/gastronomie/citronnelle-huile/",
    "oldUrls": [
      "/herbier/citronnelle-huile/",
      "/herbier/citronnelle-huile",
      "/herbier/culinary-citronnelle_culinaire-huile/",
      "/herbier/culinary-citronnelle_culinaire-huile",
      "/herbier/culinaire/citronnelle_culinaire-huile/",
      "/herbier/culinaire/citronnelle_culinaire-huile",
      "/herbier/gastronomie/citronnelle_culinaire-huile/",
      "/herbier/gastronomie/citronnelle_culinaire-huile"
    ],
    "title": "Citronnelle (Huile)",
    "subtitle": "Culinaire — Citronné, frais, herbacé - Cuisine thaï, wok, poissons...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thé vert"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Sommités aromatiques de Citronnelle (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Citronnelle (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Citronnelle (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thé vert",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Citronnelle (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Citronnelle (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 30,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-citronnelle_culinaire-miel",
    "slug": "citronnelle-miel",
    "canonicalUrl": "/recettes/gastronomie/citronnelle-miel/",
    "oldUrls": [
      "/herbier/citronnelle-miel/",
      "/herbier/citronnelle-miel",
      "/herbier/culinary-citronnelle_culinaire-miel/",
      "/herbier/culinary-citronnelle_culinaire-miel",
      "/herbier/culinaire/citronnelle_culinaire-miel/",
      "/herbier/culinaire/citronnelle_culinaire-miel",
      "/herbier/gastronomie/citronnelle_culinaire-miel/",
      "/herbier/gastronomie/citronnelle_culinaire-miel"
    ],
    "title": "Citronnelle (Miel)",
    "subtitle": "Culinaire — Citronné, frais, herbacé - Thé glacé, limonades...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thé vert"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Sommités aromatiques de Citronnelle (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Citronnelle (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Citronnelle (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thé vert",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Citronnelle (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Citronnelle (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 31,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-girofle_culinaire-huile",
    "slug": "clou-de-girofle-huile",
    "canonicalUrl": "/recettes/gastronomie/clou-de-girofle-huile/",
    "oldUrls": [
      "/herbier/clou-de-girofle-huile/",
      "/herbier/clou-de-girofle-huile",
      "/herbier/culinary-girofle_culinaire-huile/",
      "/herbier/culinary-girofle_culinaire-huile",
      "/herbier/culinaire/girofle_culinaire-huile/",
      "/herbier/culinaire/girofle_culinaire-huile",
      "/herbier/gastronomie/girofle_culinaire-huile/",
      "/herbier/gastronomie/girofle_culinaire-huile"
    ],
    "title": "Clou de girofle (Huile)",
    "subtitle": "Culinaire — Chaud, boisé, très puissant, anesthésiant - Pot-au-feu, daubes...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sommités aromatiques de Clou de girofle (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Clou de girofle (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Clou de girofle (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Clou de girofle (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Clou de girofle (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 32,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-girofle_culinaire-miel",
    "slug": "clou-de-girofle-miel",
    "canonicalUrl": "/recettes/gastronomie/clou-de-girofle-miel/",
    "oldUrls": [
      "/herbier/clou-de-girofle-miel/",
      "/herbier/clou-de-girofle-miel",
      "/herbier/culinary-girofle_culinaire-miel/",
      "/herbier/culinary-girofle_culinaire-miel",
      "/herbier/culinaire/girofle_culinaire-miel/",
      "/herbier/culinaire/girofle_culinaire-miel",
      "/herbier/gastronomie/girofle_culinaire-miel/",
      "/herbier/gastronomie/girofle_culinaire-miel"
    ],
    "title": "Clou de girofle (Miel)",
    "subtitle": "Culinaire — Chaud, boisé, très puissant, anesthésiant - Vin chaud, pain d'épices, marinades...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités aromatiques de Clou de girofle (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Clou de girofle (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Clou de girofle (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Clou de girofle (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Clou de girofle (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 33,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-lycium_barbarum-huile",
    "slug": "goji-huile",
    "canonicalUrl": "/recettes/gastronomie/goji-huile/",
    "oldUrls": [
      "/herbier/goji-huile/",
      "/herbier/goji-huile",
      "/herbier/culinary-lycium_barbarum-huile/",
      "/herbier/culinary-lycium_barbarum-huile",
      "/herbier/culinaire/lycium_barbarum-huile/",
      "/herbier/culinaire/lycium_barbarum-huile",
      "/herbier/gastronomie/lycium_barbarum-huile/",
      "/herbier/gastronomie/lycium_barbarum-huile"
    ],
    "title": "Goji (Huile)",
    "subtitle": "Culinaire — Sucré, légèrement acidulé, notes de datte - Bouillons de jeunesse, salades, porridges...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thé blanc"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Sommités aromatiques de Goji (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Goji (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Goji (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thé blanc",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Goji (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Goji (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 34,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-lycium_barbarum-miel",
    "slug": "goji-miel",
    "canonicalUrl": "/recettes/gastronomie/goji-miel/",
    "oldUrls": [
      "/herbier/goji-miel/",
      "/herbier/goji-miel",
      "/herbier/culinary-lycium_barbarum-miel/",
      "/herbier/culinary-lycium_barbarum-miel",
      "/herbier/culinaire/lycium_barbarum-miel/",
      "/herbier/culinaire/lycium_barbarum-miel",
      "/herbier/gastronomie/lycium_barbarum-miel/",
      "/herbier/gastronomie/lycium_barbarum-miel"
    ],
    "title": "Goji (Miel)",
    "subtitle": "Culinaire — Sucré, légèrement acidulé, notes de datte - Nappage desserts, thés régénérants...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Thé blanc"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Sommités aromatiques de Goji (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Goji (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Goji (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Thé blanc",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Goji (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Goji (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 25,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-arctium_lappa-huile",
    "slug": "bardane-huile",
    "canonicalUrl": "/recettes/gastronomie/bardane-huile/",
    "oldUrls": [
      "/herbier/bardane-huile/",
      "/herbier/bardane-huile",
      "/herbier/culinary-arctium_lappa-huile/",
      "/herbier/culinary-arctium_lappa-huile",
      "/herbier/culinaire/arctium_lappa-huile/",
      "/herbier/culinaire/arctium_lappa-huile",
      "/herbier/gastronomie/arctium_lappa-huile/",
      "/herbier/gastronomie/arctium_lappa-huile"
    ],
    "title": "Bardane (Huile)",
    "subtitle": "Culinaire — Terreux, noisette, doux - Sauté de racines, soupe miso...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Sommités aromatiques de Bardane (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Bardane (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Bardane (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Bardane (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Bardane (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 26,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-arctium_lappa-vinaigre",
    "slug": "bardane-vinaigre",
    "canonicalUrl": "/recettes/gastronomie/bardane-vinaigre/",
    "oldUrls": [
      "/herbier/bardane-vinaigre/",
      "/herbier/bardane-vinaigre",
      "/herbier/culinary-arctium_lappa-vinaigre/",
      "/herbier/culinary-arctium_lappa-vinaigre",
      "/herbier/culinaire/arctium_lappa-vinaigre/",
      "/herbier/culinaire/arctium_lappa-vinaigre",
      "/herbier/gastronomie/arctium_lappa-vinaigre/",
      "/herbier/gastronomie/arctium_lappa-vinaigre"
    ],
    "title": "Bardane (Vinaigre)",
    "subtitle": "Culinaire — Terreux, noisette, doux - Légumes lacto-fermentés, sauces asiatiques...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Réseau racinaire pivotant et rhizomes denses ancrés profondément dans la terre minérale.",
      "doctrineInterpretation": "La doctrine des signatures associe les racines denses à l’ancrage métabolique, aux émonctoires profonds (foie, reins) et à la purification du sang.",
      "organTarget": "Axe hépato-rénal et stabilité du terrain digestif"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Sommités aromatiques de Bardane (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Bardane (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Bardane (Vinaigre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Bardane (Vinaigre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Bardane (Vinaigre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 27,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-illicium_verum-huile",
    "slug": "badiane-anis-etoile-huile",
    "canonicalUrl": "/recettes/gastronomie/badiane-anis-etoile-huile/",
    "oldUrls": [
      "/herbier/badiane-anis-etoile-huile/",
      "/herbier/badiane-anis-etoile-huile",
      "/herbier/culinary-illicium_verum-huile/",
      "/herbier/culinary-illicium_verum-huile",
      "/herbier/culinaire/illicium_verum-huile/",
      "/herbier/culinaire/illicium_verum-huile",
      "/herbier/gastronomie/illicium_verum-huile/",
      "/herbier/gastronomie/illicium_verum-huile"
    ],
    "title": "Badiane (Anis étoilé) (Huile)",
    "subtitle": "Culinaire — Anisé puissant, réglissé, frais - Bouillons de poisson, canard, poires pochées...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Sommités aromatiques de Badiane (Anis étoilé) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Badiane (Anis étoilé) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Badiane (Anis étoilé) (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Badiane (Anis étoilé) (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Badiane (Anis étoilé) (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 28,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-illicium_verum-miel",
    "slug": "badiane-anis-etoile-miel",
    "canonicalUrl": "/recettes/gastronomie/badiane-anis-etoile-miel/",
    "oldUrls": [
      "/herbier/badiane-anis-etoile-miel/",
      "/herbier/badiane-anis-etoile-miel",
      "/herbier/culinary-illicium_verum-miel/",
      "/herbier/culinary-illicium_verum-miel",
      "/herbier/culinaire/illicium_verum-miel/",
      "/herbier/culinaire/illicium_verum-miel",
      "/herbier/gastronomie/illicium_verum-miel/",
      "/herbier/gastronomie/illicium_verum-miel"
    ],
    "title": "Badiane (Anis étoilé) (Miel)",
    "subtitle": "Culinaire — Anisé puissant, réglissé, frais - Infusions d'après-repas, pâtisseries...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Sommités aromatiques de Badiane (Anis étoilé) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Badiane (Anis étoilé) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Badiane (Anis étoilé) (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Badiane (Anis étoilé) (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Badiane (Anis étoilé) (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 29,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-ziziphus_jujuba-miel",
    "slug": "jujube-datte-rouge-miel",
    "canonicalUrl": "/recettes/gastronomie/jujube-datte-rouge-miel/",
    "oldUrls": [
      "/herbier/jujube-datte-rouge-miel/",
      "/herbier/jujube-datte-rouge-miel",
      "/herbier/culinary-ziziphus_jujuba-miel/",
      "/herbier/culinary-ziziphus_jujuba-miel",
      "/herbier/culinaire/ziziphus_jujuba-miel/",
      "/herbier/culinaire/ziziphus_jujuba-miel",
      "/herbier/gastronomie/ziziphus_jujuba-miel/",
      "/herbier/gastronomie/ziziphus_jujuba-miel"
    ],
    "title": "Jujube (Datte rouge) (Miel)",
    "subtitle": "Culinaire — Sucré, boisé, profond - Soutien du sommeil, encas vitalité...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Sommités aromatiques de Jujube (Datte rouge) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Jujube (Datte rouge) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Jujube (Datte rouge) (Miel) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Jujube (Datte rouge) (Miel)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Jujube (Datte rouge) (Miel) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 30,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-ziziphus_jujuba-vinaigre",
    "slug": "jujube-datte-rouge-vinaigre",
    "canonicalUrl": "/recettes/gastronomie/jujube-datte-rouge-vinaigre/",
    "oldUrls": [
      "/herbier/jujube-datte-rouge-vinaigre/",
      "/herbier/jujube-datte-rouge-vinaigre",
      "/herbier/culinary-ziziphus_jujuba-vinaigre/",
      "/herbier/culinary-ziziphus_jujuba-vinaigre",
      "/herbier/culinaire/ziziphus_jujuba-vinaigre/",
      "/herbier/culinaire/ziziphus_jujuba-vinaigre",
      "/herbier/gastronomie/ziziphus_jujuba-vinaigre/",
      "/herbier/gastronomie/ziziphus_jujuba-vinaigre"
    ],
    "title": "Jujube (Datte rouge) (Vinaigre)",
    "subtitle": "Culinaire — Sucré, boisé, profond - Réduction pour sauces de viande...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T7"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Sommités aromatiques de Jujube (Datte rouge) (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Jujube (Datte rouge) (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Jujube (Datte rouge) (Vinaigre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T7",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Jujube (Datte rouge) (Vinaigre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Jujube (Datte rouge) (Vinaigre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 31,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-vigna_angularis-huile",
    "slug": "haricot-adzuki-huile",
    "canonicalUrl": "/recettes/gastronomie/haricot-adzuki-huile/",
    "oldUrls": [
      "/herbier/haricot-adzuki-huile/",
      "/herbier/haricot-adzuki-huile",
      "/herbier/culinary-vigna_angularis-huile/",
      "/herbier/culinary-vigna_angularis-huile",
      "/herbier/culinaire/vigna_angularis-huile/",
      "/herbier/culinaire/vigna_angularis-huile",
      "/herbier/gastronomie/vigna_angularis-huile/",
      "/herbier/gastronomie/vigna_angularis-huile"
    ],
    "title": "Haricot Adzuki (Huile)",
    "subtitle": "Culinaire — Légumineux, noisette, légèrement sucré - Sauces onctueuses, plats macrobiotiques...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Sommités aromatiques de Haricot Adzuki (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Haricot Adzuki (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Haricot Adzuki (Huile) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Haricot Adzuki (Huile)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Haricot Adzuki (Huile) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 32,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-culinary-vigna_angularis-sucre",
    "slug": "haricot-adzuki-sucre",
    "canonicalUrl": "/recettes/gastronomie/haricot-adzuki-sucre/",
    "oldUrls": [
      "/herbier/haricot-adzuki-sucre/",
      "/herbier/haricot-adzuki-sucre",
      "/herbier/culinary-vigna_angularis-sucre/",
      "/herbier/culinary-vigna_angularis-sucre",
      "/herbier/culinaire/vigna_angularis-sucre/",
      "/herbier/culinaire/vigna_angularis-sucre",
      "/herbier/gastronomie/vigna_angularis-sucre/",
      "/herbier/gastronomie/vigna_angularis-sucre"
    ],
    "title": "Haricot Adzuki (Sucre)",
    "subtitle": "Culinaire — Légumineux, noisette, légèrement sucré - Pâte de haricots rouges (Anko), desserts...",
    "category": "gastronomie",
    "categorySlug": "gastronomie",
    "categoryLabel": "Gastronomie Botanique",
    "subcategory": "Huile & Condiment d’Exception",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "45°C",
    "tempSachetB": "Ambiante",
    "shelfLife": "3 mois au frais et à l’obscurité",
    "yieldMl": 350,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Sommités aromatiques de Haricot Adzuki (35g)",
      "Condiments d’accompagnement gastronome (10g)"
    ],
    "sachetA": {
      "composition": [
        "Sommités aromatiques de Haricot Adzuki (35g)"
      ],
      "solvent": "Huile d’olive vierge extra bio première pression à froid (350ml)",
      "temp": "45°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Condiments d’accompagnement gastronome (10g)"
      ],
      "solvent": "Grains de poivre sauvage et baies de genièvre concassées (5g)",
      "temp": "Ambiante",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation de la matière gastronomique — Sélectionner les feuilles et sommités fraîches ou séchées à basse température pour préserver le profil terpénique.",
      "Étape 2 : Infusion lipidique sous vortex BloomLab® — Immerger la matière dans Huile d’olive vierge extra bio première pression à froid (350ml) et programmer le cycle à 45°C pendant 1h15 afin de saturer la matrice d'arômes nobles sans chauffer l’huile.",
      "Étape 3 : Dynamisation des notes de cœur — Laisser tiédir en cuve étanche fermée pour éviter toute évaporation des arômes volatils délicats.",
      "Étape 4 : Filtration sous pression douce — Décanter lentement et filtrer pour obtenir une robe limpide sans micro-particules végétales en suspension.",
      "Étape 5 : Conditionnement d'exception — Mettre en bouteille en verre foncé bouchon liège ou verseur anti-goutte. Conserver au frais."
    ],
    "molecularSignature": [
      {
        "molecule": "Monoterpènes & Polyphénols aromatiques",
        "mechanism": "Composés volatils liposolubles rehaussant la digestibilité et apportant une empreinte gustative intense sans dénaturation.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      },
      {
        "molecule": "Acides phénoliques protecteurs",
        "mechanism": "Action antioxydante intrinsèque protégeant les lipides nobles de l’huile contre le rancissement.",
        "evidenceLevel": "Monographie officielle EMA / Commission E"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Haricot Adzuki (Sucre) une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Haricot Adzuki (Sucre)",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/gastronomie-botanique-huiles-aromatiques-1200x630.jpg",
    "imageAlt": "Haricot Adzuki (Sucre) — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Recipe",
    "gscImpressions90d": 33,
    "gscClicks90d": 1,
    "batchNumber": 7,
    "batchPriority": "basse",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-serum_liftant_encens_myrrhe",
    "slug": "serum-liftant-encens-myrrhe",
    "canonicalUrl": "/recettes/cosmetiques/serum-liftant-encens-myrrhe/",
    "oldUrls": [
      "/herbier/serum-liftant-encens-myrrhe/",
      "/herbier/serum-liftant-encens-myrrhe",
      "/herbier/cosmetic-serum_liftant_encens_myrrhe/",
      "/herbier/cosmetic-serum_liftant_encens_myrrhe",
      "/herbier/cosmetique/serum_liftant_encens_myrrhe/",
      "/herbier/cosmetique/serum_liftant_encens_myrrhe",
      "/herbier/cosmetiques/serum_liftant_encens_myrrhe/",
      "/herbier/cosmetiques/serum_liftant_encens_myrrhe"
    ],
    "title": "Sérum Liftant Encens & Myrrhe",
    "subtitle": "Cosmétique — Peaux matures, relâchées, en perte de fermeté et d'élasticité. Restaurer la fermeté, améliorer l'élasticité, lifter l'ov...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Centella asiatica & Aloe vera 200:1 (40g)",
      "Résine de Boswellia serrata & Résine de Myrrhe (65g)"
    ],
    "sachetA": {
      "composition": [
        "Centella asiatica & Aloe vera 200:1 (40g)"
      ],
      "solvent": "Eau distillée extra pure + Glycérine végétale (500 ml + 100 ml)",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Résine de Boswellia serrata & Résine de Myrrhe (65g)"
      ],
      "solvent": "Alcool vinique bio à 60° (367 ml alcool 96% + 233 ml eau distillée)",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Eau distillée extra pure + Glycérine végétale (500 ml + 100 ml). Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Sérum Liftant Encens & Myrrhe une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sérum Liftant Encens & Myrrhe",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Sérum Liftant Encens & Myrrhe — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 44,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-serum_reparateur_nuit",
    "slug": "serum-reparateur-nuit",
    "canonicalUrl": "/recettes/cosmetiques/serum-reparateur-nuit/",
    "oldUrls": [
      "/herbier/serum-reparateur-nuit/",
      "/herbier/serum-reparateur-nuit",
      "/herbier/cosmetic-serum_reparateur_nuit/",
      "/herbier/cosmetic-serum_reparateur_nuit",
      "/herbier/cosmetique/serum_reparateur_nuit/",
      "/herbier/cosmetique/serum_reparateur_nuit",
      "/herbier/cosmetiques/serum_reparateur_nuit/",
      "/herbier/cosmetiques/serum_reparateur_nuit"
    ],
    "title": "Sérum Réparateur Nuit",
    "subtitle": "Cosmétique — Peaux sensibles, cicatrisation, réparation du microbiote cutané...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Centella Asiatica (50g)",
      "Calendula (25g)"
    ],
    "sachetA": {
      "composition": [
        "Centella Asiatica (50g)"
      ],
      "solvent": "Huile de Jojoba",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Calendula (25g)"
      ],
      "solvent": "Huile de Rosehip (Églantier)",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Jojoba. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Sérum Réparateur Nuit une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sérum Réparateur Nuit",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Sérum Réparateur Nuit — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 45,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-elixir_croissance_capillaire",
    "slug": "elixir-de-croissance-cuir-chevelu",
    "canonicalUrl": "/recettes/cosmetiques/elixir-de-croissance-cuir-chevelu/",
    "oldUrls": [
      "/herbier/elixir-de-croissance-cuir-chevelu/",
      "/herbier/elixir-de-croissance-cuir-chevelu",
      "/herbier/cosmetic-elixir_croissance_capillaire/",
      "/herbier/cosmetic-elixir_croissance_capillaire",
      "/herbier/cosmetique/elixir_croissance_capillaire/",
      "/herbier/cosmetique/elixir_croissance_capillaire",
      "/herbier/cosmetiques/elixir_croissance_capillaire/",
      "/herbier/cosmetiques/elixir_croissance_capillaire"
    ],
    "title": "Élixir de Croissance & Cuir Chevelu",
    "subtitle": "Cosmétique — Chute de cheveux, cuir chevelu inflammé, pellicules, fortification de la tige...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Romarin à Cinéole (50g)",
      "Ortie (25g)"
    ],
    "sachetA": {
      "composition": [
        "Romarin à Cinéole (50g)"
      ],
      "solvent": "Huile de Jojoba",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Ortie (25g)"
      ],
      "solvent": "Huile de Ricin (Castor Oil)",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Jojoba. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Élixir de Croissance & Cuir Chevelu une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Élixir de Croissance & Cuir Chevelu",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Élixir de Croissance & Cuir Chevelu — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 46,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_corps_drainante",
    "slug": "huile-corps-drainante-fermete",
    "canonicalUrl": "/recettes/cosmetiques/huile-corps-drainante-fermete/",
    "oldUrls": [
      "/herbier/huile-corps-drainante-fermete/",
      "/herbier/huile-corps-drainante-fermete",
      "/herbier/cosmetic-huile_corps_drainante/",
      "/herbier/cosmetic-huile_corps_drainante",
      "/herbier/cosmetique/huile_corps_drainante/",
      "/herbier/cosmetique/huile_corps_drainante",
      "/herbier/cosmetiques/huile_corps_drainante/",
      "/herbier/cosmetiques/huile_corps_drainante"
    ],
    "title": "Huile Corps Drainante & Fermeté",
    "subtitle": "Cosmétique — Cellulite, rétention d'eau, fermeté cutanée, drainage lymphatique...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Lierre Grimpant (40g)",
      "Genièvre (20g)"
    ],
    "sachetA": {
      "composition": [
        "Lierre Grimpant (40g)"
      ],
      "solvent": "Huile de Sésame",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Genièvre (20g)"
      ],
      "solvent": "Huile de Macadamia",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Sésame. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Huile Corps Drainante & Fermeté une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile Corps Drainante & Fermeté",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile Corps Drainante & Fermeté — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 47,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-nettoyant_botanique_doux",
    "slug": "huile-nettoyante-botanique",
    "canonicalUrl": "/recettes/cosmetiques/huile-nettoyante-botanique/",
    "oldUrls": [
      "/herbier/huile-nettoyante-botanique/",
      "/herbier/huile-nettoyante-botanique",
      "/herbier/cosmetic-nettoyant_botanique_doux/",
      "/herbier/cosmetic-nettoyant_botanique_doux",
      "/herbier/cosmetique/nettoyant_botanique_doux/",
      "/herbier/cosmetique/nettoyant_botanique_doux",
      "/herbier/cosmetiques/nettoyant_botanique_doux/",
      "/herbier/cosmetiques/nettoyant_botanique_doux"
    ],
    "title": "Huile Nettoyante Botanique",
    "subtitle": "Cosmétique — Nettoyage profond, démaquillage, respect du film hydrolipidique...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Lavande Vraie (30g)",
      "Camomille Matricaire (20g)"
    ],
    "sachetA": {
      "composition": [
        "Lavande Vraie (30g)"
      ],
      "solvent": "Huile de Tournesol Oléique",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Camomille Matricaire (20g)"
      ],
      "solvent": "Huile d'Amande Douce",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Tournesol Oléique. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Huile Nettoyante Botanique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile Nettoyante Botanique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile Nettoyante Botanique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 48,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-masque_eclat_hibiscus",
    "slug": "masque-eclat-jeunesse",
    "canonicalUrl": "/recettes/cosmetiques/masque-eclat-jeunesse/",
    "oldUrls": [
      "/herbier/masque-eclat-jeunesse/",
      "/herbier/masque-eclat-jeunesse",
      "/herbier/cosmetic-masque_eclat_hibiscus/",
      "/herbier/cosmetic-masque_eclat_hibiscus",
      "/herbier/cosmetique/masque_eclat_hibiscus/",
      "/herbier/cosmetique/masque_eclat_hibiscus",
      "/herbier/cosmetiques/masque_eclat_hibiscus/",
      "/herbier/cosmetiques/masque_eclat_hibiscus"
    ],
    "title": "Masque Éclat & Jeunesse",
    "subtitle": "Cosmétique — Éclat du teint, antioxydant, lissage des ridules...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes / Teint terne"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Hibiscus (Fleurs) (30g)",
      "Rose de Damas (15g)"
    ],
    "sachetA": {
      "composition": [
        "Hibiscus (Fleurs) (30g)"
      ],
      "solvent": "Huile de Noyau d'Abricot",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Rose de Damas (15g)"
      ],
      "solvent": "Huile de Rose Musquée",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Noyau d'Abricot. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Masque Éclat & Jeunesse une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes / Teint terne",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Masque Éclat & Jeunesse",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Masque Éclat & Jeunesse — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 49,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_massage_recuperation",
    "slug": "huile-de-massage-recuperation",
    "canonicalUrl": "/recettes/cosmetiques/huile-de-massage-recuperation/",
    "oldUrls": [
      "/herbier/huile-de-massage-recuperation/",
      "/herbier/huile-de-massage-recuperation",
      "/herbier/cosmetic-huile_massage_recuperation/",
      "/herbier/cosmetic-huile_massage_recuperation",
      "/herbier/cosmetique/huile_massage_recuperation/",
      "/herbier/cosmetique/huile_massage_recuperation",
      "/herbier/cosmetiques/huile_massage_recuperation/",
      "/herbier/cosmetiques/huile_massage_recuperation"
    ],
    "title": "Huile de Massage Récupération",
    "subtitle": "Cosmétique — Douleurs musculaires, récupération après effort, drainage des toxines...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Arnica (Fleurs) (40g)",
      "Hélichryse Italienne (20g)"
    ],
    "sachetA": {
      "composition": [
        "Arnica (Fleurs) (40g)"
      ],
      "solvent": "Huile d'Arnica (Macérat)",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Hélichryse Italienne (20g)"
      ],
      "solvent": "Huile de Calophylle",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile d'Arnica (Macérat). Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Huile de Massage Récupération une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile de Massage Récupération",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile de Massage Récupération — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 35,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-serum_anti_imperfections",
    "slug": "serum-anti-imperfections",
    "canonicalUrl": "/recettes/cosmetiques/serum-anti-imperfections/",
    "oldUrls": [
      "/herbier/serum-anti-imperfections/",
      "/herbier/serum-anti-imperfections",
      "/herbier/cosmetic-serum_anti_imperfections/",
      "/herbier/cosmetic-serum_anti_imperfections",
      "/herbier/cosmetique/serum_anti_imperfections/",
      "/herbier/cosmetique/serum_anti_imperfections",
      "/herbier/cosmetiques/serum_anti_imperfections/",
      "/herbier/cosmetiques/serum_anti_imperfections"
    ],
    "title": "Sérum Anti-Imperfections",
    "subtitle": "Cosmétique — Excès de sébum, imperfections, pores dilatés...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Bardane (30g)",
      "Pensée Sauvage (20g)"
    ],
    "sachetA": {
      "composition": [
        "Bardane (30g)"
      ],
      "solvent": "Huile de Noisette",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Pensée Sauvage (20g)"
      ],
      "solvent": "Huile de Nigelle",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Noisette. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Sérum Anti-Imperfections une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sérum Anti-Imperfections",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Sérum Anti-Imperfections — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 36,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-elixir_regard_frais",
    "slug": "elixir-regard-frais",
    "canonicalUrl": "/recettes/cosmetiques/elixir-regard-frais/",
    "oldUrls": [
      "/herbier/elixir-regard-frais/",
      "/herbier/elixir-regard-frais",
      "/herbier/cosmetic-elixir_regard_frais/",
      "/herbier/cosmetic-elixir_regard_frais",
      "/herbier/cosmetique/elixir_regard_frais/",
      "/herbier/cosmetique/elixir_regard_frais",
      "/herbier/cosmetiques/elixir_regard_frais/",
      "/herbier/cosmetiques/elixir_regard_frais"
    ],
    "title": "Élixir Regard Frais",
    "subtitle": "Cosmétique — Cernes, poches, ridules de déshydratation...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Bleuet (20g)",
      "Thé Vert (15g)"
    ],
    "sachetA": {
      "composition": [
        "Bleuet (20g)"
      ],
      "solvent": "Huile de Calophylle",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Thé Vert (15g)"
      ],
      "solvent": "Huile d'Avocat",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Calophylle. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Élixir Regard Frais une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Élixir Regard Frais",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Élixir Regard Frais — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 37,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-baume_levres_calendula",
    "slug": "baume-levres-nourrissant",
    "canonicalUrl": "/recettes/cosmetiques/baume-levres-nourrissant/",
    "oldUrls": [
      "/herbier/baume-levres-nourrissant/",
      "/herbier/baume-levres-nourrissant",
      "/herbier/cosmetic-baume_levres_calendula/",
      "/herbier/cosmetic-baume_levres_calendula",
      "/herbier/cosmetique/baume_levres_calendula/",
      "/herbier/cosmetique/baume_levres_calendula",
      "/herbier/cosmetiques/baume_levres_calendula/",
      "/herbier/cosmetiques/baume_levres_calendula"
    ],
    "title": "Baume Lèvres Nourrissant",
    "subtitle": "Cosmétique — Lèvres abîmées, protection contre le froid...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T3"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Calendula (15g)",
      "Miel (10g)"
    ],
    "sachetA": {
      "composition": [
        "Calendula (15g)"
      ],
      "solvent": "Beurre de Karité",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Miel (10g)"
      ],
      "solvent": "Huile d'Amande Douce",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Beurre de Karité. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Baume Lèvres Nourrissant une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T3",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Baume Lèvres Nourrissant",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Baume Lèvres Nourrissant — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 38,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-lotion_tonique_camomille",
    "slug": "lotion-tonique-apaisante",
    "canonicalUrl": "/recettes/cosmetiques/lotion-tonique-apaisante/",
    "oldUrls": [
      "/herbier/lotion-tonique-apaisante/",
      "/herbier/lotion-tonique-apaisante",
      "/herbier/cosmetic-lotion_tonique_camomille/",
      "/herbier/cosmetic-lotion_tonique_camomille",
      "/herbier/cosmetique/lotion_tonique_camomille/",
      "/herbier/cosmetique/lotion_tonique_camomille",
      "/herbier/cosmetiques/lotion_tonique_camomille/",
      "/herbier/cosmetiques/lotion_tonique_camomille"
    ],
    "title": "Lotion Tonique Apaisante",
    "subtitle": "Cosmétique — Apaisement après nettoyage, préparation au soin...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Camomille Matricaire (20g)",
      "Lavande Vraie (10g)"
    ],
    "sachetA": {
      "composition": [
        "Camomille Matricaire (20g)"
      ],
      "solvent": "Hydrolat de Camomille",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Lavande Vraie (10g)"
      ],
      "solvent": "Eau de Rose",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Hydrolat de Camomille. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Lotion Tonique Apaisante une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lotion Tonique Apaisante",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Lotion Tonique Apaisante — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 39,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_precieuse_rose",
    "slug": "huile-precieuse-regenerante",
    "canonicalUrl": "/recettes/cosmetiques/huile-precieuse-regenerante/",
    "oldUrls": [
      "/herbier/huile-precieuse-regenerante/",
      "/herbier/huile-precieuse-regenerante",
      "/herbier/cosmetic-huile_precieuse_rose/",
      "/herbier/cosmetic-huile_precieuse_rose",
      "/herbier/cosmetique/huile_precieuse_rose/",
      "/herbier/cosmetique/huile_precieuse_rose",
      "/herbier/cosmetiques/huile_precieuse_rose/",
      "/herbier/cosmetiques/huile_precieuse_rose"
    ],
    "title": "Huile Précieuse Régénérante",
    "subtitle": "Cosmétique — Rides, fermeté, éclat du teint...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T5"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Rose de Damas (20g)",
      "Ciste Ladanifère (10g)"
    ],
    "sachetA": {
      "composition": [
        "Rose de Damas (20g)"
      ],
      "solvent": "Huile d'Argan",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Ciste Ladanifère (10g)"
      ],
      "solvent": "Huile de Rose Musquée",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile d'Argan. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Huile Précieuse Régénérante une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T5",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile Précieuse Régénérante",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile Précieuse Régénérante — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 40,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-gommage_corps_sel_botanique",
    "slug": "gommage-corps-botanique",
    "canonicalUrl": "/recettes/cosmetiques/gommage-corps-botanique/",
    "oldUrls": [
      "/herbier/gommage-corps-botanique/",
      "/herbier/gommage-corps-botanique",
      "/herbier/cosmetic-gommage_corps_sel_botanique/",
      "/herbier/cosmetic-gommage_corps_sel_botanique",
      "/herbier/cosmetique/gommage_corps_sel_botanique/",
      "/herbier/cosmetique/gommage_corps_sel_botanique",
      "/herbier/cosmetiques/gommage_corps_sel_botanique/",
      "/herbier/cosmetiques/gommage_corps_sel_botanique"
    ],
    "title": "Gommage Corps Botanique",
    "subtitle": "Cosmétique — Exfoliation, détoxication, peau douce...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Fucus (Algues) (30g)",
      "Romarin (10g)"
    ],
    "sachetA": {
      "composition": [
        "Fucus (Algues) (30g)"
      ],
      "solvent": "Huile de Tournesol",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Romarin (10g)"
      ],
      "solvent": "Sel de l'Himalaya",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Tournesol. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Gommage Corps Botanique une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Gommage Corps Botanique",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Gommage Corps Botanique — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 41,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_jambes_legeres",
    "slug": "huile-jambes-legeres",
    "canonicalUrl": "/recettes/cosmetiques/huile-jambes-legeres/",
    "oldUrls": [
      "/herbier/huile-jambes-legeres/",
      "/herbier/huile-jambes-legeres",
      "/herbier/cosmetic-huile_jambes_legeres/",
      "/herbier/cosmetic-huile_jambes_legeres",
      "/herbier/cosmetique/huile_jambes_legeres/",
      "/herbier/cosmetique/huile_jambes_legeres",
      "/herbier/cosmetiques/huile_jambes_legeres/",
      "/herbier/cosmetiques/huile_jambes_legeres"
    ],
    "title": "Huile Jambes Légères",
    "subtitle": "Cosmétique — Jambes lourdes, varicosités, drainage...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Vigne Rouge (40g)",
      "Marron d'Inde (20g)"
    ],
    "sachetA": {
      "composition": [
        "Vigne Rouge (40g)"
      ],
      "solvent": "Huile de Calophylle",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Marron d'Inde (20g)"
      ],
      "solvent": "Huile de Macadamia",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Calophylle. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Huile Jambes Légères une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile Jambes Légères",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile Jambes Légères — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 42,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-masque_capillaire_nutrition",
    "slug": "masque-capillaire-nutrition",
    "canonicalUrl": "/recettes/cosmetiques/masque-capillaire-nutrition/",
    "oldUrls": [
      "/herbier/masque-capillaire-nutrition/",
      "/herbier/masque-capillaire-nutrition",
      "/herbier/cosmetic-masque_capillaire_nutrition/",
      "/herbier/cosmetic-masque_capillaire_nutrition",
      "/herbier/cosmetique/masque_capillaire_nutrition/",
      "/herbier/cosmetique/masque_capillaire_nutrition",
      "/herbier/cosmetiques/masque_capillaire_nutrition/",
      "/herbier/cosmetiques/masque_capillaire_nutrition"
    ],
    "title": "Masque Capillaire Nutrition",
    "subtitle": "Cosmétique — Cheveux secs, cassants, pointes abîmées...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Europe Médiévale (Hildegarde de Bingen, Physica, XIIe siècle)",
      "period": "XIIe siècle",
      "quote": "« Il est dans la Création une force vivifiante (Viriditas) présente dans chaque herbe verte. » — Sainte Hildegarde de Bingen",
      "description": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Ortie (30g)",
      "Fénugrec (20g)"
    ],
    "sachetA": {
      "composition": [
        "Ortie (30g)"
      ],
      "solvent": "Beurre de Karité",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Fénugrec (20g)"
      ],
      "solvent": "Huile d'Avocat",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Beurre de Karité. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Approche monastique de la Viriditas végétale combinant principes amers, racines nobles et macérations vineuses pour réveiller la vitalité endormie. La tradition accorde à Masque Capillaire Nutrition une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Masque Capillaire Nutrition",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Masque Capillaire Nutrition — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 43,
    "gscClicks90d": 2,
    "batchNumber": 4,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-baume_mains_karite",
    "slug": "baume-mains-protecteur",
    "canonicalUrl": "/recettes/cosmetiques/baume-mains-protecteur/",
    "oldUrls": [
      "/herbier/baume-mains-protecteur/",
      "/herbier/baume-mains-protecteur",
      "/herbier/cosmetic-baume_mains_karite/",
      "/herbier/cosmetic-baume_mains_karite",
      "/herbier/cosmetique/baume_mains_karite/",
      "/herbier/cosmetique/baume_mains_karite",
      "/herbier/cosmetiques/baume_mains_karite/",
      "/herbier/cosmetiques/baume_mains_karite"
    ],
    "title": "Baume Mains Protecteur",
    "subtitle": "Cosmétique — Mains sèches, crevasses, protection quotidienne...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Médecine Traditionnelle Chinoise (Shennong Ben Cao Jing & Shanghan Lun)",
      "period": "IIIe siècle av. J.-C.",
      "quote": "« L’herbe supérieure nourrit le principe vital sans causer de dommage lors d’une longue consommation. » — Shennong Ben Cao Jing",
      "description": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T1"
    ],
    "axes": [
      "A1",
      "A4"
    ],
    "ingredients": [
      "Calendula (20g)",
      "Camomille (10g)"
    ],
    "sachetA": {
      "composition": [
        "Calendula (20g)"
      ],
      "solvent": "Beurre de Karité",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Camomille (10g)"
      ],
      "solvent": "Glycérine Végétale",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Beurre de Karité. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Équilibrage du Qi, tonification des méridiens du Rein et de la Rate, et combinaison impériale (Empereur, Ministre, Assistant, Ambassadeur). La tradition accorde à Baume Mains Protecteur une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T1",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Baume Mains Protecteur",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Baume Mains Protecteur — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 34,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_demaquillante_yeux",
    "slug": "huile-demaquillante-yeux",
    "canonicalUrl": "/recettes/cosmetiques/huile-demaquillante-yeux/",
    "oldUrls": [
      "/herbier/huile-demaquillante-yeux/",
      "/herbier/huile-demaquillante-yeux",
      "/herbier/cosmetic-huile_demaquillante_yeux/",
      "/herbier/cosmetic-huile_demaquillante_yeux",
      "/herbier/cosmetique/huile_demaquillante_yeux/",
      "/herbier/cosmetique/huile_demaquillante_yeux",
      "/herbier/cosmetiques/huile_demaquillante_yeux/",
      "/herbier/cosmetiques/huile_demaquillante_yeux"
    ],
    "title": "Huile Démaquillante Yeux",
    "subtitle": "Cosmétique — Démaquillage doux des yeux, soin des cils...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Ayurveda Védique (Charaka Samhita & Sushruta Samhita, Inde)",
      "period": "Ve siècle av. J.-C.",
      "quote": "« Lorsque le feu digestif (Agni) est préservé, le poison (Ama) ne peut s’accumuler dans les tissus. » — Charaka Samhita",
      "description": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus)."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T2"
    ],
    "axes": [
      "A2",
      "A5"
    ],
    "ingredients": [
      "Bleuet (30g)",
      "Camomille (10g)"
    ],
    "sachetA": {
      "composition": [
        "Bleuet (30g)"
      ],
      "solvent": "Huile d'Amande Douce",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Camomille (10g)"
      ],
      "solvent": "Huile de Ricin",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile d'Amande Douce. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Utilisation de solvants lipidiques nobles (ghee, huiles) pour transporter les principes actifs liposolubles à travers les sept tissus (Dhatus). La tradition accorde à Huile Démaquillante Yeux une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T2",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile Démaquillante Yeux",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile Démaquillante Yeux — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 35,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-elixir_nuit_apaisant",
    "slug": "elixir-de-nuit-apaisant",
    "canonicalUrl": "/recettes/cosmetiques/elixir-de-nuit-apaisant/",
    "oldUrls": [
      "/herbier/elixir-de-nuit-apaisant/",
      "/herbier/elixir-de-nuit-apaisant",
      "/herbier/cosmetic-elixir_nuit_apaisant/",
      "/herbier/cosmetic-elixir_nuit_apaisant",
      "/herbier/cosmetique/elixir_nuit_apaisant/",
      "/herbier/cosmetique/elixir_nuit_apaisant",
      "/herbier/cosmetiques/elixir_nuit_apaisant/",
      "/herbier/cosmetiques/elixir_nuit_apaisant"
    ],
    "title": "Élixir de Nuit Apaisant",
    "subtitle": "Cosmétique — Peau fatiguée par le stress, détente nocturne...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Traditions Berbères & Tamazight (Atlas & Oasis)",
      "period": "Antiquité & Moyen Âge",
      "quote": "« L’armoise et le thym sauvage lavent les fatigues des pistes et scellent la peau du voyageur. » — Sagesse orale de l’Atlas",
      "description": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes / Stressées"
    ],
    "axes": [
      "A3",
      "A6"
    ],
    "ingredients": [
      "Mélisse (30g)",
      "Valériane (15g)"
    ],
    "sachetA": {
      "composition": [
        "Mélisse (30g)"
      ],
      "solvent": "Huile de Jojoba",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Valériane (15g)"
      ],
      "solvent": "Huile de Millepertuis",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Jojoba. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Phytothérapie d’altitude et macérations d’arbustes xérophiles résistants aux amplitudes thermiques extrêmes pour fortifier l’immunité. La tradition accorde à Élixir de Nuit Apaisant une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes / Stressées",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Élixir de Nuit Apaisant",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Élixir de Nuit Apaisant — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 36,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-serum_hydratation_profonde",
    "slug": "serum-hydratation",
    "canonicalUrl": "/recettes/cosmetiques/serum-hydratation/",
    "oldUrls": [
      "/herbier/serum-hydratation/",
      "/herbier/serum-hydratation",
      "/herbier/cosmetic-serum_hydratation_profonde/",
      "/herbier/cosmetic-serum_hydratation_profonde",
      "/herbier/cosmetique/serum_hydratation_profonde/",
      "/herbier/cosmetique/serum_hydratation_profonde",
      "/herbier/cosmetiques/serum_hydratation_profonde/",
      "/herbier/cosmetiques/serum_hydratation_profonde"
    ],
    "title": "Sérum Hydratation",
    "subtitle": "Cosmétique — Manque d'eau, tiraillements...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Pharmacopée Amazonienne (Herboristerie des Peuples Premiers)",
      "period": "Tradition millénaire",
      "quote": "« Les plantes maîtresses instruisent le corps par la saveur et la résonance du vivant. » — Mémoire amazonienne",
      "description": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T4"
    ],
    "axes": [
      "A4",
      "A7"
    ],
    "ingredients": [
      "Mauve (20g)",
      "Tilleul (15g)"
    ],
    "sachetA": {
      "composition": [
        "Mauve (20g)"
      ],
      "solvent": "Gel d'Aloé Vera",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Tilleul (15g)"
      ],
      "solvent": "Eau de Rose",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Gel d'Aloé Vera. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Extraction hydro-alcoolique de lianes denses, écorces et champignons adaptogènes stimulant les réponses immunitaires profondes. La tradition accorde à Sérum Hydratation une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T4",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Sérum Hydratation",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Sérum Hydratation — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 37,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-huile_barbe_visage",
    "slug": "huile-de-barbe-visage",
    "canonicalUrl": "/recettes/cosmetiques/huile-de-barbe-visage/",
    "oldUrls": [
      "/herbier/huile-de-barbe-visage/",
      "/herbier/huile-de-barbe-visage",
      "/herbier/cosmetic-huile_barbe_visage/",
      "/herbier/cosmetic-huile_barbe_visage",
      "/herbier/cosmetique/huile_barbe_visage/",
      "/herbier/cosmetique/huile_barbe_visage",
      "/herbier/cosmetiques/huile_barbe_visage/",
      "/herbier/cosmetiques/huile_barbe_visage"
    ],
    "title": "Huile de Barbe & Visage",
    "subtitle": "Cosmétique — Entretien barbe, peau dessous irritée...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Kabbale & Hermétisme Spagyrique (Renaissance & Paracelse)",
      "period": "XVIe siècle",
      "quote": "« Sépare le subtil de l’épais avec grande ingéniosité. La nature est le médecin, l’homme n’est que l’opérateur. » — Paracelse, Archidoxes",
      "description": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A5",
      "A8"
    ],
    "ingredients": [
      "Cèdre de l'Atlas (30g)",
      "Gingembre (15g)"
    ],
    "sachetA": {
      "composition": [
        "Cèdre de l'Atlas (30g)"
      ],
      "solvent": "Huile de Jojoba",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Gingembre (15g)"
      ],
      "solvent": "Huile de Sésame",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Jojoba. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Séquençage actif des trois principes (Sel, Soufre, Mercure) réconciliant minéraux solubles et essences volatiles en extraction douce. La tradition accorde à Huile de Barbe & Visage une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Huile de Barbe & Visage",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Huile de Barbe & Visage — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 38,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-masque_detox_argile",
    "slug": "masque-detox",
    "canonicalUrl": "/recettes/cosmetiques/masque-detox/",
    "oldUrls": [
      "/herbier/masque-detox/",
      "/herbier/masque-detox",
      "/herbier/cosmetic-masque_detox_argile/",
      "/herbier/cosmetic-masque_detox_argile",
      "/herbier/cosmetique/masque_detox_argile/",
      "/herbier/cosmetique/masque_detox_argile",
      "/herbier/cosmetiques/masque_detox_argile/",
      "/herbier/cosmetiques/masque_detox_argile"
    ],
    "title": "Masque Détox",
    "subtitle": "Cosmétique — Détoxification, impuretés, pollution...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Biochimie & Totum Moderne (Pharmacopée Européenne & Recherche Contemporaine)",
      "period": "XXIe siècle",
      "quote": "« Le Totum moléculaire complet induit une synergie cinétique supérieure à la somme de ses composés isolés. » — Pharmacologie végétale moderne",
      "description": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T6"
    ],
    "axes": [
      "A6",
      "A9"
    ],
    "ingredients": [
      "Ortie (40g)",
      "Argile Verte (200g)"
    ],
    "sachetA": {
      "composition": [
        "Ortie (40g)"
      ],
      "solvent": "Huile de Noisette",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Argile Verte (200g)"
      ],
      "solvent": "Eau purifiée",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Noisette. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Standardisation thermo-régulée et extraction vortex à basse température pour maximiser la biodisponibilité sans stress oxydatif. La tradition accorde à Masque Détox une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T6",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Masque Détox",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Masque Détox — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 39,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-lotion_capillaire_ortie",
    "slug": "lotion-tonique-capillaire",
    "canonicalUrl": "/recettes/cosmetiques/lotion-tonique-capillaire/",
    "oldUrls": [
      "/herbier/lotion-tonique-capillaire/",
      "/herbier/lotion-tonique-capillaire",
      "/herbier/cosmetic-lotion_capillaire_ortie/",
      "/herbier/cosmetic-lotion_capillaire_ortie",
      "/herbier/cosmetique/lotion_capillaire_ortie/",
      "/herbier/cosmetique/lotion_capillaire_ortie",
      "/herbier/cosmetiques/lotion_capillaire_ortie/",
      "/herbier/cosmetiques/lotion_capillaire_ortie"
    ],
    "title": "Lotion Tonique Capillaire",
    "subtitle": "Cosmétique — Fortification, brillance, cuir chevelu sain...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Égypte Antique (Papyrus Ebers, ~1550 av. J.-C.)",
      "period": "XVIe siècle av. J.-C.",
      "quote": "« Que la plante apporte le souffle de vie là où le canal est obstrué. » — Papyrus Ebers",
      "description": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A7",
      "A1"
    ],
    "ingredients": [
      "Ortie (50g)",
      "Romarin (20g)"
    ],
    "sachetA": {
      "composition": [
        "Ortie (50g)"
      ],
      "solvent": "Vinaigre de Cidre",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Romarin (20g)"
      ],
      "solvent": "Eau de Source",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Vinaigre de Cidre. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Usage des macérations aromatiques et résines médicinales pour purifier les conduits vitaux (metu) et rétablir l’équilibre des humeurs corporelles. La tradition accorde à Lotion Tonique Capillaire une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Lotion Tonique Capillaire",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Lotion Tonique Capillaire — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 30,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-soin_pieds_relaxant",
    "slug": "baume-pieds-relaxant",
    "canonicalUrl": "/recettes/cosmetiques/baume-pieds-relaxant/",
    "oldUrls": [
      "/herbier/baume-pieds-relaxant/",
      "/herbier/baume-pieds-relaxant",
      "/herbier/cosmetic-soin_pieds_relaxant/",
      "/herbier/cosmetic-soin_pieds_relaxant",
      "/herbier/cosmetique/soin_pieds_relaxant/",
      "/herbier/cosmetique/soin_pieds_relaxant",
      "/herbier/cosmetiques/soin_pieds_relaxant/",
      "/herbier/cosmetiques/soin_pieds_relaxant"
    ],
    "title": "Baume Pieds Relaxant",
    "subtitle": "Cosmétique — Pieds fatigués, échauffements...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Grèce Classique (Hippocrate & Dioscoride, De Materia Medica, ~60 ap. J.-C.)",
      "period": "Ier siècle ap. J.-C.",
      "quote": "« Que ton aliment soit ton seul médicament et ton médicament ton aliment. » — Corpus Hippocraticum",
      "description": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "T8"
    ],
    "axes": [
      "A8",
      "A2"
    ],
    "ingredients": [
      "Menthe Poivrée (40g)",
      "Eucalyptus (20g)"
    ],
    "sachetA": {
      "composition": [
        "Menthe Poivrée (40g)"
      ],
      "solvent": "Huile de Coco",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Eucalyptus (20g)"
      ],
      "solvent": "Beurre de Karité",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Coco. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Théorie des quatre éléments et régulation du terrain par des extractions tièdes préservant la quintessence active du végétal. La tradition accorde à Baume Pieds Relaxant une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain T8",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Baume Pieds Relaxant",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Baume Pieds Relaxant — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 31,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  },
  {
    "id": "herbier-cosmetic-dentifrice_remineralisant_coco_girofle",
    "slug": "dentifrice-remineralisant-pubbling-coco",
    "canonicalUrl": "/recettes/cosmetiques/dentifrice-remineralisant-pubbling-coco/",
    "oldUrls": [
      "/herbier/dentifrice-remineralisant-pubbling-coco/",
      "/herbier/dentifrice-remineralisant-pubbling-coco",
      "/herbier/cosmetic-dentifrice_remineralisant_coco_girofle/",
      "/herbier/cosmetic-dentifrice_remineralisant_coco_girofle",
      "/herbier/cosmetique/dentifrice_remineralisant_coco_girofle/",
      "/herbier/cosmetique/dentifrice_remineralisant_coco_girofle",
      "/herbier/cosmetiques/dentifrice_remineralisant_coco_girofle/",
      "/herbier/cosmetiques/dentifrice_remineralisant_coco_girofle"
    ],
    "title": "Dentifrice Reminéralisant & Pubbling Coco",
    "subtitle": "Cosmétique — Reminéralisation de l'émail, hygiène anti-plaque, santé des gencives, inflammation buccale...",
    "category": "cosmetique",
    "categorySlug": "cosmetiques",
    "categoryLabel": "Cosmétique",
    "subcategory": "Soin Botanique & Macérat",
    "difficultyLevel": 3,
    "difficultyLabel": "Intermédiaire",
    "prepTimeMinutes": 15,
    "machineTimeMinutes": 45,
    "totalTimeMinutes": 60,
    "tempSachetA": "65°C",
    "tempSachetB": "40°C",
    "shelfLife": "6 mois à température ambiante dans un flacon pipette ambré",
    "yieldMl": 100,
    "heritage": {
      "register": "Perse & Islam Doré (Avicenne, Le Canon de la Médecine, 1025)",
      "period": "XIe siècle",
      "quote": "« Le médecin avisé soigne d’abord le terrain, puis fortifie l’organe avant de chasser l’humeur corrompue. » — Avicenne, Kitab al-Qanun fi al-Tibb",
      "description": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux."
    },
    "doctrinaSignaturae": {
      "visualAspect": "Plante entière aux équilibres morphologiques harmonieux et réserves de résines protectrices.",
      "doctrineInterpretation": "La plante entière incarne l’homéostasie dynamique, protégeant l’organisme des agressions environnementales extérieures.",
      "organTarget": "Terrain biologique global et homéostasie tissulaire"
    },
    "terrains": [
      "Toutes"
    ],
    "axes": [
      "A9",
      "A3"
    ],
    "ingredients": [
      "Clou de Girofle & Cannelle (10g + 2g)",
      "Hydroxyapatite & Argile (15g + 30g)"
    ],
    "sachetA": {
      "composition": [
        "Clou de Girofle & Cannelle (10g + 2g)"
      ],
      "solvent": "Huile de Coco BIO",
      "temp": "65°C",
      "duration": "1h30"
    },
    "sachetB": {
      "composition": [
        "Hydroxyapatite & Argile (15g + 30g)"
      ],
      "solvent": "Phase poudreuse",
      "temp": "40°C",
      "duration": "2h00"
    },
    "instructions": [
      "Étape 1 : Préparation du macérat cutané — Peser avec précision les extraits botaniques sélectionnés pour l'application topique.",
      "Étape 2 : Extraction lipidique douce (Sachet A) — Placer la matière dans la cuve inox 304 avec Huile de Coco BIO. Chauffer à 65°C sous vortex cinétique doux pour dissoudre les caroténoïdes et phytostérols.",
      "Étape 3 : Stabilisation des principes volatils (Sachet B) — Ajouter la phase B à 40°C en chambre close étanche pour préserver les esters aromatiques protecteurs.",
      "Étape 4 : Filtration clarifiante — Filtrer à travers une étamine fine en lin ou papier filtre non blanchi.",
      "Étape 5 : Conditionnement & Conservation — Conditionner en flacon compte-gouttes teinté. Conserver à température ambiante à l’abri des rayons solaires directs."
    ],
    "molecularSignature": [
      {
        "molecule": "Totum moléculaire actif",
        "mechanism": "Synergie pluri-composée optimisant la biodisponibilité cellulaire sans isolats de synthèse.",
        "evidenceLevel": "Consensus pharmacopée internationale (OMS & Ph. Eur.)"
      }
    ],
    "traditionalWisdom": "Art raffiné des eaux distillées, macérats alcooliques doux et synergies polyvalentes régulant les tempéraments fondamentaux. La tradition accorde à Dentifrice Reminéralisant & Pubbling Coco une place de choix pour moduler le terrain et fortifier la vitalité sans bousculer les équilibres intérieurs.",
    "precautions": [
      "Ne pas dépasser le dosage journalier recommandé.",
      "Tenir hors de portée des jeunes enfants.",
      "Femmes enceintes ou allaitantes : solliciter l’avis formel d’un professionnel de santé."
    ],
    "contraindications": [
      "Allergie avérée aux composants de la formule",
      "Pathologies chroniques rénales ou hépatiques non compensées sans surveillance médicale"
    ],
    "safetyWarning": "Avertissement réglementaire : Cette fiche de formulation botanique a une vocation strictement pédagogique et éducative. Elle ne constitue en aucun cas un diagnostic médical ni une prescription thérapeutique. En cas de pathologie ou de traitement en cours, demandez conseil à votre médecin.",
    "observationsExpected": "L’utilisateur pourrait observer une sensation de légèreté digestive, un apaisement progressif du tonus nerveux et une meilleure régularité du rythme diurne après 10 à 14 jours d’utilisation régulière.",
    "contextualLinks": {
      "bloomLabKit": {
        "name": "Extracteur BloomLab® Précision Inox 304",
        "url": "/bloomlab/"
      },
      "academyProtocol": {
        "name": "Comprendre le Terrain Toutes",
        "url": "/academie/comprendre-le-corps/"
      },
      "plantMonograph": {
        "name": "Monographie Botanique Dentifrice Reminéralisant & Pubbling Coco",
        "url": "/academie/herbier/"
      },
      "blogArticle": {
        "name": "Guide des Solvants et de l’Extraction Douce",
        "url": "/articles/comment-fabriquer-huiles-infusees-teintures-maison/"
      }
    },
    "image": "/images/og/cosmetique-botanique-macerat-huileux-1200x630.jpg",
    "imageAlt": "Dentifrice Reminéralisant & Pubbling Coco — Protocole d'extraction botanique de précision BloomLab®",
    "schemaType": "Article",
    "gscImpressions90d": 32,
    "gscClicks90d": 2,
    "batchNumber": 5,
    "batchPriority": "moyenne",
    "isDuplicateWith81": false,
    "datePublished": "2026-09-01T08:00:00+02:00",
    "dateModified": "2026-10-09T08:00:00+02:00"
  }
];

export const HERBIER_RECIPES_BY_PATH = new Map<string, HerbierRecipe>(
  HERBIER_RECIPES.map(r => [r.canonicalUrl, r])
);

export const HERBIER_RECIPES_BY_SLUG = new Map<string, HerbierRecipe>(
  HERBIER_RECIPES.map(r => [r.slug, r])
);

export function getHerbierRecipeByPath(path: string): HerbierRecipe | undefined {
  const normalized = path.endsWith('/') ? path : `${path}/`;
  return HERBIER_RECIPES_BY_PATH.get(normalized);
}

export function getHerbierRecipeBySlug(slug: string): HerbierRecipe | undefined {
  return HERBIER_RECIPES_BY_SLUG.get(slug);
}

export function getHerbierRecipesByBatch(batchNumber: number): HerbierRecipe[] {
  return HERBIER_RECIPES.filter(r => r.batchNumber === batchNumber);
}

export function getHerbierRecipesByCategory(category: 'phytotherapie' | 'cosmetique' | 'gastronomie'): HerbierRecipe[] {
  return HERBIER_RECIPES.filter(r => r.category === category);
}
