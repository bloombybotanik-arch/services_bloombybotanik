import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { validateRecipeRoute } from './src/utils/recipeRouteValidator';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Analyse des arguments CLI et variables d'environnement pour le port
function resolvePort(): number {
  const args = process.argv.slice(2);
  const portArgIndex = args.indexOf('--port');
  if (portArgIndex !== -1 && args[portArgIndex + 1]) {
    const parsed = parseInt(args[portArgIndex + 1], 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  if (process.env.DEFAULT_APP_PORT) {
    const parsed = parseInt(process.env.DEFAULT_APP_PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  // En environnement AI Studio / Cloud Run, Nginx écoute sur 8080 et proxie vers 3000
  if (process.env.PORT && process.env.PORT !== '8080') {
    const parsed = parseInt(process.env.PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3000;
}

async function startServer() {
  const app = express();
  const PORT = resolvePort();
  const isProduction = process.env.NODE_ENV === 'production';
  const publicDir = fs.existsSync(path.resolve(__dirname, 'public'))
    ? path.resolve(__dirname, 'public')
    : path.resolve(__dirname, '../public');

  const distDir = fs.existsSync(path.resolve(__dirname, 'index.html'))
    ? __dirname
    : path.resolve(__dirname, 'dist');

  app.use(express.json());

  // Point de contrôle santé
  app.get('/health', (req, res) => {
    res.json({
      status: 'healthy',
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  // Fichiers statiques publics
  if (fs.existsSync(publicDir)) {
    app.use(express.static(publicDir, { index: false }));
  }

  // XML Sitemaps
  app.get('/sitemap.xml', (req, res) => {
    const sitemapPath = path.resolve(publicDir, 'sitemap.xml');
    if (fs.existsSync(sitemapPath)) {
      res.setHeader('Content-Type', 'application/xml');
      return res.sendFile(sitemapPath);
    }
    res.setHeader('Content-Type', 'application/xml');
    res.send(`<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap><loc>https://bloombybotanik.com/sitemap-recettes.xml</loc></sitemap>
</sitemapindex>`);
  });

  app.get('/sitemap-recettes.xml', (req, res) => {
    const sitemapPath = path.resolve(publicDir, 'sitemap-recettes.xml');
    if (fs.existsSync(sitemapPath)) {
      res.setHeader('Content-Type', 'application/xml');
      return res.sendFile(sitemapPath);
    }
    res.setHeader('Content-Type', 'application/xml');
    res.send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://bloombybotanik.com/recettes/</loc></url>
  <url><loc>https://bloombybotanik.com/recettes/culinaires/</loc></url>
  <url><loc>https://bloombybotanik.com/recettes/cosmetiques/</loc></url>
  <url><loc>https://bloombybotanik.com/recettes/parcours-botaniques/</loc></url>
</urlset>`);
  });

  if (!isProduction) {
    // Mode développement : Vite avec middlewares et transformIndexHtml explicite
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });

    // 1. Vite middlewares pour les assets et modules JS/CSS (sans intercepter le HTML SPA)
    app.use(vite.middlewares);

    // 2. Gestionnaire HTML explicite en développement
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;

      // Ne pas intercepter les requêtes qui cherchent des fichiers JS, CSS, JSON ou images
      if (
        url.startsWith('/@') ||
        url.startsWith('/src/') ||
        url.startsWith('/node_modules/') ||
        /\.(js|ts|jsx|tsx|css|png|jpg|jpeg|gif|svg|webp|ico|woff|woff2|ttf|map)$/.test(url.split('?')[0])
      ) {
        return next();
      }

      try {
        const indexPath = path.resolve(__dirname, 'index.html');
        let template = await fs.promises.readFile(indexPath, 'utf-8');

        // Transformation Vite (injecte le client Vite et React Refresh)
        template = await vite.transformIndexHtml(url, template);

        // Stratégie de template structurelle : remplacement propre de <div id="root"></div>
        // sans regex fragile sur les balises imbriquées
        const html = template;

        let statusCode = 200;
        if (url.startsWith('/recettes')) {
          const validation = validateRecipeRoute(url);
          if (!validation.isValid) {
            statusCode = 404;
          }
        }

        res.status(statusCode).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(html);
      } catch (err: any) {
        vite.ssrFixStacktrace(err);
        console.error('Erreur rendu HTML Vite:', err);
        next(err);
      }
    });
  } else {
    // Mode production
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir, { index: false }));
      app.get('*', (req, res) => {
        let statusCode = 200;
        if (req.originalUrl.startsWith('/recettes')) {
          const validation = validateRecipeRoute(req.originalUrl);
          if (!validation.isValid) {
            statusCode = 404;
          }
        }
        res.status(statusCode).sendFile(path.resolve(distDir, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Bloom by BotaniK server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
