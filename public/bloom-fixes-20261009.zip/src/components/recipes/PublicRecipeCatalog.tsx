import React, { useState, useEffect, useMemo } from 'react';
import {
  CANONICAL_RECIPES,
  CATEGORY_METADATA,
  CanonicalRecipe
} from '../../data/canonicalRecipesRegistry';
import { validateRecipeRoute, RECIPES_PER_PAGE } from '../../utils/recipeRouteValidator';
import { updateDocumentSEO } from '../../utils/seoManager';
import { Clock, ChefHat, Sparkles, ChevronRight, ChevronLeft, ArrowLeft, ShieldAlert, FileQuestion } from 'lucide-react';

interface PublicRecipeCatalogProps {
  initialPath?: string;
  onNavigate?: (path: string) => void;
  lang?: any;
}

export const PublicRecipeCatalog: React.FC<PublicRecipeCatalogProps> = ({
  initialPath = '/recettes/',
  onNavigate
}) => {
  const [currentPath, setCurrentPath] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname;
    }
    return initialPath;
  });

  useEffect(() => {
    const handlePop = () => {
      if (typeof window !== 'undefined') {
        setCurrentPath(window.location.pathname);
      }
    };
    window.addEventListener('popstate', handlePop);
    return () => window.removeEventListener('popstate', handlePop);
  }, []);

  useEffect(() => {
    if (initialPath && typeof window !== 'undefined' && window.location.pathname !== currentPath) {
      setCurrentPath(window.location.pathname);
    }
  }, [initialPath]);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) {
      return; // Permettre l'ouverture dans un nouvel onglet sans blocage
    }
    e.preventDefault();
    setCurrentPath(path);
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', path);
    }
    if (onNavigate) {
      onNavigate(path);
    }
  };

  // Validation exacte de la route
  const validation = useMemo(() => validateRecipeRoute(currentPath), [currentPath]);
  const isNotFound = !validation.isValid;
  const isDetail = validation.type === 'detail';
  const selectedRecipe = validation.recipe || null;
  const currentCategory = validation.category || 'hub';
  const currentPageNum = validation.pageNum || 1;

  // Synchronisation SEO
  useEffect(() => {
    if (isNotFound) {
      updateDocumentSEO({
        title: "Recette introuvable | Bloom by BotaniK",
        description: "La ressource demandée n'existe pas ou a été déplacée.",
        canonical: `https://bloombybotanik.com/recettes/`
      });
      return;
    }

    if (isDetail && selectedRecipe) {
      const isCulinary = selectedRecipe.category === 'culinaire';
      const schema = isCulinary
        ? {
            '@context': 'https://schema.org',
            '@type': 'Recipe',
            name: selectedRecipe.title,
            description: selectedRecipe.summary,
            image: [selectedRecipe.image],
            recipeCategory: selectedRecipe.categoryLabel,
            prepTime: `PT${selectedRecipe.activeTimeMinutes}M`,
            cookTime: `PT${selectedRecipe.machineTimeMinutes}M`,
            totalTime: `PT${selectedRecipe.totalTimeMinutes}M`,
            recipeIngredient: selectedRecipe.ingredients,
            recipeInstructions: selectedRecipe.instructions.map((ins, idx) => ({
              '@type': 'HowToStep',
              position: idx + 1,
              text: ins
            }))
          }
        : {
            '@context': 'https://schema.org',
            '@type': 'Article',
            headline: selectedRecipe.title,
            description: selectedRecipe.summary,
            image: [selectedRecipe.image]
          };

      updateDocumentSEO({
        title: `${selectedRecipe.title} | Bloom by BotaniK`,
        description: selectedRecipe.summary,
        canonical: `https://bloombybotanik.com${selectedRecipe.canonicalUrl}`,
        schema
      });
    } else {
      const meta = CATEGORY_METADATA[currentCategory] || CATEGORY_METADATA['hub'];
      const pageSuffix = currentPageNum > 1 ? ` — Page ${currentPageNum}` : '';
      updateDocumentSEO({
        title: `${meta.title}${pageSuffix}`,
        description: meta.metaDescription,
        canonical: `https://bloombybotanik.com${meta.path}${currentPageNum > 1 ? `page/${currentPageNum}/` : ''}`
      });
    }
  }, [isNotFound, isDetail, selectedRecipe, currentCategory, currentPageNum]);

  // VUE 404 : Recette introuvable
  if (isNotFound) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center bg-[#F9F9F7] text-[#1B3022] px-4 py-16">
        <div className="max-w-md w-full bg-white rounded-3xl border border-stone-200 p-8 sm:p-10 text-center shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-800 flex items-center justify-center mx-auto mb-6">
            <FileQuestion className="w-8 h-8" />
          </div>
          <span className="text-xs font-mono uppercase tracking-widest text-stone-400 block mb-2">Erreur 404</span>
          <h1 className="text-2xl font-serif font-bold text-[#1B3022] mb-3">Recette introuvable</h1>
          <p className="text-sm text-stone-600 leading-relaxed mb-8">
            La formule botanique que vous recherchez n'existe pas ou son adresse a été modifiée.
          </p>
          <div className="flex flex-col gap-3">
            <a
              href="/recettes/"
              onClick={(e) => handleLinkClick(e, '/recettes/')}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#1B3022] hover:bg-[#D97706] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
            >
              <ArrowLeft className="w-4 h-4" /> Retour au catalogue public
            </a>
            <a
              href="/recettes/culinaires/"
              onClick={(e) => handleLinkClick(e, '/recettes/culinaires/')}
              className="text-xs text-stone-500 hover:text-stone-800 underline transition-colors"
            >
              Consulter les recettes culinaires
            </a>
          </div>
        </div>
      </div>
    );
  }

  // VUE DETAIL : Fiche recette existante
  if (isDetail && selectedRecipe) {
    return (
      <div className="min-h-screen bg-[#F9F9F7] text-[#1B3022] py-8 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <nav aria-label="Fil d'Ariane" className="flex items-center gap-2 text-xs text-stone-500 mb-6">
          <a
            href="/recettes/"
            onClick={(e) => handleLinkClick(e, '/recettes/')}
            className="hover:text-stone-900 underline"
          >
            Recettes
          </a>
          <ChevronRight className="w-3 h-3" />
          <a
            href={
              selectedRecipe.category === 'culinaire'
                ? '/recettes/culinaires/'
                : selectedRecipe.category === 'cosmetique'
                ? '/recettes/cosmetiques/'
                : '/recettes/parcours-botaniques/'
            }
            onClick={(e) =>
              handleLinkClick(
                e,
                selectedRecipe.category === 'culinaire'
                  ? '/recettes/culinaires/'
                  : selectedRecipe.category === 'cosmetique'
                  ? '/recettes/cosmetiques/'
                  : '/recettes/parcours-botaniques/'
              )
            }
            className="hover:text-stone-900 underline"
          >
            {selectedRecipe.categoryLabel}
          </a>
          <ChevronRight className="w-3 h-3" />
          <span className="text-stone-800 font-medium truncate">{selectedRecipe.title}</span>
        </nav>

        <a
          href="/recettes/"
          onClick={(e) => handleLinkClick(e, '/recettes/')}
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#1B3022] hover:text-[#D97706] mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Retour aux recettes
        </a>

        <article className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm p-6 sm:p-10">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="px-3 py-1 bg-stone-100 text-stone-700 text-xs rounded-full uppercase tracking-wider font-mono">
              {selectedRecipe.categoryLabel}
            </span>
            <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs rounded-full uppercase tracking-wider font-mono">
              Difficulté : {selectedRecipe.difficulty}
            </span>
            {selectedRecipe.temperatures && (
              <span className="px-3 py-1 bg-amber-50 text-amber-800 text-xs rounded-full uppercase tracking-wider font-mono">
                {selectedRecipe.temperatures}
              </span>
            )}
          </div>

          <h1 className="text-2xl sm:text-4xl font-serif font-bold text-[#1B3022] mb-4 leading-tight">
            {selectedRecipe.title}
          </h1>

          <p className="text-stone-600 text-sm sm:text-base leading-relaxed mb-8">
            {selectedRecipe.summary}
          </p>

          <div className="grid grid-cols-3 gap-4 p-4 bg-[#F9F9F7] rounded-xl mb-8 text-center text-xs">
            <div>
              <span className="text-stone-500 block mb-1">Temps actif</span>
              <strong className="text-stone-800 text-sm">{selectedRecipe.activeTimeMinutes} min</strong>
            </div>
            <div>
              <span className="text-stone-500 block mb-1">Temps machine</span>
              <strong className="text-stone-800 text-sm">{selectedRecipe.machineTimeMinutes} min</strong>
            </div>
            <div>
              <span className="text-stone-500 block mb-1">Durée totale</span>
              <strong className="text-stone-800 text-sm">{selectedRecipe.totalTimeMinutes} min</strong>
            </div>
          </div>

          {/* Ingrédients */}
          <div className="mb-8">
            <h2 className="text-lg font-serif font-bold text-[#1B3022] mb-4 flex items-center gap-2">
              <ChefHat className="w-5 h-5 text-emerald-700" /> Ingrédients & Matières premières
            </h2>
            <ul className="space-y-2 text-sm text-stone-700 list-disc list-inside">
              {selectedRecipe.ingredients.map((ing, idx) => (
                <li key={idx}>{ing}</li>
              ))}
            </ul>
          </div>

          {/* Instructions */}
          <div className="mb-8">
            <h2 className="text-lg font-serif font-bold text-[#1B3022] mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-700" /> Protocole d'extraction & Étapes
            </h2>
            <ol className="space-y-3 text-sm text-stone-700 list-decimal list-inside">
              {selectedRecipe.instructions.map((step, idx) => (
                <li key={idx} className="leading-relaxed pl-1">{step}</li>
              ))}
            </ol>
          </div>

          {/* Précautions */}
          {selectedRecipe.precautions && selectedRecipe.precautions.length > 0 && (
            <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-xl text-xs text-amber-900 mb-8 flex gap-3">
              <ShieldAlert className="w-5 h-5 flex-shrink-0 text-amber-700" />
              <div>
                <strong className="block mb-1 font-semibold">Précautions d'emploi :</strong>
                {selectedRecipe.precautions.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </div>
          )}

          {/* CTA Bloom Complet */}
          <div className="p-6 bg-[#1B3022] text-[#FAF8F5] rounded-xl text-center">
            <h3 className="font-serif font-bold text-lg mb-2">Envie de réaliser cette recette chez vous ?</h3>
            <p className="text-xs text-stone-300 mb-4 max-w-lg mx-auto">
              L'accompagnement Bloom Complet vous guide pas à pas dans l'intégration quotidienne des extractions botaniques adaptées à votre terrain.
            </p>
            <a
              href="/abonnement"
              onClick={(e) => handleLinkClick(e, '/abonnement')}
              className="inline-block px-6 py-2.5 bg-[#FAF8F5] text-[#1B3022] rounded-lg text-xs font-bold hover:bg-[#D97706] hover:text-white uppercase tracking-wider transition-colors"
            >
              Découvrir la formule Bloom Complet (59 €/mois)
            </a>
          </div>
        </article>
      </div>
    );
  }

  // VUE LISTE & CATEGORIE AVEC PAGINATION
  const allCategoryRecipes = CANONICAL_RECIPES.filter((r) => {
    if (currentCategory === 'culinaires') return r.category === 'culinaire';
    if (currentCategory === 'cosmetiques') return r.category === 'cosmetique';
    if (currentCategory === 'parcours-botaniques') return r.category === 'parcours-guide';
    return true;
  });

  const perPage = currentCategory === 'hub' ? 6 : RECIPES_PER_PAGE;
  const totalPages = Math.max(1, Math.ceil(allCategoryRecipes.length / perPage));
  const safePageNum = Math.min(Math.max(1, currentPageNum), totalPages);

  const paginatedRecipes = allCategoryRecipes.slice(
    (safePageNum - 1) * perPage,
    safePageNum * perPage
  );

  const categoryMeta = CATEGORY_METADATA[currentCategory] || CATEGORY_METADATA['hub'];

  const getPageUrl = (page: number) => {
    const basePath = categoryMeta.path;
    return page === 1 ? basePath : `${basePath}page/${page}/`;
  };

  return (
    <div className="min-h-screen bg-[#F9F9F7] text-[#1B3022] py-8 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      {/* Category Navigation */}
      <nav aria-label="Navigation des catégories de recettes" className="flex flex-wrap items-center gap-2 mb-8 border-b border-stone-200 pb-4 text-xs font-mono uppercase tracking-wider">
        <a
          href="/recettes/"
          onClick={(e) => handleLinkClick(e, '/recettes/')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            currentCategory === 'hub' ? 'bg-[#1B3022] text-[#FAF8F5]' : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          Toutes les recettes
        </a>
        <a
          href="/recettes/culinaires/"
          onClick={(e) => handleLinkClick(e, '/recettes/culinaires/')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            currentCategory === 'culinaires' ? 'bg-[#1B3022] text-[#FAF8F5]' : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          Culinaires
        </a>
        <a
          href="/recettes/cosmetiques/"
          onClick={(e) => handleLinkClick(e, '/recettes/cosmetiques/')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            currentCategory === 'cosmetiques' ? 'bg-[#1B3022] text-[#FAF8F5]' : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          Cosmétiques
        </a>
        <a
          href="/recettes/parcours-botaniques/"
          onClick={(e) => handleLinkClick(e, '/recettes/parcours-botaniques/')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            currentCategory === 'parcours-botaniques' ? 'bg-[#1B3022] text-[#FAF8F5]' : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          Parcours Botaniques
        </a>
      </nav>

      <header className="mb-10">
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#1B3022] mb-3">
          {categoryMeta.title.split('|')[0].trim()}
          {safePageNum > 1 && <span className="text-stone-400 font-sans text-xl ml-3">Page {safePageNum}</span>}
        </h1>
        <p className="text-stone-600 text-sm sm:text-base max-w-3xl leading-relaxed">
          {categoryMeta.intro}
        </p>
      </header>

      {/* Grid of Crawlable Recipes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {paginatedRecipes.map((recipe) => (
          <article
            key={recipe.id}
            className="bg-white rounded-2xl border border-stone-200 overflow-hidden hover:shadow-md transition-shadow flex flex-col justify-between"
          >
            <div className="p-6">
              <div className="flex items-center justify-between text-xs font-mono uppercase text-stone-500 mb-2">
                <span>{recipe.categoryLabel}</span>
                <span className="text-emerald-700 font-semibold">{recipe.difficulty}</span>
              </div>
              <h2 className="text-lg font-serif font-bold text-[#1B3022] mb-2 leading-snug">
                <a
                  href={recipe.canonicalUrl}
                  onClick={(e) => handleLinkClick(e, recipe.canonicalUrl)}
                  className="hover:text-emerald-800 transition-colors"
                >
                  {recipe.title}
                </a>
              </h2>
              <p className="text-xs text-stone-600 leading-relaxed line-clamp-3 mb-4">
                {recipe.summary}
              </p>
              <div className="flex items-center gap-3 text-xs text-stone-500 font-mono">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {recipe.totalTimeMinutes} min
                </span>
                <span>• {recipe.ingredients.length} ingrédients</span>
              </div>
            </div>

            <div className="px-6 py-4 bg-[#F9F9F7] border-t border-stone-100 flex items-center justify-between">
              <a
                href={recipe.canonicalUrl}
                onClick={(e) => handleLinkClick(e, recipe.canonicalUrl)}
                className="text-xs font-bold text-[#1B3022] hover:text-[#D97706] uppercase tracking-wider flex items-center gap-1 transition-colors"
              >
                Voir la recette <ChevronRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </article>
        ))}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <nav aria-label="Pagination des recettes" className="flex items-center justify-center gap-2 pt-6 border-t border-stone-200">
          {safePageNum > 1 && (
            <a
              href={getPageUrl(safePageNum - 1)}
              onClick={(e) => handleLinkClick(e, getPageUrl(safePageNum - 1))}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-white border border-stone-200 text-xs font-mono text-stone-700 hover:bg-stone-50"
            >
              <ChevronLeft className="w-4 h-4" /> Précédent
            </a>
          )}

          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <a
              key={p}
              href={getPageUrl(p)}
              onClick={(e) => handleLinkClick(e, getPageUrl(p))}
              className={`w-9 h-9 flex items-center justify-center rounded-lg text-xs font-mono font-bold transition-colors ${
                p === safePageNum
                  ? 'bg-[#1B3022] text-white shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
              }`}
            >
              {p}
            </a>
          ))}

          {safePageNum < totalPages && (
            <a
              href={getPageUrl(safePageNum + 1)}
              onClick={(e) => handleLinkClick(e, getPageUrl(safePageNum + 1))}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-white border border-stone-200 text-xs font-mono text-stone-700 hover:bg-stone-50"
            >
              Suivant <ChevronRight className="w-4 h-4" />
            </a>
          )}
        </nav>
      )}
    </div>
  );
};

export default PublicRecipeCatalog;
