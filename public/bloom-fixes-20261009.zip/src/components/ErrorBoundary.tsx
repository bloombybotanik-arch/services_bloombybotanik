import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('BloomApp Uncaught Runtime Error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F9F9F7] text-[#1B3022] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white border border-stone-200 rounded-3xl p-8 text-center shadow-lg">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto mb-4 font-bold text-xl">
              !
            </div>
            <h2 className="text-xl font-serif font-bold text-[#1B3022] mb-2">Une interruption temporaire est survenue</h2>
            <p className="text-xs text-stone-600 mb-6 leading-relaxed">
              L'application a rencontré une anomalie d'exécution lors du rendu. Vous pouvez recharger l'interface en toute sécurité.
            </p>
            {this.state.error?.message && (
              <pre className="text-[10px] bg-stone-50 border border-stone-200 p-3 rounded-xl text-left text-stone-700 overflow-x-auto mb-6 max-h-32">
                {this.state.error.message}
              </pre>
            )}
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.href = '/';
              }}
              className="px-6 py-2.5 bg-[#1B3022] hover:bg-[#D97706] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
            >
              Recharger l'accueil
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
