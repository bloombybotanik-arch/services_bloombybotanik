export type Language = 'fr' | 'en' | 'de';

export const translations: Record<Language, any> = {
  fr: {
    nav: {
      recipes: "Recettes",
      shop: "Boutique",
      academy: "Académie",
      machine: "BloomLab",
      cart: "Panier",
      account: "Compte"
    },
    common: {
      back: "Retour",
      learnMore: "En savoir plus",
      addToCart: "Ajouter au panier",
      viewRecipe: "Voir la recette",
      difficulty: "Difficulté",
      duration: "Durée",
      ingredients: "Ingrédients",
      instructions: "Instructions"
    },
    seo: {
      keywords: "extracteur botanique, totum vegetal, phytotherapie, herboristerie moderne, infusion precision, huiles infusees, bloomlab",
      alt: {
        extracteur: "Extracteur botanique de précision BloomLab® en verre borosilicate et inox 316L",
        bloomlab: "Extracteur d'extraits botaniques et principes actifs BloomLab®"
      },
      infusion_guide: {
        title: "Mode d'emploi & Principes de l'Extraction Botanique Active",
        summary: "Comprendre les cinétiques d'extraction, le gradient thermique et le standard Totum BOTANIK pour une biodisponibilité optimale.",
        faq_title: "Questions fréquentes sur l'infusion de précision",
        faq: [
          {
            q: "Quelle est la différence entre une tisane classique et une extraction BloomLab ?",
            question: "Quelle est la différence entre une tisane classique et une extraction BloomLab ?",
            a: "Une tisane ordinaire utilise une eau bouillante qui dégrade les composés thermolabiles et laisse les molécules insolubles. Le BloomLab régule la température de 40 à 100°C et crée un vortex dynamique continu pour extraire le Totum moléculaire complet sans dégradation.",
            answer: "Une tisane ordinaire utilise une eau bouillante qui dégrade les composés thermolabiles et laisse les molécules insolubles. Le BloomLab régule la température de 40 à 100°C et crée un vortex dynamique continu pour extraire le Totum moléculaire complet sans dégradation."
          },
          {
            q: "Peut-on extraire dans des solvants gras ou alcoolisés ?",
            question: "Peut-on extraire dans des solvants gras ou alcoolisés ?",
            a: "Oui, le bol en verre borosilicate 3.3 et les pièces en inox 316L chirurgical sont chimiquement inertes, conçus pour les huiles végétales (macerats lipidiques), le vinaigre de cidre et l'alcool éthylique.",
            answer: "Oui, le bol en verre borosilicate 3.3 et les pièces en inox 316L chirurgical sont chimiquement inertes, conçus pour les huiles végétales (macerats lipidiques), le vinaigre de cidre et l'alcool éthylique."
          }
        ]
      }
    },
    guide: {
      machine: {
        title: "Technologie d'Extraction Totum",
        precision: {
          title: "Précision Thermique ±1°C",
          desc: "Contrôle électronique de 40°C à 100°C pour respecter les principes actifs les plus fragiles."
        },
        extraction: {
          title: "Circulation Dynamique Active",
          desc: "Gradient continu de concentration et vortex régulier pour un rendement moléculaire décuplé."
        }
      },
      levels: {
        title: "Trois Niveaux d'Autonomie",
        subtitle: "De l'amateur curieux au praticien chevronné",
        lvl1: {
          status: "Niveau 1",
          title: "Cuisines & Huiles Aromatiques",
          desc: "Sublimez vos plats avec des macérats gastronomiques intenses et digestifs.",
          cta: "Explorer le niveau 1"
        },
        lvl2: {
          status: "Niveau 2",
          title: "Cosmétique Active Maison",
          desc: "Créez vos sérums, baumes et lotions à partir de fleurs médicinales fraîches ou séchées.",
          cta: "Explorer le niveau 2"
        },
        lvl3: {
          status: "Niveau 3",
          title: "Phytothérapie & Soutien de Terrain",
          desc: "Protocoles d'extraction thérapeutique pour soutenir vos émonctoires et équilibres.",
          cta: "Explorer le niveau 3"
        }
      },
      principles: {
        title: "Les Piliers de l'Extraction Moderne",
        p1: {
          title: "Intégrité du Totum",
          desc: "La synergie globale de la plante est préservée sans isolat synthétique."
        },
        p2: {
          title: "Neutralité Chimique",
          desc: "Matériaux neutres garantis zéro transfert de perturbateurs endocriniens."
        },
        p3: {
          title: "Reproductibilité",
          desc: "Paramètres stables pour réitérer vos formules avec exactitude à chaque cycle."
        }
      }
    },
    home: {
      way: {
        badge: "Parcours Botanique",
        title: "La Voie de la Souveraineté Botanique",
        description: "Reprenez la maîtrise de votre santé naturelle et de votre alimentation vivante grâce à une méthode validée par la science végétale.",
        discover: {
          title: "1. Découvrir",
          description: "Explorez notre herbier médicinal et nos formules ouvertes documentées.",
          cta: "Découvrir l'Herbier"
        },
        reset: {
          title: "2. Rééquilibrer",
          description: "Activez vos émonctoires avec nos protocoles d'homéostasie ciblés.",
          cta: "Voir les Protocoles"
        },
        more: {
          title: "3. Créer & Pratiquer",
          description: "Utilisez le BloomLab pour confectionner des remèdes et soins purs chez vous.",
          cta: "Découvrir le BloomLab"
        }
      }
    },
    store: {
      header: {
        title: "Boutique Officielle Bloom by BotaniK",
        subtitle: "Matériel d'extraction de précision, herboristerie sélectionnée et protocoles guidés",
        search_placeholder: "Rechercher un produit, une plante, un kit..."
      },
      hero: {
        badge: "Innovation Rentrée 2026",
        title: "Extracteur BloomLab® Précision Totum",
        description: "Le premier système domestique d'infusion dynamique thermo-régulée conçu pour préserver le spectre moléculaire complet des plantes médicinales.",
        cta: "Découvrir le BloomLab"
      },
      grid: {
        title: "Tous nos équipements et mélanges botaniques",
        results_for: "Résultats pour"
      },
      trust: {
        payment: "Paiement 100% Sécurisé (CB, Stripe, PayPal)",
        lab: "Matériaux de Grade Laboratoire (Inox 316L & Verre 3.3)",
        guarantee: "Garantie Satisfait ou Remboursé 30 Jours"
      },
      products: {
        bloomlab: {
          name: "Extracteur Botanique BloomLab®",
          subtitle: "Infuseur de précision à thermo-régulation active (40-100°C)",
          description: "L'appareil de référence pour réussir vos extractions végétales, macérats lipidiques, teintures et synergies à domicile.",
          bullets: [
            "Cuve borosilicate 3.3 neutre & panier inox chirurgical 316L",
            "Thermo-régulation active de 40°C à 100°C au degré près",
            "Maintien au chaud programmable et cycle automatique",
            "Garantie constructeur 1 an & guide de recettes inclus"
          ]
        },
        bundle_apothicaire: {
          name: "Bundle Apothicaire Rentrée 2026",
          subtitle: "Sélection de 3 mélanges de plantes médicinales sauvages",
          description: "Trio de sachets botaniques hermétiques pour soutenir l'immunité, la vitalité hépatique et le sommeil profond."
        },
        pack_signature: {
          name: "Pack Signature Rentrée — BloomLab® + Duo Argiles",
          subtitle: "L'équipement complet avec double argile purifiante",
          description: "Comprend l'extracteur BloomLab®, le duo d'argiles médicinales montmorillonite/illite et l'accès membre offert."
        },
        kit_starter: {
          name: "Kit Starter Découverte Botanique",
          subtitle: "Mélange Sève Fondamentale — Plantes bio coupées",
          description: "Le mélange parfait pour débuter vos premières infusions actives au BloomLab."
        },
        kit_nuit: {
          name: "Kit Nuit Profonde & Sommeil Réparateur",
          subtitle: "Passiflore, mélisse et camomille noble",
          description: "Favorise l'endormissement naturel et la phase de régénération nerveuse nocturne."
        },
        kit_digestion: {
          name: "Kit Équilibre Digestif & Confort Hépatique",
          subtitle: "Romarin à verbénone, menthe poivrée, fenouil doux",
          description: "Synergie digestive pour alléger les surcharges post-prandiales et stimuler la sécrétion biliaire."
        },
        kit_articulaire: {
          name: "Kit Feu Articulaire & Souplesse",
          subtitle: "Harpagophytum, reine des prés et cassis",
          description: "Soutien des articulations sensibles et diminution des raideurs matinales."
        },
        kit_hiver: {
          name: "Kit Bouclier Hivernal & Voies Respiratoires",
          subtitle: "Thym vulgaire, sureau noir et eucalyptus",
          description: "Protection des muqueuses respiratoires et renforcement des défenses immunitaires naturelles."
        },
        kit_reset: {
          name: "Duo Argiles Vivantes — Illite & Montmorillonite",
          subtitle: "Adsorption intestinale et détoxification douce",
          description: "Deux argiles sélectionnées sans additif pour capter les endotoxines et assainir la muqueuse."
        },
        freemium_access: {
          name: "Accès Découverte Freemium",
          subtitle: "Catalogue public et fiches d'herboristerie",
          description: "Consultez librement les bases de l'extraction, les fiches plantes et les recettes ouvertes."
        },
        premium_access: {
          name: "Abonnement Annuel Bloom Académie",
          subtitle: "Protocoles complets, suivi de terrain et masterclasses",
          description: "Rejoignez le cercle des praticiens autonomes avec nos guides avancés et webinaires mensuels."
        }
      }
    }
  },
  en: {
    nav: {
      recipes: "Recipes",
      shop: "Shop",
      academy: "Academy",
      machine: "BloomLab",
      cart: "Cart",
      account: "Account"
    },
    common: {
      back: "Back",
      learnMore: "Learn more",
      addToCart: "Add to cart",
      viewRecipe: "View recipe",
      difficulty: "Difficulty",
      duration: "Duration",
      ingredients: "Ingredients",
      instructions: "Instructions"
    },
    seo: {
      keywords: "botanical extractor, plant totum, herbal medicine, precision infusion, infused oils, bloomlab",
      alt: {
        extracteur: "BloomLab® Precision Botanical Extractor in borosilicate glass and 316L stainless steel",
        bloomlab: "BloomLab® Active Botanical Compounds Extractor"
      },
      infusion_guide: {
        title: "User Guide & Principles of Active Botanical Extraction",
        summary: "Understand extraction kinetics, thermal gradient, and the Totum BOTANIK standard for optimal bioavailability.",
        faq_title: "Frequently Asked Questions about Precision Infusion",
        faq: [
          {
            q: "What is the difference between classic herbal tea and BloomLab extraction?",
            question: "What is the difference between classic herbal tea and BloomLab extraction?",
            a: "Classic tea uses boiling water that degrades thermolabile compounds and misses insoluble molecules. BloomLab regulates 40-100°C with dynamic vortex flow to extract the full molecular Totum intact.",
            answer: "Classic tea uses boiling water that degrades thermolabile compounds and misses insoluble molecules. BloomLab regulates 40-100°C with dynamic vortex flow to extract the full molecular Totum intact."
          },
          {
            q: "Can you extract in lipid or alcoholic solvents?",
            question: "Can you extract in lipid or alcoholic solvents?",
            a: "Yes, borosilicate 3.3 glass and surgical 316L stainless steel are fully inert and designed for plant oils, vinegars, and food-grade alcohols.",
            answer: "Yes, borosilicate 3.3 glass and surgical 316L stainless steel are fully inert and designed for plant oils, vinegars, and food-grade alcohols."
          }
        ]
      }
    },
    guide: {
      machine: {
        title: "Totum Extraction Technology",
        precision: {
          title: "Thermal Precision ±1°C",
          desc: "Electronic control from 40°C to 100°C to preserve fragile active compounds."
        },
        extraction: {
          title: "Active Dynamic Circulation",
          desc: "Continuous concentration gradient and vortex flow for maximum yield."
        }
      },
      levels: {
        title: "Three Levels of Autonomy",
        subtitle: "From curious enthusiast to seasoned herbal practitioner",
        lvl1: {
          status: "Level 1",
          title: "Culinary & Aromatic Oils",
          desc: "Enhance your dishes with intense and digestive gastronomic macerations.",
          cta: "Explore Level 1"
        },
        lvl2: {
          status: "Level 2",
          title: "Homemade Active Cosmetics",
          desc: "Create your own serums, balms, and lotions from fresh or dried medicinal flowers.",
          cta: "Explore Level 2"
        },
        lvl3: {
          status: "Level 3",
          title: "Phytotherapy & Terrain Support",
          desc: "Therapeutic extraction protocols to support emunctories and biological balance.",
          cta: "Explore Level 3"
        }
      },
      principles: {
        title: "Pillars of Modern Extraction",
        p1: {
          title: "Totum Integrity",
          desc: "Complete botanical synergy preserved without synthetic isolates."
        },
        p2: {
          title: "Chemical Inertness",
          desc: "Certified zero hormone-disruptor leaching."
        },
        p3: {
          title: "Reproducibility",
          desc: "Stable parameters to replicate formulas precisely every cycle."
        }
      }
    },
    home: {
      way: {
        badge: "Botanical Journey",
        title: "The Path to Botanical Sovereignty",
        description: "Regain mastery over your natural health with science-backed plant wisdom.",
        discover: {
          title: "1. Discover",
          description: "Explore our medicinal herbarium and documented open recipes.",
          cta: "Explore Herbarium"
        },
        reset: {
          title: "2. Rebalance",
          description: "Activate emunctories with targeted biological reset protocols.",
          cta: "View Protocols"
        },
        more: {
          title: "3. Craft & Practice",
          description: "Use BloomLab to prepare pure remedies and cosmetics at home.",
          cta: "Discover BloomLab"
        }
      }
    },
    store: {
      header: {
        title: "Official Bloom by BotaniK Store",
        subtitle: "Precision extraction equipment, selected herbs, and guided protocols",
        search_placeholder: "Search a product, plant, kit..."
      },
      hero: {
        badge: "2026 Innovation",
        title: "BloomLab® Totum Extractor",
        description: "The first domestic dynamic temperature-regulated infusion system designed to preserve the full molecular spectrum of medicinal plants.",
        cta: "Discover BloomLab"
      },
      grid: {
        title: "All equipment and botanical blends",
        results_for: "Results for"
      },
      trust: {
        payment: "100% Secure Payment (Credit Card, Stripe, PayPal)",
        lab: "Laboratory Grade Materials (316L Inox & 3.3 Glass)",
        guarantee: "30-Day Money Back Guarantee"
      },
      products: {
        bloomlab: {
          name: "BloomLab® Botanical Extractor",
          subtitle: "Precision infuser with active temperature control (40-100°C)",
          description: "The reference equipment for successful plant infusions, lipid macerations, and tinctures at home.",
          bullets: [
            "Neutral 3.3 borosilicate glass & surgical 316L stainless steel basket",
            "Active temperature regulation from 40°C to 100°C degree by degree",
            "Programmable keep-warm mode and automatic cycle",
            "1-year manufacturer warranty & recipe guide included"
          ]
        },
        bundle_apothicaire: {
          name: "Apothecary Bundle 2026",
          subtitle: "Selection of 3 wild medicinal plant blends",
          description: "Trio of airtight botanical pouches to support immunity, liver vitality, and deep sleep."
        },
        pack_signature: {
          name: "Signature Pack — BloomLab® + Clay Duo",
          subtitle: "Complete setup with purifying double clay",
          description: "Includes BloomLab® extractor, montmorillonite/illite medicinal clay duo, and complimentary membership access."
        },
        kit_starter: {
          name: "Discovery Starter Kit",
          subtitle: "Fundamental Sap blend — Organic cut herbs",
          description: "The perfect blend to start your first active infusions with BloomLab."
        },
        kit_nuit: {
          name: "Deep Night & Restorative Sleep Kit",
          subtitle: "Passionflower, lemon balm, and chamomile",
          description: "Promotes natural sleep and nocturnal nervous system recovery."
        },
        kit_digestion: {
          name: "Digestive Balance & Liver Comfort Kit",
          subtitle: "Verbenone rosemary, peppermint, sweet fennel",
          description: "Digestive synergy to ease post-meal heaviness and stimulate bile secretion."
        },
        kit_articulaire: {
          name: "Joint Fire & Flexibility Kit",
          subtitle: "Devil's claw, meadowsweet, blackcurrant",
          description: "Supports sensitive joints and eases morning stiffness."
        },
        kit_hiver: {
          name: "Winter Shield & Respiratory Kit",
          subtitle: "Thyme, elderberry, eucalyptus",
          description: "Protects respiratory mucosa and boosts natural immune defenses."
        },
        kit_reset: {
          name: "Living Clays Duo — Illite & Montmorillonite",
          subtitle: "Intestinal adsorption and gentle detoxification",
          description: "Two additive-free selected clays to bind endotoxins and cleanse intestinal lining."
        },
        freemium_access: {
          name: "Freemium Discovery Access",
          subtitle: "Public catalog and herbal monographs",
          description: "Freely consult extraction principles, plant monographs, and open recipes."
        },
        premium_access: {
          name: "Annual Bloom Academy Membership",
          subtitle: "Complete protocols, terrain tracking, and masterclasses",
          description: "Join our circle of autonomous practitioners with advanced guides and monthly webinars."
        }
      }
    }
  },
  de: {
    nav: {
      recipes: "Rezepte",
      shop: "Shop",
      academy: "Akademie",
      machine: "BloomLab",
      cart: "Warenkorb",
      account: "Konto"
    },
    common: {
      back: "Zurück",
      learnMore: "Mehr erfahren",
      addToCart: "In den Warenkorb",
      viewRecipe: "Rezept ansehen",
      difficulty: "Schwierigkeit",
      duration: "Dauer",
      ingredients: "Zutaten",
      instructions: "Anleitung"
    },
    seo: {
      keywords: "botanischer extraktor, pflanzliches totum, phytotherapie, moderne krauterkunde, prazisionsinfusion, bloomlab",
      alt: {
        extracteur: "BloomLab® Präzisions-Pflanzenextraktor aus Borosilikatglas und 316L Edelstahl",
        bloomlab: "BloomLab® Extraktor für pflanzliche Wirkstoffe"
      },
      infusion_guide: {
        title: "Gebrauchsanweisung & Prinzipien der aktiven Pflanzenextraktion",
        summary: "Verstehen Sie Extraktionskinetik, Temperaturgradienten und den Totum BOTANIK-Standard für optimale Bioverfügbarkeit.",
        faq_title: "Häufig gestellte Fragen zur Präzisionsinfusion",
        faq: [
          {
            q: "Was ist der Unterschied zwischen klassischem Kräutertee und BloomLab-Extraktion?",
            question: "Was ist der Unterschied zwischen klassischem Kräutertee und BloomLab-Extraktion?",
            a: "Kochendes Wasser zerstört thermolabile Wirkstoffe. BloomLab regelt von 40-100°C mit dynamischem Wirbel, um das gesamte molekulare Totum unbeschadet zu gewinnen.",
            answer: "Kochendes Wasser zerstört thermolabile Wirkstoffe. BloomLab regelt von 40-100°C mit dynamischem Wirbel, um das gesamte molekulare Totum unbeschadet zu gewinnen."
          },
          {
            q: "Kann man in fetten oder alkoholischen Lösungsmitteln extrahieren?",
            question: "Kann man in fetten oder alkoholischen Lösungsmitteln extrahieren?",
            a: "Ja, Borosilikatglas 3.3 und chirurgischer Edelstahl 316L sind chemisch inert für Pflanzenöle, Essig und Alkohol.",
            answer: "Ja, Borosilikatglas 3.3 und chirurgischer Edelstahl 316L sind chemisch inert für Pflanzenöle, Essig und Alkohol."
          }
        ]
      }
    },
    guide: {
      machine: {
        title: "Totum Extraktionstechnologie",
        precision: {
          title: "Thermo-Präzision ±1°C",
          desc: "Elektronische Steuerung von 40°C bis 100°C zur Schonung empfindlicher Inhaltsstoffe."
        },
        extraction: {
          title: "Aktive dynamische Zirkulation",
          desc: "Kontinuierlicher Konzentrationsgradient und Wirbelfluss für maximale Ausbeute."
        }
      },
      levels: {
        title: "Drei Stufen der Autonomie",
        subtitle: "Vom interessierten Laien bis zum erfahrenen Praktiker",
        lvl1: {
          status: "Stufe 1",
          title: "Kulinarische & Aromatische Öle",
          desc: "Verfeinern Sie Gerichte mit intensiven und bekömmlichen Mazeraten.",
          cta: "Stufe 1 entdecken"
        },
        lvl2: {
          status: "Stufe 2",
          title: "Selbstgemachte aktive Naturkosmetik",
          desc: "Erstellen Sie Seren, Balsame und Lotionen aus frischen oder getrockneten Blüten.",
          cta: "Stufe 2 entdecken"
        },
        lvl3: {
          status: "Stufe 3",
          title: "Phytotherapie & Milieu-Unterstützung",
          desc: "Therapeutische Extraktionsprotokolle zur Stärkung der Ausleitungsorgane.",
          cta: "Stufe 3 entdecken"
        }
      },
      principles: {
        title: "Säulen moderner Extraktion",
        p1: {
          title: "Totum-Integrität",
          desc: "Ganzheitliche Pflanzensynergie ohne synthetische Isolate."
        },
        p2: {
          title: "Chemische Neutralität",
          desc: "Garantierter Ausschluss von Weichmachern und Fremdstoffen."
        },
        p3: {
          title: "Reproduzierbarkeit",
          desc: "Gleiche Parameter für stets identische Rezepturergebnisse."
        }
      }
    },
    home: {
      way: {
        badge: "Botanischer Weg",
        title: "Der Weg zur botanischen Souveränität",
        description: "Gewinnen Sie die Kontrolle über Ihre natürliche Gesundheit mit wissenschaftlich fundierter Pflanzenkunde zurück.",
        discover: {
          title: "1. Entdecken",
          description: "Erkunden Sie unser Heilpflanzen-Herbar und offene Rezepturen.",
          cta: "Herbar ansehen"
        },
        reset: {
          title: "2. Ausgleichen",
          description: "Aktivieren Sie Ihre Ausleitungsorgane mit gezielten Protokollen.",
          cta: "Protokolle ansehen"
        },
        more: {
          title: "3. Praktizieren",
          description: "Nutzen Sie BloomLab für reine Heilmittel und Pflege zu Hause.",
          cta: "BloomLab entdecken"
        }
      }
    },
    store: {
      header: {
        title: "Offizieller Bloom by BotaniK Shop",
        subtitle: "Präzisions-Extraktionsgeräte, ausgewählte Kräuter und geführte Protokolle",
        search_placeholder: "Produkt, Pflanze oder Set suchen..."
      },
      hero: {
        badge: "Innovation 2026",
        title: "BloomLab® Totum-Extraktor",
        description: "Das erste Haushalts-Infusionssystem mit dynamischer Temperaturkontrolle zum Schutz des vollen Wirkstoffspektrums.",
        cta: "BloomLab entdecken"
      },
      grid: {
        title: "Alle Geräte und Kräutermischungen",
        results_for: "Ergebnisse für"
      },
      trust: {
        payment: "100% sichere Zahlung (Kreditkarte, Stripe, PayPal)",
        lab: "Labor-Qualitätsmaterialien (316L Edelstahl & 3.3 Glas)",
        guarantee: "30 Tage Geld-zurück-Garantie"
      },
      products: {
        bloomlab: {
          name: "BloomLab® Botanischer Extraktor",
          subtitle: "Präzisionsinfuseur mit aktiver Temperaturregelung (40-100°C)",
          description: "Das Referenzgerät für gelungene Pflanzenauszüge und Mazerate zu Hause.",
          bullets: [
            "Neutrales Borosilikatglas 3.3 & chirurgischer Edelstahlkorb 316L",
            "Aktive Temperaturregelung von 40°C bis 100°C gradgenau",
            "Programmierbare Warmhaltefunktion und automatischer Zyklus",
            "1 Jahr Herstellergarantie & Rezeptheft inklusive"
          ]
        },
        bundle_apothicaire: {
          name: "Apotheker-Bundle 2026",
          subtitle: "Auswahl aus 3 Wildkräutermischungen",
          description: "Trio luftdichter Beutel zur Unterstützung von Abwehrkräften, Leber und Tiefschlaf."
        },
        pack_signature: {
          name: "Signatur-Paket — BloomLab® + Erden-Duo",
          subtitle: "Komplettausstattung mit klärenden Heilerden",
          description: "Enthält BloomLab®, das Heilerden-Duo Montmorillonit/Illit und Mitgliedszugang."
        },
        kit_starter: {
          name: "Starter-Entdeckerset",
          subtitle: "Mischung Ursaft — Bio-Schnittkräuter",
          description: "Die ideale Mischung für erste aktive Auszüge im BloomLab."
        },
        kit_nuit: {
          name: "Tiefschlaf & Erholungs-Set",
          subtitle: "Passionsblume, Melisse und Kamille",
          description: "Fördert das natürliche Einschlafen und die nächtliche Regeneration."
        },
        kit_digestion: {
          name: "Verdauungsbalance & Leber-Set",
          subtitle: "Verbenon-Rosmarin, Pfefferminze, Fenchel",
          description: "Verdauungssynergie gegen Völlegefühl und zur Unterstützung des Gallenflusses."
        },
        kit_articulaire: {
          name: "Gelenkfeuer & Beweglichkeit",
          subtitle: "Teufelskralle, Mädesüß, schwarze Johannisbeere",
          description: "Unterstützung für empfindliche Gelenke und gegen Morgensteifigkeit."
        },
        kit_hiver: {
          name: "Winterschutz & Atemwege",
          subtitle: "Thymian, schwarzer Holunder, Eukalyptus",
          description: "Schutz der Atemwegsschleimhäute und Stärkung der körpereigenen Abwehr."
        },
        kit_reset: {
          name: "Lebendige Heilerden — Illit & Montmorillonit",
          subtitle: "Darm-Adsorption und sanfte Reinigung",
          description: "Zwei zusatzstofffreie Tonerden zur Bindung von Endotoxinen."
        },
        freemium_access: {
          name: "Kostenfreier Entdeckerzugang",
          subtitle: "Öffentlicher Katalog und Pflanzenmonographien",
          description: "Freier Zugriff auf Grundlagen der Extraktion und offene Rezepte."
        },
        premium_access: {
          name: "Bloom Akademie Jahresmitgliedschaft",
          subtitle: "Vollständige Protokolle, Milieu-Begleitung und Masterclasses",
          description: "Erweiterte Fachleitfäden und monatliche Experten-Webinare."
        }
      }
    }
  }
};
